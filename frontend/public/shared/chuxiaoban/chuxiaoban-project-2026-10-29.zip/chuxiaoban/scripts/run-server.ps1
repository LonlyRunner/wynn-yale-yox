$ErrorActionPreference = 'Stop'
$port = if ($args.Count -gt 0) { [int]$args[0] } else { 8080 }
$projectRoot = Split-Path -Parent $PSScriptRoot

Get-Content (Join-Path $projectRoot '.env') | ForEach-Object {
    if ($_ -match '^([A-Za-z_][A-Za-z0-9_]*)=(.*)$') {
        [Environment]::SetEnvironmentVariable($matches[1], $matches[2], 'Process')
    }
}
[Environment]::SetEnvironmentVariable('CXB_SERVER_PORT', $port, 'Process')

Set-Location (Join-Path $projectRoot 'apps\server')
mvn -q spring-boot:run
