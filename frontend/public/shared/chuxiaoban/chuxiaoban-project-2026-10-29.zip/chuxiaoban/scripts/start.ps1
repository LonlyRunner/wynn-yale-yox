$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot

function Test-Port([int] $Port) {
    return $null -ne (Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction SilentlyContinue)
}

function Test-BackendReady {
    param([int] $Port = 8080)
    try { return (Invoke-WebRequest -UseBasicParsing ("http://localhost:{0}/actuator/health" -f $Port) -TimeoutSec 2).StatusCode -eq 200 } catch { return $false }
}

function Test-FrontendReady {
    try { return (Invoke-WebRequest -UseBasicParsing 'http://localhost:5173/' -TimeoutSec 2).StatusCode -eq 200 } catch { return $false }
}

function Wait-Port([int] $Port, [int] $Seconds) {
    $deadline = (Get-Date).AddSeconds($Seconds)
    while ((Get-Date) -lt $deadline) {
        if (Test-Port $Port) { return $true }
        Start-Sleep -Seconds 1
    }
    return $false
}

Set-Location $projectRoot
Write-Host "`n[1/4] Checking Docker..." -ForegroundColor Cyan
docker info 2>$null | Out-Null
if ($LASTEXITCODE -ne 0) {
    $dockerCandidates = @(
        (Join-Path $env:ProgramFiles 'Docker\Docker\Docker Desktop.exe'),
        (Join-Path $env:LOCALAPPDATA 'Programs\DockerDesktop\Docker Desktop.exe')
    )
    $dockerDesktop = $dockerCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (-not $dockerDesktop) { throw 'Docker Desktop is not installed or could not be located.' }
    Start-Process -FilePath $dockerDesktop
    $ready = $false
    for ($i = 0; $i -lt 60; $i++) {
        Start-Sleep -Seconds 1
        docker info 2>$null | Out-Null
        if ($LASTEXITCODE -eq 0) { $ready = $true; break }
    }
    if (-not $ready) { throw 'Docker Desktop did not become ready within 60 seconds.' }
}

Write-Host '[2/4] Starting PostgreSQL, Redis and MinIO...' -ForegroundColor Cyan
docker compose --env-file .env up -d | Out-Host

Write-Host '[3/4] Starting backend...' -ForegroundColor Cyan
${backendPort} = 8080
if (-not (Test-BackendReady $backendPort) -and (Test-Port $backendPort)) {
    $backendPort = 8081
    Write-Host '8080 is occupied by another service; using backend port 8081.' -ForegroundColor Yellow
}
if (-not (Test-BackendReady $backendPort)) {
    Start-Process powershell -ArgumentList '-NoExit', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'run-server.ps1'), $backendPort
}
$backendDeadline = (Get-Date).AddSeconds(45)
while ((Get-Date) -lt $backendDeadline -and -not (Test-BackendReady $backendPort)) { Start-Sleep -Seconds 1 }
if (-not (Test-BackendReady $backendPort)) { throw "Backend did not start on http://localhost:$backendPort within 45 seconds. Check the backend PowerShell window." }

Write-Host '[4/4] Starting H5 frontend...' -ForegroundColor Cyan
${frontendPort} = 5173
if ($backendPort -ne 8080 -and (Test-FrontendReady)) { $frontendPort = 5174 }
if (-not (Test-FrontendReady) -or $frontendPort -ne 5173) {
    Start-Process powershell -ArgumentList '-NoExit', '-ExecutionPolicy', 'Bypass', '-File', (Join-Path $PSScriptRoot 'run-web.ps1'), $frontendPort, "http://localhost:$backendPort"
}
$frontendDeadline = (Get-Date).AddSeconds(45)
while ((Get-Date) -lt $frontendDeadline -and -not (Test-FrontendReady)) { Start-Sleep -Seconds 1 }
if (-not (Test-FrontendReady)) { throw "Frontend did not start on http://localhost:$frontendPort within 45 seconds. Check the frontend PowerShell window." }

Start-Process "http://localhost:$frontendPort/"
Write-Host "`nChuxiaoban started: http://localhost:$frontendPort/ (backend http://localhost:$backendPort)" -ForegroundColor Green
