$ErrorActionPreference = 'Stop'
$port = if ($args.Count -gt 0) { [int]$args[0] } else { 5173 }
$apiBaseUrl = if ($args.Count -gt 1) { $args[1] } else { 'http://localhost:8080' }
$projectRoot = Split-Path -Parent $PSScriptRoot
$webRoot = Join-Path $projectRoot 'apps\web-mini'

Set-Location $webRoot
[Environment]::SetEnvironmentVariable('VITE_API_BASE_URL', $apiBaseUrl, 'Process')
if (-not (Test-Path (Join-Path $webRoot 'node_modules'))) {
    npm install
}
npm run dev:h5 -- --port $port
