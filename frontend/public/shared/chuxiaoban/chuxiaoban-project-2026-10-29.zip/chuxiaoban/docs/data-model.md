# 核心数据模型

```mermaid
erDiagram
  SYNC_SPACE ||--o{ GUEST_DEVICE : contains
  SYNC_SPACE ||--o{ RECOGNITION_TASK : owns
  RECOGNITION_TASK ||--o{ RECOGNIZED_ITEM : returns
  RECOGNITION_TASK ||--o{ CONFIRMED_INGREDIENT : confirms
  SYNC_SPACE ||--o{ RECOMMENDATION_BATCH : owns
  RECOMMENDATION_BATCH ||--o{ RECOMMENDED_DISH : contains
  RECOMMENDED_DISH ||--|| RECIPE : resolves
  SYNC_SPACE ||--o{ COOKING_FEEDBACK : owns
  RECIPE ||--o{ COOKING_FEEDBACK : receives
  SYNC_SPACE ||--o{ UPLOAD_OBJECT : owns
```

## 表与关键字段

- `sync_space`：`id`、`status`、`version`、`created_at`、`deleted_at`。匿名数据的归属边界。
- `guest_device`：`id`、`sync_space_id`、`device_public_id_hash`、`token_version`、`last_seen_at`、`revoked_at`。
- `sync_code`：`id`、`sync_space_id`、`code_hash`、`expires_at`、`attempts`、`used_at`。只保存哈希。
- `upload_object`：`id`、`sync_space_id`、`object_key`、`mime_type`、`size_bytes`、`sha256`、`status`、`expires_at`。
- `recognition_task`：`id`、`sync_space_id`、`upload_object_id`、`status`、`schema_version`、`model_ref`、`error_code`、时间戳。
- `recognized_item`：`id`、`task_id`、`name`、`quantity_text`、`category`、`confidence`、`needs_confirmation`、`allergen_codes`。
- `confirmed_ingredient`：`id`、`task_id`、`source_item_id`（可空）、`name`、`quantity_text`、`allergen_codes`、`position`。
- `recommendation_batch`：`id`、`sync_space_id`、`recognition_task_id`、`preferences_json`、`status`、`version`。
- `recommended_dish`：`id`、`batch_id`、`name`、`difficulty`、`prep_minutes`、`cook_minutes`、`ingredients_json`、`warnings_json`、`replaced_dish_id`。
- `recipe`：`id`、`recommended_dish_id`、`schema_version`、`steps_json`、`safety_warnings_json`、`content_hash`。
- `cooking_feedback`：`id`、`sync_space_id`、`recipe_id`、`rating`、`actual_minutes`、`notes`、`version`、时间戳和软删除字段。

## 一致性规则

- 所有业务查询必须带 `sync_space_id`，禁止只按对象 ID 查询。
- 识别任务必须处于 `CONFIRMED` 后才能创建推荐批次。
- 反馈评分为 1–5；实际用时为 1–1440 分钟。
- 可同步记录具有 `version`、`updated_at`、`deleted_at`；客户端提交基础版本，版本不一致返回冲突。
- 原始 AI 响应仅作短期受控诊断，不直接作为业务表事实；业务入库使用通过 Schema 和规则校验后的字段。

