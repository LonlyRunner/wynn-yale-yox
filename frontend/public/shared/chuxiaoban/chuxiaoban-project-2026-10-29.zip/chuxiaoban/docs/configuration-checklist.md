# 需要配置的外部参数清单

> 当前先记录，不要求现在填写。开发联调前统一配置到本地 `.env` 或部署平台密钥管理中，禁止提交真实值。

## 必填基础设施

- `CXB_DB_URL`：PostgreSQL 连接地址。
- `CXB_DB_USERNAME` / `CXB_DB_PASSWORD`：数据库账号密码。
- `CXB_REDIS_HOST` / `CXB_REDIS_PORT`：Redis 地址。
- `CXB_S3_ENDPOINT`：S3/MinIO 私有对象存储地址。
- `CXB_S3_ACCESS_KEY` / `CXB_S3_SECRET_KEY`：对象存储访问密钥。
- `CXB_S3_BUCKET`：私有 Bucket 名称。
- `CXB_TOKEN_SECRET`：至少 32 字符的随机 Token 密钥。

## AI 服务

- `CXB_AI_PROVIDER`：`mock`（本地联调）或真实供应商标识。
- `CXB_AI_BASE_URL`：真实 AI 服务端点。
- `CXB_AI_API_KEY`：真实 AI 服务密钥。
- `CXB_AI_VISION_MODEL`：视觉识别模型 ID。
- `CXB_AI_TEXT_MODEL`：推荐/菜谱模型 ID。
- `CXB_AI_TIMEOUT_MS`：单次调用超时。
- `CXB_AI_MAX_RETRIES`：最多重试次数，建议 1。
- 需要确认供应商是否允许上传用户图片、数据保存周期和地域。

## 微信小程序与 H5

- `apps/web-mini/src/manifest.json` 的微信小程序 `appid`。
- 微信开发者工具的合法业务域名、request 合法域名、uploadFile 合法域名和 downloadFile 合法域名。
- `VITE_API_BASE_URL`：H5 调用的 HTTPS API 地址。
- 生产环境 CORS 允许来源和图片下载域名。
- 隐私政策、用户数据删除说明和第三方 AI 数据传输说明页面地址。

## 发布前才需要

- HTTPS 证书和域名。
- 对象存储生命周期规则：未确认图片 24 小时、确认图片默认 7 天。
- 监控、告警和日志脱敏配置。
- 真实模型调用预算与限流阈值。

