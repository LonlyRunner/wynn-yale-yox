# 技术基线

## 前端

| 项目 | 决定 |
|---|---|
| Runtime | Node.js 24 LTS |
| 包管理器 | npm 11；提交 `package-lock.json`，CI 使用 `npm ci` |
| 框架 | uni-app Vue3 发行线 `3.0.0-5020420260813003` |
| Vue | 3.5.41 |
| 构建 | Vite；版本由 uni-app 官方模板兼容集锁定，不单独升级 |
| 语言 | TypeScript；版本由模板兼容集锁定，开启 strict |
| 状态 | Pinia；使用与 Vue/uni-app 兼容版本并由 lockfile 精确锁定 |
| UI | uView Plus 3.8.108，统一使用 `up-` 前缀 |
| CSS | Sass 1.79.x，暂不升至触发旧 `@import` 兼容问题的版本 |
| 目标 | `mp-weixin`、`h5` |

说明：DCloud 包必须保持同一发行号，不允许分别升级。安装依赖后以 lockfile 为最终精确版本源。

## 后端

| 项目 | 决定 |
|---|---|
| JDK | Java 21 LTS |
| 构建 | Maven 3.9.4+；使用 Maven Wrapper |
| 框架 | Spring Boot 3.5.16 |
| 架构 | 单应用、按业务模块分包，不引入 Spring Cloud/Nacos/Feign |
| API | Spring MVC + Jakarta Validation + springdoc-openapi |
| 持久化 | PostgreSQL 17；Flyway 管理迁移 |
| 缓存 | Redis 7.4 |
| 文件 | S3 兼容私有对象存储，开发环境使用 MinIO |
| 测试 | JUnit 5、Testcontainers、MockWebServer |

## 版本策略

- patch 更新可在自动化测试通过后合并；minor/major 更新必须单独评审。
- AI 模型 ID、供应商端点、超时和能力通过环境配置管理。
- 不在日志、前端包或仓库中保存密钥。

