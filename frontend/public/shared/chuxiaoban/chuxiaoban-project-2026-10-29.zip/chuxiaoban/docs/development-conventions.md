# 项目结构与开发规范

```text
chuxiaoban/
  apps/
    web-mini/             # uni-app：H5 + 微信小程序
    server/               # Spring Boot 模块化单体
  api/openapi.yaml
  schemas/ai/
  docs/
  tests/ai-fixtures/
```

后端包根为 `cn.chuxiaoban`，业务模块为 `sync`、`recognition`、`recommendation`、`dish`、`knowledge`、`oss`、`ai`。模块内部按 `api/application/domain/infrastructure` 分层；模块间只通过 application 接口通信。

前端页面置于 `src/pages`，通用组件置于 `src/components/cxb`，状态置于 `src/stores`，HTTP 置于 `src/api`，平台差异封装于 `src/platform`。

## 约定

- JSON 字段和 URL 使用 snake_case；TypeScript/Java 内部使用各语言常规命名并在序列化边界映射。
- 时间统一为 UTC ISO 8601，显示时转 Asia/Shanghai；金额用整数分，不用浮点数。
- 数据 ID 使用不可枚举的 UUIDv7；用户可见短码不得作为数据主键。
- 所有写接口支持 `Idempotency-Key`；所有响应携带 `X-Request-Id`。
- 日志结构化输出，只记录内部 ID、耗时和结果码，不记录 Token、同步码、图片和笔记正文。
- 环境变量以 `CXB_` 开头；仓库只提交 `.env.example`。
- 提交前必须通过 format、lint、typecheck、unit test 和 Schema test。

