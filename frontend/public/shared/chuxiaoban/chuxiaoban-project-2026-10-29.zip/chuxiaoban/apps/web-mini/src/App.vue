<script setup lang="ts">
import { onLaunch } from '@dcloudio/uni-app'
import { useGuestStore } from './stores/guest'
import { useSyncStore } from './stores/sync'

onLaunch(() => console.info('厨小伴启动'))
const guestStore = useGuestStore()
const syncStore = useSyncStore()
void guestStore.initialize().then(() => syncStore.startPolling())
</script>

<style lang="scss">
@import 'uview-plus/index.scss';

page {
  min-height: 100%;
  color: #1a1a2e;
  background: #fff8f0;
  font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', sans-serif;
}
</style>
