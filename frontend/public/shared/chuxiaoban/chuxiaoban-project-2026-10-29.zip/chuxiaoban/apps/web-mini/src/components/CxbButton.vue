<script setup lang="ts">
withDefaults(defineProps<{ text?: string; disabled?: boolean; type?: 'primary'|'secondary'|'ghost' }>(), { type: 'primary' })
</script>
<template><button class="cxb-btn" :class="type" :disabled="disabled"><slot>{{text}}</slot></button></template>
<style scoped lang="scss">.cxb-btn{padding:16rpx 28rpx;border:0;border-radius:999rpx;font-size:26rpx}.primary{background:linear-gradient(100deg,#89f7fe,#66a6ff);color:#fff}.secondary{background:#edf7ee;color:#39865a}.ghost{background:transparent;border:1rpx solid #d9c8ba;color:#5d4037}</style>
