<script setup lang="ts">
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { request } from '@/api/http'

const recipeId = ref(''); const rating = ref(5); const actualMinutes = ref(15); const notes = ref(''); const loading = ref(false); const error = ref(''); const submitted = ref(false)
const goHome = () => uni.reLaunch({ url: '/pages/home/index' })
const submit = async () => { if (!recipeId.value) { error.value = '缺少菜谱信息'; return }; loading.value = true; error.value = ''; try { await request({ url: '/api/v1/feedbacks', method: 'POST', data: { recipe_id: recipeId.value, rating: rating.value, actual_minutes: actualMinutes.value, notes: notes.value.trim() || null } }); submitted.value = true } catch (e) { error.value = e instanceof Error ? e.message : '反馈提交失败，请重试' } finally { loading.value = false } }
onLoad((query) => { recipeId.value = String(query?.recipeId || '') })
</script>

<template>
  <view class="page"><view class="hero"><text class="title">这道菜做得怎么样？</text><text class="subtitle">你的反馈会帮助厨小伴改进后续推荐。</text></view><view v-if="submitted" class="success"><text class="success-title">反馈已保存</text><text>感谢你的反馈，下次推荐会更贴合你的口味。</text><button class="primary" @click="goHome">回到首页</button></view><view v-else class="form"><text class="label">满意度</text><view class="stars"><text v-for="n in 5" :key="n" :class="{on:n<=rating}" @click="rating=n">★</text></view><text class="label">实际用时（分钟）</text><input v-model.number="actualMinutes" type="number" class="input" /><text class="label">备注（可选）</text><textarea v-model="notes" maxlength="2000" placeholder="例如：咸淡刚好、下次少放油" class="textarea" /><button class="primary" :disabled="loading" @click="submit">{{ loading ? '保存中…' : '提交反馈' }}</button></view><view v-if="error" class="error">{{ error }}</view></view>
</template>

<style scoped lang="scss">
.page{padding:32rpx;background:#fff8f0;min-height:100vh}.hero,.form,.success{padding:28rpx;border-radius:28rpx;background:rgba(255,255,255,.92);box-shadow:0 12rpx 40rpx rgba(93,64,55,.08)}.title,.subtitle,.label,.success-title{display:block}.title{font-size:40rpx;font-weight:600}.subtitle{margin-top:10rpx;color:#857b78;font-size:25rpx}.form,.success{margin-top:20rpx}.label{margin-top:22rpx;color:#6b625e;font-size:25rpx}.label:first-child{margin-top:0}.stars{display:flex;gap:18rpx;margin-top:14rpx}.stars text{color:#ded5ce;font-size:58rpx;line-height:1}.stars text.on{color:#f2a33b}.input,.textarea{box-sizing:border-box;width:100%;margin-top:12rpx;padding:16rpx;border:1rpx solid #eadfd6;border-radius:16rpx;background:#fff;font-size:27rpx}.textarea{height:190rpx}.primary{width:100%;margin-top:26rpx;border:0;border-radius:999rpx;padding:20rpx;background:linear-gradient(100deg,#89f7fe,#66a6ff);color:#fff;font-size:28rpx}.success-title{font-size:30rpx;font-weight:600}.success text:nth-child(2){display:block;margin-top:12rpx;color:#857b78;font-size:25rpx}.error{margin-top:20rpx;padding:18rpx;border-radius:16rpx;background:#fff0ef;color:#c45555;font-size:24rpx}
</style>
