<script setup lang="ts">
defineProps<{ name: string; quantity?: string | null; haveIt?: boolean }>()
defineEmits<{ remove: [] }>()
</script>
<template><view class="item"><view><text class="name">{{name}}</text><text class="qty">{{quantity||'数量待补充'}}</text></view><text class="state" :class="{have:haveIt}">{{haveIt?'已有':'需购买'}}</text><button @click="$emit('remove')">删除</button></view></template>
<style scoped lang="scss">.item{display:flex;align-items:center;gap:12rpx;padding:16rpx 0;border-bottom:1rpx solid #eee5dc}.item>view{flex:1}.name,.qty{display:block}.name{font-size:26rpx}.qty{margin-top:6rpx;color:#857b78;font-size:21rpx}.state{color:#b7672f;font-size:21rpx}.state.have{color:#39865a}.item button{border:0;background:transparent;color:#c45555;font-size:21rpx}</style>
