<script setup lang="ts">
withDefaults(defineProps<{ text: string; kind?: 'default'|'warning'|'success' }>(), { kind: 'default' })
</script>
<template><text class="tag" :class="kind">{{text}}</text></template>
<style scoped lang="scss">.tag{display:inline-block;padding:6rpx 12rpx;border-radius:999rpx;background:#fff1db;color:#9a6c36;font-size:21rpx}.warning{background:#fff0e5;color:#b7672f}.success{background:#edf7ee;color:#39865a}</style>
