<script setup lang="ts">
defineProps<{ title: string; platform?: string; duration?: number }>()
defineEmits<{ copy: [] }>()
</script>
<template><view class="video"><view><text class="title">{{title}}</text><text class="meta">{{platform||'其他'}} · {{duration?Math.ceil(duration/60)+' 分钟':'时长未标注'}}</text></view><button @click="$emit('copy')">复制链接</button></view></template>
<style scoped lang="scss">.video{display:flex;align-items:center;justify-content:space-between;padding:16rpx 0}.title,.meta{display:block}.title{font-size:26rpx}.meta{margin-top:6rpx;color:#9b8d86;font-size:21rpx}.video button{border:0;border-radius:999rpx;background:#edf6ff;color:#4d83b8;font-size:21rpx}</style>
