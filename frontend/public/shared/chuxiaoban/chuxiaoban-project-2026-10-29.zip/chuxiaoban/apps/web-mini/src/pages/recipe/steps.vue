<script setup lang="ts">
import { computed, onUnmounted, ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { request } from '@/api/http'

interface Step { step_no: number; action: string; heat_level: string; duration_minutes: number; warnings: string[] }
interface Recipe { id: string; dish_name: string; steps: Step[]; safety_warnings: string[] }

const recipe = ref<Recipe | null>(null)
const loading = ref(false)
const error = ref('')
const dishId = ref('')
const activeIndex = ref(0)
const completed = ref<number[]>([])
const timerRunning = ref(false)
const secondsLeft = ref(0)
const voiceEnabled = ref(false)
const voiceSupported = ref(false)
const mode = ref<'beginner'|'advanced'>('beginner')
let timer: ReturnType<typeof setInterval> | undefined

const activeStep = computed(() => recipe.value?.steps[activeIndex.value])
const progress = computed(() => recipe.value?.steps.length ? Math.round((completed.value.length / recipe.value.steps.length) * 100) : 0)
const isLastStep = computed(() => !!recipe.value && activeIndex.value === recipe.value.steps.length - 1)
const formatTime = computed(() => `${String(Math.floor(secondsLeft.value / 60)).padStart(2, '0')}:${String(secondsLeft.value % 60).padStart(2, '0')}`)
const heatLabel = (value: string) => ({ low: '小火', medium: '中火', high: '大火', off: '关火', not_applicable: '无需加热' }[value] || '按实际火力')
const speechEngine = () => (globalThis as typeof globalThis & { speechSynthesis?: { cancel: () => void; speak: (utterance: unknown) => void } }).speechSynthesis
const speak = (text: string) => {
  if (!voiceEnabled.value || !voiceSupported.value) return
  const engine = speechEngine(); if (!engine) return
  engine.cancel()
  const Utterance = (globalThis as typeof globalThis & { SpeechSynthesisUtterance?: new (value: string) => unknown }).SpeechSynthesisUtterance
  if (Utterance) engine.speak(new Utterance(text))
}
const toggleVoice = () => {
  if (!voiceSupported.value) { uni.showToast({ title: '当前平台不支持语音，将显示文字步骤', icon: 'none' }); return }
  voiceEnabled.value = !voiceEnabled.value
  uni.setStorageSync('cxb_voice_enabled', voiceEnabled.value ? '1' : '0')
  if (voiceEnabled.value && activeStep.value) speak(`第${activeStep.value.step_no}步：${activeStep.value.action}`)
  else speechEngine()?.cancel()
}

const stopTimer = () => {
  if (timer) clearInterval(timer)
  timer = undefined
  timerRunning.value = false
}
const resetTimer = () => {
  stopTimer()
  secondsLeft.value = Math.max(0, (activeStep.value?.duration_minutes || 0) * 60)
}
const toggleTimer = () => {
  if (!activeStep.value || secondsLeft.value <= 0) resetTimer()
  if (timerRunning.value) { stopTimer(); return }
  timerRunning.value = true
  timer = setInterval(() => {
    if (secondsLeft.value <= 1) {
      secondsLeft.value = 0
      stopTimer()
      uni.showToast({ title: '本步骤计时完成', icon: 'success' })
      return
    }
    secondsLeft.value -= 1
  }, 1000)
}
const activate = (index: number) => {
  activeIndex.value = index
  resetTimer()
  const step = recipe.value?.steps[index]
  if (step) speak(`第${step.step_no}步：${step.action}`)
}
const markDone = () => {
  const stepNo = activeStep.value?.step_no
  if (stepNo !== undefined && !completed.value.includes(stepNo)) completed.value.push(stepNo)
  if (!isLastStep.value) activate(activeIndex.value + 1)
  else { stopTimer(); uni.showToast({ title: '恭喜完成烹饪！', icon: 'success' }) }
}
const restart = () => {
  completed.value = []
  activate(0)
}
const goFeedback = () => { if (recipe.value) uni.navigateTo({ url: `/pages/feedback/index?recipeId=${recipe.value.id}` }) }
const load = async () => {
  if (!dishId.value) { error.value = '缺少菜品信息'; return }
  loading.value = true; error.value = ''; stopTimer()
  try {
    recipe.value = (await request<Recipe>({ url: `/api/v1/dishes/${dishId.value}`, method: 'GET' })).data
    activeIndex.value = 0
    completed.value = []
    resetTimer()
  } catch (e) { error.value = e instanceof Error ? e.message : '菜谱加载失败' }
  finally { loading.value = false }
}
onLoad((query) => { dishId.value = String(query?.dishId || ''); load() })
onLoad(() => { voiceEnabled.value = uni.getStorageSync('cxb_voice_enabled') === '1'; voiceSupported.value = !!speechEngine() })
onUnmounted(() => { stopTimer(); speechEngine()?.cancel() })
</script>

<template>
  <view class="page">
    <view v-if="loading" class="loading">正在准备步骤…</view>
    <view v-if="error" class="error"><text>{{ error }}</text><button v-if="dishId" class="retry" @click="load">重新加载</button></view>
    <template v-if="recipe && !loading">
      <view class="hero"><text class="title">{{ recipe.dish_name }}</text><text class="subtitle">跟着步骤做，关键处会提醒你。</text><view class="mode-row"><button class="mode" :class="{active:mode==='beginner'}" @click="mode='beginner'">新手模式</button><button class="mode" :class="{active:mode==='advanced'}" @click="mode='advanced'">进阶模式</button></view><button class="voice" :class="{enabled: voiceEnabled}" @click="toggleVoice">语音播报：{{ voiceEnabled ? '开' : '关' }}</button><view class="progress-row"><text>已完成 {{ completed.length }}/{{ recipe.steps.length }}</text><text>{{ progress }}%</text></view><view class="progress-track"><view class="progress-value" :style="{ width: `${progress}%` }" /></view></view>
      <view v-if="recipe.safety_warnings?.length" class="safety"><text class="safety-title">下厨安全提醒</text><text v-for="warning in recipe.safety_warnings" :key="warning" class="warning">⚠ {{ warning }}</text></view>
      <view v-if="activeStep" class="focus-step"><view class="focus-title"><text>当前第 {{ activeStep.step_no }} 步</text><text class="duration">预计 {{ activeStep.duration_minutes }} 分钟</text></view><text class="instruction">{{ activeStep.action }}</text><view class="meta"><text>火力：{{ heatLabel(activeStep.heat_level) }}</text><text v-if="activeStep.duration_minutes">计时：{{ formatTime }}</text></view><text v-for="note in activeStep.warnings" :key="note" class="note">⚠ {{ note }}</text><text v-if="mode==='advanced'" class="tip">进阶提示：先观察食材状态，再微调火力，避免只依赖固定时间。</text><view class="actions"><button v-if="activeStep.duration_minutes" class="timer" @click="toggleTimer">{{ timerRunning ? '暂停计时' : (secondsLeft ? '开始计时' : '重新计时') }}</button><button class="done" @click="markDone">{{ isLastStep ? '完成烹饪' : '完成并下一步　→' }}</button></view></view>
      <view class="step-list"><text class="list-title">全部步骤</text><view v-for="(step, index) in recipe.steps" :key="step.step_no" class="step" :class="{active: index === activeIndex, complete: completed.includes(step.step_no)}" @click="activate(index)"><text class="number">{{ completed.includes(step.step_no) ? '✓' : step.step_no }}</text><view class="step-copy"><text class="step-action">{{ step.action }}</text><text class="step-meta">{{ heatLabel(step.heat_level) }} · {{ step.duration_minutes }} 分钟</text></view></view></view>
      <view class="bottom-actions"><button class="restart" @click="restart">从头开始</button><button class="feedback" @click="goFeedback">评价这道菜</button></view>
    </template>
  </view>
</template>

<style scoped lang="scss">
.page{padding:32rpx;background:#fff8f0;min-height:100vh}.hero,.focus-step,.safety,.step-list,.error{padding:28rpx;border-radius:28rpx;background:rgba(255,255,255,.92);box-shadow:0 12rpx 40rpx rgba(93,64,55,.08)}.title,.subtitle,.instruction,.warning,.note,.step-action,.step-meta{display:block}.title{font-size:40rpx;font-weight:600}.subtitle{margin-top:10rpx;color:#857b78;font-size:25rpx}.voice{margin-top:18rpx;padding:10rpx 20rpx;border:1rpx solid #c6d8ed;border-radius:999rpx;background:#f6fbff;color:#4d83b8;font-size:23rpx}.voice.enabled{background:#edf7ee;border-color:#9fd0aa;color:#39865a}.progress-row{display:flex;justify-content:space-between;margin-top:24rpx;color:#6b625e;font-size:23rpx}.progress-track{height:12rpx;overflow:hidden;margin-top:10rpx;border-radius:99rpx;background:#eee5dc}.progress-value{height:100%;border-radius:99rpx;background:linear-gradient(90deg,#89f7fe,#66a6ff);transition:width .25s}.safety{margin-top:20rpx;background:#fff4e8}.safety-title{display:block;font-size:26rpx;font-weight:600;color:#a75e2a}.warning{margin-top:8rpx;color:#985e38;font-size:23rpx;line-height:1.5}.focus-step{margin-top:20rpx;border:2rpx solid #d7e8fb}.focus-title{display:flex;align-items:center;justify-content:space-between;font-size:28rpx;font-weight:600}.duration{padding:7rpx 12rpx;border-radius:999rpx;background:#fff1db;color:#9a6c36;font-size:22rpx;font-weight:400}.instruction{margin-top:18rpx;color:#443735;font-size:30rpx;line-height:1.7}.meta{display:flex;gap:18rpx;margin-top:16rpx;color:#5d8bc8;font-size:23rpx}.note{margin-top:10rpx;color:#b7672f;font-size:22rpx}.actions{display:flex;gap:14rpx;margin-top:24rpx}.actions button{flex:1;border:0;border-radius:999rpx;padding:17rpx;font-size:24rpx}.timer{background:#edf6ff;color:#4d83b8}.done{background:linear-gradient(100deg,#89f7fe,#66a6ff);color:#fff}.step-list{margin-top:20rpx}.list-title{display:block;margin-bottom:8rpx;font-size:28rpx;font-weight:600}.step{display:flex;gap:16rpx;align-items:flex-start;padding:20rpx 0;border-bottom:1rpx solid #eee5dc}.step:last-child{border-bottom:0}.step.active{margin:0 -12rpx;padding:20rpx 12rpx;border-radius:18rpx;background:#f4faff;border-bottom-color:transparent}.number{display:flex;flex:0 0 48rpx;width:48rpx;height:48rpx;align-items:center;justify-content:center;border-radius:50%;background:#eadfd6;color:#6b625e;font-size:24rpx}.complete .number{background:#76bf8b;color:#fff}.step-copy{flex:1}.step-action{color:#443735;font-size:26rpx;line-height:1.55}.step-meta{margin-top:6rpx;color:#857b78;font-size:22rpx}.restart,.retry{margin-top:24rpx;border:1rpx solid #d9c8ba;border-radius:999rpx;background:#fffdf9;color:#5d4037;font-size:24rpx}.restart{width:100%}.loading{text-align:center;padding:40rpx;color:#5d8bc8}.error{margin-top:20rpx;color:#c45555}.retry{display:block;margin-top:16rpx;color:#4d83b8}
</style>
