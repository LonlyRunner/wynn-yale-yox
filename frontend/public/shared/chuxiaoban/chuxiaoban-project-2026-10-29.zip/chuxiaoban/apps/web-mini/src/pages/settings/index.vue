<script setup lang="ts">
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'

const cleared = ref(false)
const clearLocal = () => {
  uni.showModal({ title: '清除本机数据？', content: '只会移除本机游客令牌、设备标识和同步游标，不会删除云端数据。', success: ({ confirm }) => {
    if (!confirm) return
    ;['cxb_access_token', 'cxb_refresh_token', 'cxb_device_public_id', 'cxb_sync_cursor'].forEach(key => uni.removeStorageSync(key))
    cleared.value = true
  } })
}
const goSync = () => uni.navigateTo({ url: '/pages/sync/index' })
const goLogin = () => uni.navigateTo({ url: '/pages/login/index' })
onLoad(() => { cleared.value = false })
</script>

<template>
  <view class="page">
    <view class="hero"><text class="title">设置与隐私</text><text class="subtitle">你可以随时查看数据范围，并分别清除本机或云端数据。</text></view>
    <view class="card"><text class="card-title">数据说明</text><view class="item"><text class="label">图片</text><text class="value">上传到配置的 AI 服务用于识别；服务端对象默认保存 24 小时，访问使用临时签名地址。</text></view><view class="item"><text class="label">食材与反馈</text><text class="value">保存于当前游客同步空间，用于推荐、菜谱和最近记录。</text></view><view class="item"><text class="label">身份信息</text><text class="value">使用随机设备标识和匿名令牌，不建立手机号或微信账号资料。</text></view><view class="item"><text class="label">安全边界</text><text class="value">AI 内容仅供烹饪参考；涉及刀具、热油、燃气、生食和宝宝餐时，请以页面安全提示和专业规范为准。</text></view></view>
    <view class="card"><text class="card-title">账号与同步</text><text class="tip">绑定账号后可在更多设备上恢复当前同步空间。</text><button class="primary" @click="goLogin">登录或注册</button><button class="primary" @click="goSync">管理多端同步</button><button class="local" @click="clearLocal">清除本机数据</button><text v-if="cleared" class="success">本机数据已清除，下次操作会重新生成游客身份。</text></view>
  </view>
</template>

<style scoped lang="scss">
.page{min-height:100vh;padding:32rpx;background:#fff8f0}.hero,.card{padding:28rpx;border-radius:28rpx;background:rgba(255,255,255,.92);box-shadow:0 12rpx 40rpx rgba(93,64,55,.08)}.card{margin-top:20rpx}.title,.subtitle,.card-title,.tip,.label,.value,.success{display:block}.title{font-size:40rpx;font-weight:600}.subtitle{margin-top:10rpx;color:#857b78;font-size:25rpx;line-height:1.6}.card-title{font-size:29rpx;font-weight:600}.item{padding:18rpx 0;border-bottom:1rpx solid #eadfd6}.item:last-child{border-bottom:0}.label{font-size:25rpx;font-weight:600;color:#5d514c}.value{margin-top:8rpx;color:#857b78;font-size:23rpx;line-height:1.6}.tip{margin-top:10rpx;color:#857b78;font-size:24rpx;line-height:1.6}.primary,.local{width:100%;margin-top:22rpx;border-radius:999rpx;padding:18rpx;border:0;font-size:26rpx}.primary{background:linear-gradient(100deg,#89f7fe,#66a6ff);color:#fff}.local{background:#fffdf9;border:1rpx solid #e4b5aa;color:#ba685a}.success{margin-top:18rpx;padding:16rpx;border-radius:14rpx;background:#edf8ee;color:#39865a;font-size:23rpx}
</style>
