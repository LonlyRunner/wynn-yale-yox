/// <reference types="@dcloudio/types" />
declare module '*.vue'
declare module 'uview-plus' {
  import type { Plugin } from 'vue'
  const plugin: Plugin
  export default plugin
}
interface ImportMetaEnv { readonly VITE_API_BASE_URL?: string }
interface ImportMeta { readonly env: ImportMetaEnv }
