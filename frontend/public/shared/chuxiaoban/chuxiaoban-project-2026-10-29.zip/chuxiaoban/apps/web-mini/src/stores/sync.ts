import { defineStore } from 'pinia'
import { request } from '@/api/http'

export interface SyncChange { entity_type: string; entity_id: string; action: string; updated_at: string }
export interface SyncEntityDetail { entity_type: string; entity_id: string; payload: Record<string, unknown> }

const cursorKey = 'cxb_sync_cursor'

export const useSyncStore = defineStore('sync', {
  state: () => ({
    changes: [] as SyncChange[],
    details: {} as Record<string, SyncEntityDetail>,
    cursor: '',
    notice: '',
    polling: false,
    timer: undefined as ReturnType<typeof setInterval> | undefined,
    refreshing: false,
    ready: false,
  }),
  actions: {
    async refresh() {
      if (this.refreshing || !uni.getStorageSync('cxb_access_token')) return
      this.refreshing = true
      try {
        const since = this.cursor ? `?since=${encodeURIComponent(new Date(Math.max(0, Date.parse(this.cursor) - 1000)).toISOString())}&limit=50` : '?limit=50'
        const result = await request<SyncChange[]>({ url: `/api/v1/sync/changes${since}`, method: 'GET' })
        const incoming = result.data || []
        const known = new Set(this.changes.map(item => `${item.entity_type}:${item.entity_id}:${item.updated_at}`))
        const fresh = incoming.filter(item => !known.has(`${item.entity_type}:${item.entity_id}:${item.updated_at}`))
        await Promise.all(fresh.slice(0, 10).map(async item => {
          try {
            const detail = await request<SyncEntityDetail>({ url: `/api/v1/sync/changes/${item.entity_type}/${item.entity_id}`, method: 'GET' })
            this.details[`${item.entity_type}:${item.entity_id}`] = detail.data
          } catch { /* 单条详情失败不影响游标和其他实体 */ }
        }))
        if (this.ready && fresh.length) this.notice = `检测到 ${fresh.length} 条跨设备更新，请打开对应页面查看最新内容`
        this.changes = [...fresh, ...this.changes].sort((a, b) => Date.parse(b.updated_at) - Date.parse(a.updated_at)).slice(0, 50)
        const latest = this.changes[0]?.updated_at
        if (latest) { this.cursor = latest; uni.setStorageSync(cursorKey, latest) }
        this.ready = true
      } catch { /* 页面请求失败时保留本地游标，下一轮继续尝试 */ }
      finally { this.refreshing = false }
    },
    startPolling() {
      if (this.polling) return
      this.cursor = uni.getStorageSync(cursorKey) || ''
      this.polling = true
      void this.refresh()
      this.timer = setInterval(() => { void this.refresh() }, 15000)
    },
    stopPolling() {
      if (this.timer) clearInterval(this.timer)
      this.timer = undefined
      this.polling = false
    },
    clearNotice() { this.notice = '' },
  },
})
