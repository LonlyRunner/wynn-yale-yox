import { defineStore } from 'pinia'
import { request } from '@/api/http'

interface GuestData { access_token: string; refresh_token: string; expires_in: number }

export const useGuestStore = defineStore('guest', {
  state: () => ({ initialized: false, initializing: false, error: '' }),
  actions: {
    async initialize() {
      if (this.initializing) return
      const existingToken = uni.getStorageSync('cxb_access_token')
      if (existingToken) {
        try {
          // Do not trust a token left in local storage: it may have expired,
          // been revoked after an account merge, or belong to an old server.
          await request({ url: '/api/v1/sync/status', method: 'GET' })
          this.initialized = true
          return
        } catch {
          uni.removeStorageSync('cxb_access_token')
          uni.removeStorageSync('cxb_refresh_token')
        }
      }
      // A previous request may have cleared a revoked token while this store
      // was still marked initialized. Allow a fresh guest session to start.
      this.initialized = false
      this.initializing = true
      this.error = ''
      try {
        const devicePublicId = uni.getStorageSync('cxb_device_public_id') || `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 14)}`
        uni.setStorageSync('cxb_device_public_id', devicePublicId)
        const response = await request<GuestData>({
          url: '/api/v1/sync/guest/init',
          method: 'POST',
          data: { device_public_id: devicePublicId },
        })
        uni.setStorageSync('cxb_access_token', response.data.access_token)
        uni.setStorageSync('cxb_refresh_token', response.data.refresh_token)
        this.initialized = true
      } catch (error) {
        this.error = error instanceof Error ? error.message : '匿名身份初始化失败'
      } finally { this.initializing = false }
    },
  },
})
