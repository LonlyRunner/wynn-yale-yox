<script setup lang="ts">
defineProps<{ number: number; action: string; duration?: number; heat?: string; done?: boolean }>()
defineEmits<{ start: []; done: [] }>()
</script>
<template><view class="step" :class="{done}"><text class="number">{{done?'✓':number}}</text><view class="copy"><text class="action">{{action}}</text><text class="meta">{{heat||'按实际火力'}} · {{duration||0}} 分钟</text></view><button @click="$emit('start')">计时</button></view></template>
<style scoped lang="scss">.step{display:flex;align-items:center;gap:14rpx;padding:18rpx 0}.number{display:flex;width:48rpx;height:48rpx;align-items:center;justify-content:center;border-radius:50%;background:#eadfd6}.done .number{background:#76bf8b;color:#fff}.copy{flex:1}.action,.meta{display:block}.action{font-size:25rpx}.meta{margin-top:6rpx;color:#857b78;font-size:21rpx}.step button{border:0;background:#edf6ff;color:#4d83b8;font-size:21rpx}</style>
