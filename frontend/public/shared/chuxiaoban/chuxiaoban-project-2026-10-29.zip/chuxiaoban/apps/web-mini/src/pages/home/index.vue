<script setup lang="ts">
import { ref } from 'vue'
import { onShow } from '@dcloudio/uni-app'
import { request } from '@/api/http'
interface CookingRecord { id: string; recipe_id: string; dish_name: string; rating: number; actual_minutes: number; created_at: string }
const records = ref<CookingRecord[]>([])
const goRecognition = () => uni.switchTab({ url: '/pages/recognition/index' })
const goSync = () => uni.navigateTo({ url: '/pages/sync/index' })
const goSettings = () => uni.switchTab({ url: '/pages/settings/index' })
const goShopping = () => uni.navigateTo({ url: '/pages/shopping/index' })
const goMenu = () => uni.navigateTo({ url: '/pages/family-menu/index' })
const goOrder = () => uni.navigateTo({ url: '/pages/order/index' })
const goAdmin = () => uni.navigateTo({ url: '/pages/household-admin/index' })
const goPlan = () => uni.navigateTo({ url: '/pages/cooking-plan/index' })
const goKnowledge = () => uni.switchTab({ url: '/pages/knowledge/index' })
const goVideo = () => uni.navigateTo({ url: '/pages/video/index' })
const goNotifications = () => uni.navigateTo({ url: '/pages/notifications/index' })
const loadRecent = async () => { try { const result = await request<{ items: CookingRecord[] }>({ url: '/api/v1/knowledge/recent?limit=3', method: 'GET' }); records.value = result.data.items } catch {} }
onShow(() => { void loadRecent() })
</script>

<template>
  <view class="page">
    <view class="hero">
      <view class="app-brand"><image class="app-logo" src="/static/logo.svg" mode="aspectFit" /><text class="eyebrow">厨小伴 · AI 厨房助手</text></view>
      <text class="title">今天，用现有食材做点什么？</text>
      <text class="subtitle">拍一张照片，先确认食材，再获得三道安心推荐。</text>
      <up-button type="primary" shape="circle" text="拍照识别食材" @click="goRecognition" />
      <up-button class="sync-button" type="default" shape="circle" text="多端同步" @click="goSync" />
      <text class="settings-link" @click="goSettings">设置与隐私</text>
      <view class="planning-links"><text @click="goOrder">我要点菜</text><text @click="goAdmin">家庭管理</text><text @click="goMenu">家庭菜单</text></view><view class="planning-links"><text @click="goShopping">购物清单</text><text @click="goPlan">制作计划</text><text @click="goKnowledge">知识搜索</text></view><view class="planning-links"><text @click="goVideo">视频内容</text><text @click="goNotifications">消息通知</text></view>
    </view>
    <view class="recent"><view class="recent-head"><text class="status-title">最近做过</text><text class="more-link" @click="goKnowledge">查看全部</text></view><view v-if="records.length"><view v-for="record in records" :key="record.id" class="recent-row" @click="goKnowledge"><view><text class="dish">{{ record.dish_name }}</text><text class="status-text">{{ record.actual_minutes }} 分钟 · {{ new Date(record.created_at).toLocaleDateString() }}</text></view><text class="stars">{{ '★'.repeat(record.rating) }}</text></view></view><view v-else class="empty-recent"><text class="status-text">完成一道菜后，评分和心得会显示在这里。</text></view></view>
  </view>
</template>

<style scoped lang="scss">
.page { padding: 48rpx 32rpx; }
.hero { padding: 48rpx; border-radius: 40rpx; background: rgba(255,255,255,.9); box-shadow: 0 16rpx 48rpx rgba(93,64,55,.08); }
.eyebrow, .title, .subtitle, .status-title, .status-text { display: block; }
.eyebrow { color: #5d4037; font-size: 24rpx; }
.title { margin: 20rpx 0; font-size: 52rpx; font-weight: 600; line-height: 1.35; }
.subtitle { margin-bottom: 40rpx; color: #675f5a; font-size: 28rpx; line-height: 1.7; }
.recent { margin-top: 32rpx; padding: 30rpx; border: 2rpx solid rgba(93,64,55,.08); border-radius: 28rpx; background: rgba(255,255,255,.7); }
.settings-link{display:block;margin-top:20rpx;text-align:center;color:#4d83b8;font-size:24rpx}
.planning-links{display:flex;justify-content:space-between;gap:12rpx;margin-top:24rpx}.planning-links text{flex:1;padding:14rpx 8rpx;border-radius:16rpx;background:#fff4e8;color:#9a6c36;text-align:center;font-size:22rpx}
.recent-head,.recent-row { display:flex; align-items:center; justify-content:space-between; }.more-link{color:#4d83b8;font-size:24rpx}.recent-row{padding:20rpx 0;border-bottom:1rpx solid #eadfd6}.recent-row:last-child{border-bottom:0}.dish{display:block;font-size:27rpx;font-weight:600}.stars{color:#e7ad49;font-size:25rpx}.empty-recent{padding:26rpx 0 4rpx}
.status-title { font-weight: 600; }
.status-text { margin-top: 12rpx; color: #675f5a; font-size: 26rpx; }
.app-brand{display:flex;align-items:center;gap:16rpx}.app-logo{width:72rpx;height:72rpx;padding:8rpx;border-radius:22rpx;background:#fff7e8;box-shadow:0 6rpx 16rpx rgba(93,64,55,.1)}.app-brand .eyebrow{font-size:25rpx;font-weight:600;color:#5d4037}
</style>
