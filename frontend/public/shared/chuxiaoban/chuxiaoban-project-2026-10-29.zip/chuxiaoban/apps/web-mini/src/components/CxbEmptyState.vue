<script setup lang="ts">
withDefaults(defineProps<{ title?: string; tip?: string }>(), { title: '这里还没有内容', tip: '完成一次操作后会显示在这里' })
</script>
<template><view class="empty"><text class="icon">🍲</text><text class="title">{{title}}</text><text class="tip">{{tip}}</text><slot /></view></template>
<style scoped lang="scss">.empty{padding:48rpx 20rpx;text-align:center}.icon{display:block;font-size:64rpx}.title,.tip{display:block}.title{margin-top:14rpx;font-size:28rpx;font-weight:600}.tip{margin-top:8rpx;color:#857b78;font-size:23rpx}</style>
