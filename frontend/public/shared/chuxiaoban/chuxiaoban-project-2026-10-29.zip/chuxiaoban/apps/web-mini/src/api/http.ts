export interface ApiResponse<T> {
  code: string
  message: string
  data: T
  request_id: string
}

// Keep the H5 development client aligned with the backend port used by
// scripts/run-server.ps1. Deployments can still override this via VITE_API_BASE_URL.
const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8081'
const randomId = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`
const idempotencyKey = () => globalThis.crypto?.randomUUID?.() || `${randomId()}-${randomId()}`

export function request<T>(options: UniApp.RequestOptions): Promise<ApiResponse<T>> {
  const token = uni.getStorageSync('cxb_access_token')
  const headers = { ...(options.header || {}) } as Record<string, string>
  if (token) headers.Authorization = `Bearer ${token}`
  headers['X-Request-Id'] = randomId()
  if (options.method && ['POST', 'PUT', 'PATCH', 'DELETE'].includes(options.method)) headers['Idempotency-Key'] = idempotencyKey()
  return new Promise((resolve, reject) => {
    uni.request({
      ...options,
      url: `${API_BASE_URL}${options.url}`,
      header: headers,
      success: (result) => {
        const body = result.data as ApiResponse<T>
        if (result.statusCode >= 200 && result.statusCode < 300) resolve(body)
        else {
          // A guest token can be revoked when devices are merged/unbound or
          // after a server restart. Clear it so the next app action can issue
          // a fresh anonymous session instead of repeating 401s forever.
          if (result.statusCode === 401) {
            uni.removeStorageSync('cxb_access_token')
            uni.removeStorageSync('cxb_refresh_token')
          }
          reject(new Error(body?.message || `请求失败 (${result.statusCode})`))
        }
      },
      fail: reject,
    })
  })
}

export function uploadImage(filePath: string, note?: string) {
  const token = uni.getStorageSync('cxb_access_token')
  return new Promise<ApiResponse<unknown>>((resolve, reject) => {
    uni.uploadFile({
      url: `${API_BASE_URL}/api/v1/recognition/upload`,
      filePath,
      name: 'image',
      formData: note ? { note } : {},
    header: { ...(token ? { Authorization: `Bearer ${token}` } : {}), 'Idempotency-Key': idempotencyKey(), 'X-Request-Id': randomId() },
      success: (result) => {
        try {
          const body = JSON.parse(result.data) as ApiResponse<unknown>
          if (result.statusCode >= 200 && result.statusCode < 300) resolve(body)
          else {
            if (result.statusCode === 401) {
              uni.removeStorageSync('cxb_access_token')
              uni.removeStorageSync('cxb_refresh_token')
            }
            reject(new Error(body.message || `图片识别失败 (${result.statusCode})`))
          }
        } catch { reject(new Error('服务器返回格式错误')) }
      },
      fail: reject,
    })
  })
}
