<script setup lang="ts">
withDefaults(defineProps<{ emoji?: string }>(), { emoji: '👨‍🍳' })
</script>
<template><view class="avatar">{{emoji}}</view></template>
<style scoped lang="scss">.avatar{display:flex;width:76rpx;height:76rpx;align-items:center;justify-content:center;border-radius:50%;background:#fff1db;font-size:42rpx}</style>
