<script setup lang="ts">
import { ref } from 'vue'
import { onLoad } from '@dcloudio/uni-app'
import { request, uploadImage } from '@/api/http'
import { useGuestStore } from '@/stores/guest'

interface RecognizedItem { id: string; name: string; quantity: string | null; category: string; confidence: number; needs_confirmation: boolean; possible_allergens: string[] }
interface RecognitionResult { task_id: string; status: string; updated_at: string; items: RecognizedItem[]; preview_url: string; overall_confidence?: number; uncertain_items?: string[]; suggestions?: string }

const loading = ref(false)
const error = ref('')
const taskId = ref('')
const expectedUpdatedAt = ref('')
const imagePath = ref('')
const items = ref<RecognizedItem[]>([])
const recognitionTip = ref('')
const manualName = ref('')
const manualQuantity = ref('')
const editing = ref(false)
interface ChatMessage { role: 'user' | 'assistant'; text: string }
const chatInput = ref('')
const chatLoading = ref(false)
const chatMessages = ref<ChatMessage[]>([{ role: 'assistant', text: '你好！可以拍照识别食材，也可以直接问我菜品做法、火候和厨房安全。' }])
const guestStore = useGuestStore()
const newUuid = () => globalThis.crypto?.randomUUID?.() || `00000000-0000-4000-8000-${Date.now().toString(16).padStart(12, '0')}`
const addManual = () => {
  const name = manualName.value.trim()
  if (!name) return
  items.value.push({ id: newUuid(), name, quantity: manualQuantity.value.trim() || null, category: 'manual', confidence: 1, needs_confirmation: false, possible_allergens: [] })
  manualName.value = ''
  manualQuantity.value = ''
}
const chooseImage = () => {
  uni.chooseImage({ count: 1, sizeType: ['compressed'], sourceType: ['album', 'camera'], success: async ({ tempFilePaths }) => {
    const manuallyAdded = items.value.filter(item => item.category === 'manual')
    imagePath.value = tempFilePaths[0]
    taskId.value = ''
    items.value = manuallyAdded
    await ensureGuest()
    await recognize()
  } })
}
const ensureGuest = async () => {
  if (!uni.getStorageSync('cxb_access_token')) await guestStore.initialize()
  if (!uni.getStorageSync('cxb_access_token')) throw new Error(guestStore.error || '游客身份初始化失败，请刷新页面后重试')
}
const recognize = async () => {
  if (!imagePath.value) return
  loading.value = true; error.value = ''
  try {
    await ensureGuest()
    const result = await uploadImage(imagePath.value) as { data: RecognitionResult }
    taskId.value = result.data.task_id
    expectedUpdatedAt.value = result.data.updated_at
    recognitionTip.value = result.data.suggestions || ''
    const manuallyAdded = items.value.filter(item => item.category === 'manual')
    items.value = [...result.data.items, ...manuallyAdded]
  } catch (e) { error.value = e instanceof Error ? e.message : '识别失败，请重试' }
  finally { loading.value = false }
}
const confirm = async () => {
  if (!taskId.value) { error.value = '识别任务尚未建立，请重新选择图片'; return }
  if (items.value.length === 0) { error.value = '请至少添加或保留一项食材'; return }
  loading.value = true; error.value = ''
  try {
    const ingredients = items.value.map((item, index) => ({
      source_item_id: item.id,
      name: item.name.trim(),
      quantity: item.quantity,
      allergen_codes: item.possible_allergens || [],
    })).filter(item => item.name)
    await request({ url: `/api/v1/recognition/${taskId.value}/confirm`, method: 'PUT', data: { ingredients, expected_updated_at: expectedUpdatedAt.value || undefined } })
    uni.navigateTo({ url: `/pages/recommendation/index?taskId=${taskId.value}` })
  } catch (e) { error.value = e instanceof Error ? e.message : '确认失败，请重试' }
  finally { loading.value = false }
}
const remove = (index: number) => items.value.splice(index, 1)
const sendChat = async () => {
  const message = chatInput.value.trim()
  if (!message || chatLoading.value) return
  chatInput.value = ''
  chatMessages.value.push({ role: 'user', text: message })
  chatLoading.value = true
  try {
    await ensureGuest()
    const context = items.value.filter(item => item.name.trim()).map(item => item.name.trim()).join('、')
    const result = await request<{ reply: string; suggestions: string[] }>({ url: '/api/v1/chat', method: 'POST', data: { message, context } })
    chatMessages.value.push({ role: 'assistant', text: result.data.reply })
  } catch (e) {
    chatMessages.value.push({ role: 'assistant', text: e instanceof Error ? e.message : '暂时无法回答，请稍后再试' })
  } finally { chatLoading.value = false }
}
const askQuick = (message: string) => { chatInput.value = message; void sendChat() }
onLoad(() => { if (!uni.getStorageSync('cxb_access_token')) uni.showToast({ title: '正在初始化游客身份', icon: 'none' }) })
</script>

<template>
  <view class="page">
    <view class="hero"><view class="brand-row"><view><view class="app-brand-mini"><image class="app-logo-mini" src="/static/logo.svg" mode="aspectFit" /><text class="eyebrow"><text class="brand-icon">✦</text> 厨小伴 · 厨房灵感</text></view><text class="title">今天，想吃点什么？</text><text class="subtitle">拍一张食材，或直接问我。一起把一餐变得简单。</text></view><view class="hero-art"><text>🥣</text><view class="spark spark-a">✦</view><view class="spark spark-b">✦</view></view></view><view class="hero-chips"><text>识别食材</text><text>智能排菜</text><text>安全提醒</text></view></view>
    <view v-if="!imagePath" class="upload-box" @click="chooseImage"><text class="upload-icon">📷</text><text class="upload-title">拍照或从相册选择</text><text class="upload-tip">支持 JPG、PNG、WebP，最大 10MB</text></view>
    <view v-else class="preview"><image :src="imagePath" mode="aspectFill" /><button class="retake" @click="chooseImage">重拍</button></view>
    <view v-if="loading" class="loading"><text>正在翻阅食材图谱…</text></view>
    <view v-if="imagePath && !loading && !items.length" class="empty-result"><text>暂时没有识别出明确食材</text><text class="empty-tip">点击右下角“管理食材”补录后即可继续推荐。</text><button v-if="taskId" class="retry" :disabled="loading" @click="recognize">重新识别</button></view>
    <view v-if="editing" class="editor"><text class="section-title">补录食材</text><text class="empty-tip">可添加未识别的食材，并修改每项数量。{{ imagePath ? '' : '可先添加，选择图片后会合并到识别结果。' }}</text><view class="manual-row"><input v-model="manualName" placeholder="食材名称，如西红柿" @confirm="addManual" /><input v-model="manualQuantity" class="quantity-input" placeholder="数量，如 2个" @confirm="addManual" /><button @click="addManual">添加</button></view></view>
    <view v-if="recognitionTip" class="recognition-tip">{{ recognitionTip }}</view><view v-if="items.length" class="result"><view class="result-head"><text class="section-title">确认食材</text><text class="pending">{{items.filter(item => item.needs_confirmation).length}} 项待确认</text></view><view v-for="(item,index) in items" :key="`${item.name}-${index}`" class="ingredient"><view><input v-model="item.name" :disabled="!editing" /><input v-if="editing" v-model="item.quantity" class="item-quantity" placeholder="数量，如 2个" /><text v-else>{{item.quantity || '数量待补充'}} · 置信度 {{item.confidence.toFixed(2)}}</text></view><button v-if="editing" @click="remove(index)">删除</button></view></view>
    <view v-if="!imagePath" class="quick-prompts"><view class="section-title">也可以直接问</view><view class="prompt-grid"><button @click="askQuick('鸡蛋怎么做更下饭？')">🍳 鸡蛋怎么做</button><button @click="askQuick('今天晚餐推荐什么？')">🍲 今天吃什么</button><button @click="askQuick('油锅起火怎么办？')">⚠️ 厨房安全</button></view></view>
    <button v-if="imagePath && !loading && taskId" class="primary" :disabled="loading" @click="confirm">确认并开始推荐　→</button>
    <button class="floating-edit" :disabled="loading" @click="editing = !editing">{{ editing ? '完成编辑' : '管理食材' }}</button>
    <view class="chat-panel"><scroll-view class="chat-history" scroll-y><view v-for="(message, index) in chatMessages" :key="index" class="chat-line" :class="message.role"><text>{{ message.text }}</text></view><text v-if="chatLoading" class="chat-thinking">正在思考…</text></scroll-view><view class="chat-input-row"><input v-model="chatInput" class="chat-input" maxlength="1000" placeholder="问问菜品做法、火候或安全问题" confirm-type="send" @confirm="sendChat" /><button class="chat-send" :disabled="chatLoading || !chatInput.trim()" @click="sendChat">发送</button></view></view>
    <view v-if="error" class="error">{{error}}</view>
  </view>
</template>

<style scoped lang="scss">
.page{padding:32rpx 32rpx 140rpx;background:#fff8f0;min-height:100vh}.hero,.upload-box,.preview,.result,.empty-result,.editor{padding:28rpx;border-radius:28rpx;background:rgba(255,255,255,.9);box-shadow:0 12rpx 40rpx rgba(93,64,55,.08)}.title,.subtitle,.upload-title,.upload-tip,.section-title,.empty-tip{display:block}.title{font-size:40rpx;font-weight:600}.subtitle,.upload-tip,.ingredient text{margin-top:10rpx;color:#857b78;font-size:25rpx}.upload-box{margin-top:24rpx;height:360rpx;display:flex;flex-direction:column;justify-content:center;align-items:center;border:2rpx dashed #d8c7ba}.upload-icon{font-size:74rpx}.upload-title{margin-top:18rpx;font-size:30rpx;font-weight:600}.preview{margin-top:24rpx;position:relative}.preview image{width:100%;height:360rpx;border-radius:20rpx}.retake{position:absolute;right:44rpx;bottom:44rpx;padding:10rpx 18rpx;border:0;border-radius:999rpx;background:rgba(255,255,255,.9);font-size:24rpx}.loading{margin:24rpx 0;padding:20rpx;text-align:center;color:#5d8bc8}.empty-result,.editor{margin-top:24rpx}.empty-result>text:first-child{display:block;font-size:28rpx;font-weight:600}.empty-tip{margin-top:10rpx;color:#857b78;font-size:24rpx}.manual-row{display:flex;gap:12rpx;margin-top:20rpx}.manual-row input{min-width:0;flex:1;padding:14rpx 18rpx;border:1rpx solid #eadfd6;border-radius:999rpx;background:#fff}.manual-row .quantity-input{flex:.75}.manual-row button{padding:0 24rpx;border:0;border-radius:999rpx;background:#5d8bc8;color:#fff;font-size:24rpx}.result{margin-top:24rpx}.result-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:16rpx}.pending{color:#b7672f;font-size:23rpx}.ingredient{display:flex;justify-content:space-between;align-items:center;padding:18rpx 0;border-bottom:1rpx solid #eadfd6}.ingredient input{font-size:29rpx;font-weight:600}.ingredient input:disabled{color:#1a1a2e;background:transparent}.item-quantity{display:block;width:230rpx;margin-top:10rpx;padding:8rpx 12rpx;border:1rpx solid #eadfd6;border-radius:12rpx;background:#fff;font-size:24rpx}.ingredient button{border:0;background:transparent;color:#d96e6e;font-size:23rpx}.primary{width:100%;margin-top:24rpx;border:0;border-radius:999rpx;padding:20rpx;color:#fff;background:linear-gradient(100deg,#89f7fe,#66a6ff);font-size:28rpx}.floating-edit{position:fixed;right:32rpx;bottom:36rpx;z-index:10;padding:18rpx 30rpx;border:0;border-radius:999rpx;background:#5d8bc8;color:#fff;box-shadow:0 10rpx 28rpx rgba(57,100,154,.3);font-size:26rpx}.retry{margin-top:18rpx;border:1rpx solid #c6d8ed;border-radius:999rpx;background:#f6fbff;color:#4d83b8;font-size:24rpx}.error{margin-top:20rpx;padding:18rpx;border-radius:16rpx;background:#fff0ef;color:#c45555;font-size:24rpx}
/* Keep the persistent editor action above the bottom TabBar on phones. */
.page { padding-bottom: 500rpx; }
.floating-edit { bottom: 455rpx; z-index: 100; }
.chat-panel { position: fixed; left: 20rpx; right: 20rpx; bottom: 125rpx; z-index: 90; padding: 14rpx 16rpx; border: 1rpx solid #dbe8f5; border-radius: 24rpx; background: rgba(255,255,255,.98); box-shadow: 0 8rpx 28rpx rgba(57,100,154,.18); }
.chat-history { min-height: 92rpx; max-height: 280rpx; padding: 8rpx 8rpx 10rpx; border-radius: 18rpx; background: #f7fbff; }
.chat-line { display: flex; margin: 6rpx 0; font-size: 23rpx; line-height: 1.45; }
.chat-line text { max-width: 86%; padding: 10rpx 14rpx; border-radius: 16rpx; background: #f2f6fb; color: #3d4e61; }
.chat-line.user { justify-content: flex-end; }
.chat-line.user text { background: #5d8bc8; color: #fff; }
.chat-thinking { display: block; padding: 6rpx 12rpx; color: #8a9bad; font-size: 21rpx; }
.chat-input-row { display: flex; gap: 10rpx; align-items: center; margin-top: 8rpx; }
.chat-input { flex: 1; min-width: 0; height: 68rpx; padding: 0 18rpx; border: 1rpx solid #dce6ef; border-radius: 999rpx; background: #f9fbfd; font-size: 24rpx; }
.chat-send { flex: 0 0 auto; padding: 0 24rpx; height: 68rpx; border: 0; border-radius: 999rpx; background: #5d8bc8; color: #fff; font-size: 24rpx; }
.hero { position: relative; overflow: hidden; padding: 34rpx 30rpx 28rpx; background: linear-gradient(135deg, #fffdf8 0%, #f0f8ff 100%); border: 1rpx solid rgba(255,255,255,.9); }
.hero::after { position: absolute; right: -70rpx; top: -90rpx; width: 250rpx; height: 250rpx; border-radius: 50%; background: rgba(137,247,254,.22); content: ''; }
.brand-row { position: relative; z-index: 1; display: flex; align-items: center; justify-content: space-between; gap: 14rpx; }
.eyebrow { display: block; color: #6c9bc6; font-size: 19rpx; letter-spacing: 2rpx; }
.brand-icon { display: inline-block; margin-right: 6rpx; color: #f0a25c; font-size: 23rpx; }
.app-brand-mini{display:flex;align-items:center;gap:10rpx}.app-logo-mini{width:46rpx;height:46rpx;padding:5rpx;border-radius:14rpx;background:#fff7e8}
.hero .title { margin-top: 12rpx; font-size: 42rpx; color: #2d4054; }
.hero .subtitle { max-width: 500rpx; line-height: 1.55; color: #71808f; }
.hero-art { position: relative; display: flex; align-items: center; justify-content: center; flex: 0 0 142rpx; width: 142rpx; height: 142rpx; border-radius: 44% 56% 52% 48%; background: linear-gradient(145deg, #d8f7ff, #fff1d7); box-shadow: inset -10rpx -12rpx 0 rgba(255,255,255,.55), 0 16rpx 28rpx rgba(101,146,177,.16); transform: rotate(7deg); }
.hero-art>text { font-size: 72rpx; transform: rotate(-7deg); }
.spark { position: absolute; color: #f0a25c; font-size: 26rpx; transform: rotate(-7deg); }.spark-a { right: 4rpx; top: 12rpx; }.spark-b { left: 10rpx; bottom: 10rpx; font-size: 18rpx; color: #73b6d9; }
.hero-chips { position: relative; z-index: 1; display: flex; gap: 12rpx; margin-top: 24rpx; }.hero-chips text { padding: 8rpx 16rpx; border-radius: 999rpx; background: rgba(255,255,255,.78); color: #6887a0; font-size: 21rpx; }
.quick-prompts { margin-top: 24rpx; padding: 24rpx 26rpx; border-radius: 26rpx; background: rgba(255,255,255,.78); box-shadow: 0 10rpx 28rpx rgba(93,64,55,.06); }.prompt-grid { display: grid; grid-template-columns: repeat(3,1fr); gap: 12rpx; margin-top: 16rpx; }.prompt-grid button { min-height: 76rpx; padding: 10rpx 6rpx; border: 1rpx solid #e5eef5; border-radius: 18rpx; background: #f8fbfe; color: #5d7185; font-size: 22rpx; }
</style>
