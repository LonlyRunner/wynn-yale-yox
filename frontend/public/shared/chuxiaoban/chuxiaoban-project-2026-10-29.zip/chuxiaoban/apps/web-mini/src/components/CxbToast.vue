<script setup lang="ts">
defineProps<{ message: string }>()
</script>
<template><view class="toast">{{message}}</view></template>
<style scoped lang="scss">.toast{position:fixed;left:50%;bottom:80rpx;z-index:20;transform:translateX(-50%);padding:16rpx 24rpx;border-radius:999rpx;background:rgba(40,35,32,.88);color:#fff;font-size:23rpx}</style>
