package cn.chuxiaoban.sync;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
@ConditionalOnProperty(name = "cxb.auth.enabled", havingValue = "true", matchIfMissing = true)
public class GuestAuthenticationFilter extends OncePerRequestFilter {
    public static final String SPACE_ID = GuestAuthenticationFilter.class.getName() + ".spaceId";
    public static final String DEVICE_ID = GuestAuthenticationFilter.class.getName() + ".deviceId";
    private final GuestTokenService tokens;
    private final JdbcTemplate jdbc;

    public GuestAuthenticationFilter(GuestTokenService tokens, JdbcTemplate jdbc) { this.tokens = tokens; this.jdbc = jdbc; }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {
        String path = request.getRequestURI();
        if (request.getMethod().equalsIgnoreCase("OPTIONS") || path.equals("/") || path.equals("/api/v1/sync/guest/init") || path.equals("/api/v1/sync/guest/refresh") || path.equals("/api/v1/auth/account/login") || path.startsWith("/actuator") || path.startsWith("/swagger-ui") || path.startsWith("/v3/api-docs")) {
            chain.doFilter(request, response);
            return;
        }
        String authorization = request.getHeader("Authorization");
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "guest token required");
            return;
        }
        try {
            var claims = tokens.verify(authorization.substring("Bearer ".length()).trim());
            Integer valid = jdbc.queryForObject("SELECT count(*) FROM guest_device gd JOIN sync_space ss ON ss.id=gd.sync_space_id WHERE gd.id=? AND gd.sync_space_id=? AND gd.token_version=? AND gd.revoked_at IS NULL AND ss.status='ACTIVE'", Integer.class, claims.deviceId(), claims.spaceId(), claims.tokenVersion());
            if (valid == null || valid != 1) { response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "guest token revoked"); return; }
            request.setAttribute(SPACE_ID, claims.spaceId());
            request.setAttribute(DEVICE_ID, claims.deviceId());
            chain.doFilter(request, response);
        } catch (IllegalArgumentException ex) {
            response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "invalid guest token");
        }
    }
}
