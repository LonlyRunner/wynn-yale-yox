package cn.chuxiaoban.ai;

import java.util.List;

public interface AiRecommendationClient {
    List<Recommendation> recommend(List<Ingredient> ingredients, Preferences preferences);

    record Ingredient(String name, String quantity, List<String> allergenCodes) {}
    record Preferences(List<String> flavors, List<String> allergenCodes, List<String> excludedIngredients, String variationHint) {}
    record Recommendation(String name, int difficulty, int prepMinutes, int cookMinutes,
                          List<RecommendationIngredient> ingredients, String reason, List<String> warnings) {}
    record RecommendationIngredient(String name, String amount, boolean available) {}
}
