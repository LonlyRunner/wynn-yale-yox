/** Ingredient image recognition and confirmation. */
package cn.chuxiaoban.recognition;
