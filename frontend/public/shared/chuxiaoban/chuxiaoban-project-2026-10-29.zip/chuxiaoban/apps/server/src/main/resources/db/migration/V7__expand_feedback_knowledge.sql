ALTER TABLE cooking_feedback
    ADD COLUMN improvements VARCHAR(2000),
    ADD COLUMN failures VARCHAR(2000),
    ADD COLUMN family_feedback VARCHAR(2000),
    ADD COLUMN auto_tags_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN ai_suggestion VARCHAR(2000);
