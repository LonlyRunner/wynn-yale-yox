package cn.chuxiaoban.knowledge;

import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.UUID;

@Service
public class CookingFeedbackService {
    private final JdbcTemplate jdbc;
    public CookingFeedbackService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public FeedbackData create(UUID spaceId, FeedbackRequest request) {
        Integer owned = jdbc.queryForObject("SELECT count(*) FROM recipe r JOIN recommended_dish d ON d.id=r.recommended_dish_id JOIN recommendation_batch b ON b.id=d.batch_id WHERE r.id=? AND b.sync_space_id=?", Integer.class, request.recipeId(), spaceId);
        if (owned == null || owned != 1) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "菜谱不存在");
        UUID id = UUID.randomUUID();
        jdbc.update("INSERT INTO cooking_feedback(id,sync_space_id,recipe_id,rating,actual_minutes,notes,improvements,failures,family_feedback,auto_tags_json,ai_suggestion) VALUES (?,?,?,?,?,?,?,?,?,?::jsonb,?)", id, spaceId, request.recipeId(), request.rating(), request.actualMinutes(), request.notes(), request.improvements(), request.failures(), request.familyFeedback(), request.autoTags() == null ? "[]" : new com.fasterxml.jackson.databind.ObjectMapper().valueToTree(request.autoTags()).toString(), request.aiSuggestion());
        return new FeedbackData(id, request.recipeId(), request.rating(), request.actualMinutes(), request.notes(), 1L, Instant.now());
    }

    public FeedbackData update(UUID spaceId, UUID feedbackId, long expectedVersion, Integer rating, Integer actualMinutes, String notes) {
        int updated = jdbc.update("UPDATE cooking_feedback SET rating=?,actual_minutes=?,notes=?,version=version+1,updated_at=now() WHERE id=? AND sync_space_id=? AND deleted_at IS NULL AND version=?", rating, actualMinutes, notes, feedbackId, spaceId, expectedVersion);
        if (updated == 0) {
            Integer exists = jdbc.queryForObject("SELECT count(*) FROM cooking_feedback WHERE id=? AND sync_space_id=? AND deleted_at IS NULL", Integer.class, feedbackId, spaceId);
            throw new BusinessException(exists != null && exists == 1 ? ErrorCode.CONFLICT : ErrorCode.NOT_FOUND, exists != null && exists == 1 ? HttpStatus.CONFLICT : HttpStatus.NOT_FOUND, exists != null && exists == 1 ? "反馈已在另一端更新，请刷新后再试" : "反馈不存在");
        }
        return jdbc.queryForObject("SELECT id,recipe_id,rating,actual_minutes,notes,version,created_at FROM cooking_feedback WHERE id=?", (rs, row) -> new FeedbackData(rs.getObject(1, UUID.class), rs.getObject(2, UUID.class), rs.getInt(3), rs.getInt(4), rs.getString(5), rs.getLong(6), rs.getTimestamp(7).toInstant()), feedbackId);
    }

    public record FeedbackRequest(UUID recipeId, Integer rating, Integer actualMinutes, String notes, String improvements, String failures, String familyFeedback, java.util.List<String> autoTags, String aiSuggestion) {}
    public record FeedbackData(UUID id, UUID recipeId, int rating, int actualMinutes, String notes, long version, Instant createdAt) {}
}
