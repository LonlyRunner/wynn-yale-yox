package cn.chuxiaoban.knowledge;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Base64;
import java.util.List;
import java.util.UUID;

@Service
public class RecentCookingService {
    private final JdbcTemplate jdbc;
    public RecentCookingService(JdbcTemplate jdbc, ObjectMapper mapper) { this.jdbc = jdbc; }

    public RecentPage list(UUID spaceId, String cursor, int limit) {
        int offset = 0;
        try { if (cursor != null && !cursor.isBlank()) offset = Integer.parseInt(new String(Base64.getUrlDecoder().decode(cursor))); } catch (Exception ignored) { }
        int safeLimit = Math.max(1, Math.min(50, limit));
        List<CookingRecord> rows = jdbc.query("SELECT f.id,f.recipe_id,d.name,f.rating,f.actual_minutes,f.notes,f.created_at FROM cooking_feedback f JOIN recipe r ON r.id=f.recipe_id JOIN recommended_dish d ON d.id=r.recommended_dish_id WHERE f.sync_space_id=? AND f.deleted_at IS NULL ORDER BY f.created_at DESC LIMIT ? OFFSET ?", (rs, row) -> new CookingRecord(rs.getObject(1, UUID.class), rs.getObject(2, UUID.class), rs.getString(3), rs.getInt(4), rs.getInt(5), rs.getString(6), rs.getTimestamp(7).toInstant()), spaceId, safeLimit + 1, offset);
        String next = rows.size() > safeLimit ? Base64.getUrlEncoder().withoutPadding().encodeToString(String.valueOf(offset + safeLimit).getBytes()) : null;
        return new RecentPage(rows.stream().limit(safeLimit).toList(), next);
    }

    public record CookingRecord(UUID id, UUID recipeId, String dishName, int rating, int actualMinutes, String notes, Instant createdAt) {}
    public record RecentPage(List<CookingRecord> items, String nextCursor) {}
}
