package cn.chuxiaoban.recognition;

import cn.chuxiaoban.ai.AiRecognitionClient;
import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import cn.chuxiaoban.oss.ObjectStorage;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.List;
import java.util.ArrayList;
import java.util.UUID;

@Service
public class RecognitionService {
    private static final long MAX_BYTES = 10L * 1024 * 1024;
    private static final List<String> ALLOWED = List.of("image/jpeg", "image/png", "image/webp");
    private final JdbcTemplate jdbc;
    private final ObjectStorage storage;
    private final AiRecognitionClient ai;
    private final ObjectMapper mapper;

    public RecognitionService(JdbcTemplate jdbc, ObjectStorage storage, AiRecognitionClient ai, ObjectMapper mapper) {
        this.jdbc = jdbc; this.storage = storage; this.ai = ai; this.mapper = mapper;
    }

    @Transactional
    public RecognitionResult recognize(UUID spaceId, MultipartFile image, String note) {
        if (image == null) {
            throw new BusinessException(ErrorCode.INVALID_FILE, org.springframework.http.HttpStatus.UNSUPPORTED_MEDIA_TYPE, "图片为空或超过 10MB");
        }
        try {
            byte[] bytes = image.getBytes();
            String mime = normalizeContentType(image, bytes);
            validate(image, mime);
            String digest = sha256(bytes);
            UUID uploadId = UUID.randomUUID();
            String objectKey = "guest/" + spaceId + "/recognition/" + uploadId + extension(mime);
            try (InputStream input = image.getInputStream()) { storage.put(objectKey, input, bytes.length, mime); }
            jdbc.update("INSERT INTO upload_object(id,sync_space_id,object_key,mime_type,size_bytes,sha256,status,expires_at) VALUES (?,?,?,?,?,?,?,now()+interval '24 hours')",
                    uploadId, spaceId, objectKey, mime, bytes.length, digest, "ACTIVE");
            UUID taskId = UUID.randomUUID();
            jdbc.update("INSERT INTO recognition_task(id,sync_space_id,upload_object_id,status,schema_version,model_ref) VALUES (?,?,?,?,?,?)",
                    taskId, spaceId, uploadId, "PROCESSING", "1.0", "mock");
            List<AiRecognitionClient.RecognitionItem> items;
            try {
                items = ai.recognize(bytes, mime, note);
            } catch (IllegalStateException ex) {
                // Keep the persisted task available so the user can add ingredients manually.
                items = List.of();
            }
            var recognizedItems = new ArrayList<RecognizedItem>();
            for (var item : items) {
                UUID itemId = UUID.randomUUID();
                jdbc.update("INSERT INTO recognized_item(id,task_id,name,quantity_text,category,confidence,needs_confirmation,allergen_codes) VALUES (?,?,?,?,?,?,?,?::jsonb)",
                        itemId, taskId, item.name(), item.quantity(), item.category(), item.confidence(),
                        item.needsConfirmation() || item.confidence() < 0.75, json(item.possibleAllergens()));
                recognizedItems.add(new RecognizedItem(itemId, item.name(), item.quantity(), item.category(), item.confidence(),
                        item.needsConfirmation() || item.confidence() < 0.75, item.possibleAllergens()));
            }
            jdbc.update("UPDATE recognition_task SET status='AWAITING_CONFIRMATION',updated_at=now() WHERE id=?", taskId);
            var updatedAt = jdbc.queryForObject("SELECT updated_at FROM recognition_task WHERE id=?", java.sql.Timestamp.class, taskId).toInstant();
            double overall = recognizedItems.stream().mapToDouble(RecognizedItem::confidence).average().orElse(0d);
            List<String> uncertain = recognizedItems.stream().filter(item -> item.confidence() < 0.75d).map(item -> "可能是" + item.name() + "，请确认").toList();
            String suggestion = recognizedItems.isEmpty() ? "暂未识别到明确食材，可手动补录后继续" : "已识别 " + recognizedItems.size() + " 项食材，请确认名称和数量后再推荐";
            return new RecognitionResult(taskId, "awaiting_confirmation", updatedAt, recognizedItems, signedUrl(objectKey), overall, uncertain, suggestion);
        } catch (IOException ex) {
            throw new BusinessException(ErrorCode.INVALID_FILE, org.springframework.http.HttpStatus.BAD_REQUEST, "图片读取失败");
        }
    }

    private void validate(MultipartFile image, String mime) {
        if (image == null || image.isEmpty() || image.getSize() > MAX_BYTES)
            throw new BusinessException(ErrorCode.INVALID_FILE, org.springframework.http.HttpStatus.UNSUPPORTED_MEDIA_TYPE, "图片为空或超过 10MB");
        if (!ALLOWED.contains(mime))
            throw new BusinessException(ErrorCode.INVALID_FILE, org.springframework.http.HttpStatus.UNSUPPORTED_MEDIA_TYPE, "仅支持 JPG、PNG 或 WebP 图片");
    }

    /** Browsers and mini-programs occasionally send image/jpg or octet-stream. */
    private String normalizeContentType(MultipartFile image, byte[] bytes) {
        String raw = image == null ? null : image.getContentType();
        if ("image/jpg".equalsIgnoreCase(raw)) return "image/jpeg";
        if (ALLOWED.contains(raw)) return raw;
        String name = image == null ? "" : String.valueOf(image.getOriginalFilename()).toLowerCase();
        if (name.endsWith(".png") || isPng(bytes)) return "image/png";
        if (name.endsWith(".webp") || isWebp(bytes)) return "image/webp";
        if (name.endsWith(".jpg") || name.endsWith(".jpeg") || isJpeg(bytes)) return "image/jpeg";
        return raw == null ? "" : raw.toLowerCase();
    }

    private boolean isPng(byte[] bytes) {
        return bytes != null && bytes.length >= 8 && bytes[0] == (byte) 0x89 && bytes[1] == 0x50
                && bytes[2] == 0x4e && bytes[3] == 0x47 && bytes[4] == 0x0d && bytes[5] == 0x0a
                && bytes[6] == 0x1a && bytes[7] == 0x0a;
    }

    private boolean isJpeg(byte[] bytes) {
        return bytes != null && bytes.length >= 3 && (bytes[0] & 0xff) == 0xff
                && (bytes[1] & 0xff) == 0xd8 && (bytes[2] & 0xff) == 0xff;
    }

    private boolean isWebp(byte[] bytes) {
        return bytes != null && bytes.length >= 12 && bytes[0] == 'R' && bytes[1] == 'I'
                && bytes[2] == 'F' && bytes[3] == 'F' && bytes[8] == 'W' && bytes[9] == 'E'
                && bytes[10] == 'B' && bytes[11] == 'P';
    }

    private URI signedUrl(String objectKey) { return storage.signedGetUrl(objectKey, Duration.ofMinutes(10)); }
    private String extension(String mime) { return "image/png".equals(mime) ? ".png" : "image/webp".equals(mime) ? ".webp" : ".jpg"; }
    private String sha256(byte[] bytes) { try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes)); } catch (Exception ex) { throw new IllegalStateException(ex); } }
    private String json(List<String> values) { try { return mapper.writeValueAsString(values); } catch (JsonProcessingException ex) { throw new IllegalStateException(ex); } }

    public record RecognitionResult(UUID taskId, String status, java.time.Instant updatedAt, List<RecognizedItem> items, URI previewUrl, double overallConfidence, List<String> uncertainItems, String suggestions) {}
    public record RecognizedItem(UUID id, String name, String quantity, String category, double confidence, boolean needsConfirmation, List<String> possibleAllergens) {}
}
