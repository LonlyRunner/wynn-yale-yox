package cn.chuxiaoban.ordering;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import cn.chuxiaoban.common.exception.BusinessException;
import cn.chuxiaoban.common.api.ErrorCode;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/v1/household")
public class HouseholdController {
 private final JdbcTemplate db;
 private final cn.chuxiaoban.ai.OpenAiCompatibleClient ai;
 private final com.fasterxml.jackson.databind.ObjectMapper mapper;
 @Value("${cxb.ai.provider:mock}") private String provider;
 @Value("${cxb.ai.text-model:}") private String textModel;
 @Value("${cxb.ai.vision-model:}") private String visionModel;
 @Value("${CXB_ADMIN_PASSWORD:}") private String adminPassword;
 public HouseholdController(JdbcTemplate db,cn.chuxiaoban.ai.OpenAiCompatibleClient ai,com.fasterxml.jackson.databind.ObjectMapper mapper){this.db=db;this.ai=ai;this.mapper=mapper;}
 private UUID space(HttpServletRequest r){return (UUID)r.getAttribute(GuestAuthenticationFilter.SPACE_ID);}
 private <T> ApiResponse<T> ok(T x,HttpServletRequest r){return ApiResponse.ok(x,(String)r.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));}
 private void admin(HttpServletRequest r){String supplied=r.getHeader("X-Admin-Password");if(adminPassword==null||adminPassword.isBlank()||supplied==null||!java.security.MessageDigest.isEqual(adminPassword.getBytes(java.nio.charset.StandardCharsets.UTF_8),supplied.getBytes(java.nio.charset.StandardCharsets.UTF_8)))throw new BusinessException(ErrorCode.FORBIDDEN,HttpStatus.FORBIDDEN,"管理密码未配置或不正确");}
 @GetMapping("/dishes") @Transactional public ApiResponse<List<Dish>> dishes(HttpServletRequest r){
  UUID sp=space(r);
  db.queryForObject("SELECT id FROM sync_space WHERE id=? FOR UPDATE",UUID.class,sp);
  Integer count=db.queryForObject("SELECT count(*) FROM household_dish WHERE sync_space_id=?",Integer.class,sp);
  if(count!=null && count==0){
   String[][] defaults={{"番茄炒蛋","酸甜开胃，经典家常菜"},{"宫保鸡丁","鸡肉鲜嫩，香辣下饭"},{"红烧肉","酱香浓郁，软糯入味"},{"鱼香肉丝","酸甜微辣，配菜丰富"},{"清炒时蔬","清爽鲜嫩，少油快炒"},{"麻婆豆腐","麻辣鲜香，豆腐嫩滑"},{"清蒸鲈鱼","清蒸鲜鱼，口味清淡"},{"紫菜蛋花汤","清淡暖胃，鲜香可口"},{"米饭","松软米饭，搭配家常菜"},{"蛋炒饭","粒粒分明，简单美味"}};
   for(String[] dish:defaults)db.update("INSERT INTO household_dish(id,sync_space_id,name,description,category) VALUES(?,?,?,?,?)",UUID.randomUUID(),sp,dish[0],dish[1],defaultCategory(dish[0]));
  }
  Integer seeded=db.queryForObject("SELECT count(*) FROM demo_dish_seeded WHERE sync_space_id=?",Integer.class,sp);
  if(seeded!=null && seeded==0){
   db.update("INSERT INTO household_dish(id,sync_space_id,name,description,category) SELECT gen_random_uuid(),?,d.name,d.description,d.category FROM demo_dish_catalog d WHERE NOT EXISTS (SELECT 1 FROM household_dish existing WHERE existing.sync_space_id=? AND existing.name=d.name)",sp,sp);
   db.update("INSERT INTO demo_dish_seeded(sync_space_id) VALUES(?)",sp);
  }
  return ok(db.query("SELECT id,name,description,available,category FROM household_dish WHERE sync_space_id=? ORDER BY created_at,name",(s,n)->new Dish(s.getObject(1,UUID.class),s.getString(2),s.getString(3),s.getBoolean(4),s.getString(5)),sp),r);
 }
 @PostMapping("/dishes") public ApiResponse<Dish> add(@Valid @RequestBody DishInput b,HttpServletRequest r){admin(r);UUID id=UUID.randomUUID();String category=b.category()==null||b.category().isBlank()?"其他":b.category().trim();db.update("INSERT INTO household_dish(id,sync_space_id,name,description,category) VALUES(?,?,?,?,?)",id,space(r),b.name().trim(),b.description(),category);return ok(new Dish(id,b.name().trim(),b.description(),true,category),r);}
 @PostMapping("/dishes/{id}/recipe") public ApiResponse<DishRecipe> recipe(@PathVariable UUID id,HttpServletRequest r){
  String name=db.query("SELECT name FROM household_dish WHERE id=? AND sync_space_id=?",rs->rs.next()?rs.getString(1):null,id,space(r));
  if(name==null)throw missing();
  try{
   String cached=db.query("SELECT recipe_json::text FROM household_dish_recipe WHERE dish_id=?",rs->rs.next()?rs.getString(1):null,id);
   if(cached!=null)return ok(mapper.readValue(cached,DishRecipe.class),r);
   String prompt="为家常菜生成约2人份参考菜谱。只输出JSON对象，格式：{\"ingredients\":[{\"name\":\"食材\",\"amount\":\"用量\"}],\"steps\":[\"步骤\"],\"safety_warnings\":[\"安全提醒\"]}。用量写常见单位，步骤简明并包含火候，生肉、海鲜需充分加热；不确定的信息不要杜撰。菜名："+name;
   var result=ai.chat(ai.textModel(),List.of(Map.of("role","user","content",prompt)));
   var ing=result.path("ingredients");var steps=result.path("steps");
   if(!ing.isArray()||ing.isEmpty()||!steps.isArray()||steps.isEmpty())throw new IllegalStateException("invalid recipe");
   List<Ingredient> ingredients=new ArrayList<>();for(var x:ing){String n=x.path("name").asText("").trim(),a=x.path("amount").asText("").trim();if(!n.isEmpty())ingredients.add(new Ingredient(n,a));if(ingredients.size()>=30)break;}
   List<String> actions=new ArrayList<>();for(var x:steps){if(x.isTextual()&&!x.asText().isBlank())actions.add(x.asText());if(actions.size()>=20)break;}
   List<String> warnings=new ArrayList<>();if(result.path("safety_warnings").isArray())for(var x:result.path("safety_warnings")){if(x.isTextual())warnings.add(x.asText());if(warnings.size()>=10)break;}
   if(ingredients.isEmpty()||actions.isEmpty())throw new IllegalStateException("invalid recipe");
   DishRecipe recipe=new DishRecipe(name,ingredients,actions,warnings);
   db.update("INSERT INTO household_dish_recipe(dish_id,recipe_json) VALUES(?,?::jsonb) ON CONFLICT (dish_id) DO NOTHING",id,mapper.writeValueAsString(recipe));
   return ok(recipe,r);
  }catch(Exception e){throw new BusinessException(ErrorCode.AI_INVALID_RESPONSE,HttpStatus.SERVICE_UNAVAILABLE,"菜谱暂不可用，请稍后重试");}
 }
 @PutMapping("/dishes/{id}") public ApiResponse<Void> toggle(@PathVariable UUID id,@RequestBody Availability b,HttpServletRequest r){admin(r);if(db.update("UPDATE household_dish SET available=? WHERE id=? AND sync_space_id=?",b.available(),id,space(r))!=1)throw missing();return ok(null,r);}
 @PostMapping("/orders") @Transactional public ApiResponse<UUID> order(@Valid @RequestBody OrderInput b,HttpServletRequest r){UUID id=UUID.randomUUID(),sp=space(r);db.update("INSERT INTO household_order(id,sync_space_id,note) VALUES(?,?,?)",id,sp,b.note());for(OrderLine item:b.items()){String name=db.query("SELECT name FROM household_dish WHERE id=? AND sync_space_id=? AND available=true",rs->rs.next()?rs.getString(1):null,item.dishId(),sp);if(name==null)throw missing();db.update("INSERT INTO household_order_item(id,order_id,dish_name,quantity,note) VALUES(?,?,?,?,?)",UUID.randomUUID(),id,name,item.quantity(),item.note());}return ok(id,r);}
 @GetMapping("/orders") public ApiResponse<List<Order>> orders(HttpServletRequest r){admin(r);UUID sp=space(r);return ok(db.query("SELECT id,status,note,created_at FROM household_order WHERE sync_space_id=? ORDER BY created_at DESC LIMIT 100",(s,n)->{UUID id=s.getObject(1,UUID.class);return new Order(id,s.getString(2),s.getString(3),s.getTimestamp(4).toInstant(),db.query("SELECT dish_name,quantity,note FROM household_order_item WHERE order_id=? ORDER BY id",(a,i)->new Line(a.getString(1),a.getInt(2),a.getString(3)),id));},sp),r);}
 @PutMapping("/orders/{id}") public ApiResponse<Void> status(@PathVariable UUID id,@Valid @RequestBody Status b,HttpServletRequest r){admin(r);if(db.update("UPDATE household_order SET status=? WHERE id=? AND sync_space_id=?",b.status(),id,space(r))!=1)throw missing();return ok(null,r);}
 @GetMapping("/model") public ApiResponse<Map<String,String>> model(HttpServletRequest r){admin(r);return ok(Map.of("provider",provider,"text_model",textModel,"vision_model",visionModel),r);}
 private String defaultCategory(String name){return switch(name){case "清炒时蔬" -> "清爽蔬菜"; case "紫菜蛋花汤" -> "暖心汤品"; case "米饭","蛋炒饭" -> "主食"; default -> "家常热菜";};}
 private BusinessException missing(){return new BusinessException(ErrorCode.NOT_FOUND,HttpStatus.NOT_FOUND,"菜品或订单不存在");}
 public record Ingredient(String name,String amount){} public record DishRecipe(String name,List<Ingredient> ingredients,List<String> steps,List<String> safetyWarnings){}
 public record Dish(UUID id,String name,String description,boolean available,String category){} public record DishInput(@NotBlank @Size(max=120) String name,@Size(max=300) String description,@Size(max=30) String category){} public record Availability(boolean available){} public record OrderLine(@NotNull UUID dishId,@Min(1) @Max(20) int quantity,@Size(max=300) String note){} public record OrderInput(@NotEmpty @Size(max=50) List<@Valid OrderLine> items,@Size(max=300) String note){} public record Status(@NotBlank @Pattern(regexp="NEW|ACCEPTED|DONE|CANCELLED") String status){} public record Line(String dishName,int quantity,String note){} public record Order(UUID id,String status,String note,java.time.Instant createdAt,List<Line> items){}
}
