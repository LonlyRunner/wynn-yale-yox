package cn.chuxiaoban.chat;

import cn.chuxiaoban.ai.OpenAiCompatibleClient;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class KitchenChatService {
    private final ObjectProvider<OpenAiCompatibleClient> ai;

    public KitchenChatService(ObjectProvider<OpenAiCompatibleClient> ai) { this.ai = ai; }

    public ChatReply reply(String message, String context) {
        String question = message == null ? "" : message.trim();
        if (question.isBlank()) return new ChatReply("请先输入想了解的菜品或烹饪问题。", List.of("鸡蛋怎么做", "今天吃什么", "油锅起火怎么办"));
        OpenAiCompatibleClient client = ai.getIfAvailable();
        if (client != null) {
            try {
                String prompt = "你是厨小伴厨房助手。只返回 JSON：{\"reply\":\"回答\",\"suggestions\":[]}。用简洁、可靠的中文回答厨房问题，涉及刀具、热油、燃气、生食时优先给出安全提醒。不要编造营养或价格数据。用户问题：" + question + (context == null || context.isBlank() ? "" : "。当前识别食材：" + context);
                JsonNode result = client.chat(client.textModel(), List.of(Map.of("role", "user", "content", prompt)));
                JsonNode content = result.path("reply");
                if (!content.isTextual()) content = result.path("answer");
                if (content.isTextual() && !content.asText().isBlank()) return new ChatReply(content.asText(), List.of());
            } catch (RuntimeException ignored) { /* use safe local fallback */ }
        }
        return new ChatReply(localReply(question), List.of("换一道家常菜", "查看烹饪步骤", "补充食材"));
    }

    private String localReply(String question) {
        if (question.contains("鸡蛋")) return "鸡蛋可以做番茄炒蛋、蒸水蛋或蛋花汤。想快速解决一餐，可以先做番茄炒蛋：鸡蛋炒至刚凝固后盛出，再炒番茄，最后回锅合炒。";
        if (question.contains("油锅") || question.contains("起火")) return "油锅起火时立即关火，用锅盖完全盖住锅口，切勿泼水；确认安全后再处理。若火势无法控制，请立即撤离并拨打 119。";
        if (question.contains("今天吃什么") || question.contains("推荐")) return "可以告诉我人数、预算、口味和忌口，我会按现有食材帮你安排一餐。也可以直接拍照识别食材。";
        return "我可以帮你回答菜品做法、火候、调味和厨房安全问题。你可以具体说说想做什么菜或手边有哪些食材。";
    }

    public record ChatReply(String reply, List<String> suggestions) {}
}
