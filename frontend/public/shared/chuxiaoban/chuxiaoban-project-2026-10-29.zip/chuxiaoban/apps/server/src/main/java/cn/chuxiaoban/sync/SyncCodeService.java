package cn.chuxiaoban.sync;

import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.Mac;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.time.Instant;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class SyncCodeService {
    private static final SecureRandom RANDOM = new SecureRandom();
    private final JdbcTemplate jdbc;
    private final GuestTokenService tokens;
    public SyncCodeService(JdbcTemplate jdbc, GuestTokenService tokens) { this.jdbc = jdbc; this.tokens = tokens; }

    public SyncCode create(UUID spaceId) {
        String code = String.format("%08d", RANDOM.nextInt(100_000_000));
        Instant expires = Instant.now().plusSeconds(10 * 60L);
        // PostgreSQL's JDBC driver cannot infer a type for java.time.Instant;
        // bind an explicit SQL timestamp for the TIMESTAMPTZ column.
        jdbc.update("INSERT INTO sync_code(id,sync_space_id,code_hash,expires_at) VALUES (?,?,?,?)", UUID.randomUUID(), spaceId, hash(code), java.sql.Timestamp.from(expires));
        return new SyncCode(code, expires);
    }

    @Transactional
    public GuestIdentityController.GuestTokenData bind(UUID deviceId, String code, boolean confirmed) {
        if (!confirmed) throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "请确认绑定设备");
        String codeHash = hash(code == null ? "" : code.trim());
        var rows = jdbc.query("SELECT id,sync_space_id,expires_at,attempts,used_at FROM sync_code WHERE code_hash=?", (rs, row) -> new CodeRow(rs.getObject(1, UUID.class), rs.getObject(2, UUID.class), rs.getTimestamp(3).toInstant(), rs.getInt(4), rs.getTimestamp(5)), codeHash);
        if (rows.isEmpty()) throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "同步码无效");
        CodeRow row = rows.get(0);
        if (row.usedAt != null || row.expiresAt.isBefore(Instant.now()) || row.attempts >= 5) throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "同步码已失效");
        UUID targetSpace = row.spaceId;
        Integer device = jdbc.queryForObject("SELECT count(*) FROM guest_device WHERE id=? AND revoked_at IS NULL", Integer.class, deviceId);
        if (device == null || device != 1) throw new BusinessException(ErrorCode.UNAUTHORIZED, HttpStatus.UNAUTHORIZED, "游客设备不存在");
        jdbc.update("UPDATE guest_device SET sync_space_id=?,token_version=token_version+1,last_seen_at=now() WHERE id=?", targetSpace, deviceId);
        jdbc.update("UPDATE sync_code SET used_at=now(),attempts=attempts+1 WHERE id=?", row.id);
        var current = jdbc.queryForMap("SELECT token_version FROM guest_device WHERE id=?", deviceId);
        long version = ((Number) current.get("token_version")).longValue();
        String access = tokens.issue(deviceId, targetSpace, version, 3600);
        return new GuestIdentityController.GuestTokenData(access, "", 3600);
    }

    public SyncStatus status(UUID spaceId, UUID deviceId) {
        Integer devices = jdbc.queryForObject("SELECT count(*) FROM guest_device WHERE sync_space_id=? AND revoked_at IS NULL", Integer.class, spaceId);
        return new SyncStatus(devices == null ? 0 : devices, devices != null && devices > 1);
    }

    @Transactional
    public GuestIdentityController.GuestTokenData unbind(UUID deviceId) {
        Integer exists = jdbc.queryForObject("SELECT count(*) FROM guest_device WHERE id=? AND revoked_at IS NULL", Integer.class, deviceId);
        if (exists == null || exists != 1) throw new BusinessException(ErrorCode.UNAUTHORIZED, HttpStatus.UNAUTHORIZED, "游客设备不存在");
        UUID newSpace = UUID.randomUUID();
        jdbc.update("INSERT INTO sync_space(id,status,version) VALUES (?, 'ACTIVE', 1)", newSpace);
        jdbc.update("UPDATE guest_device SET sync_space_id=?,token_version=token_version+1,last_seen_at=now() WHERE id=?", newSpace, deviceId);
        long version = ((Number) jdbc.queryForMap("SELECT token_version FROM guest_device WHERE id=?", deviceId).get("token_version")).longValue();
        return new GuestIdentityController.GuestTokenData(tokens.issue(deviceId, newSpace, version, 3600), "", 3600);
    }

    private String hash(String value) { try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8))); } catch (Exception ex) { throw new IllegalStateException(ex); } }
    private record CodeRow(UUID id, UUID spaceId, Instant expiresAt, int attempts, java.sql.Timestamp usedAt) {}
    public record SyncCode(String syncCode, Instant expiresAt) {}
    public record SyncStatus(int deviceCount, boolean bound) {}
}
