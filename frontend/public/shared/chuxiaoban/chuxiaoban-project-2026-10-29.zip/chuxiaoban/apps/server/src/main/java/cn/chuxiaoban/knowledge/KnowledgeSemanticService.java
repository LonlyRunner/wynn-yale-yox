package cn.chuxiaoban.knowledge;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class KnowledgeSemanticService {
    private static final int DIMENSIONS = 96;
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public KnowledgeSemanticService(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.mapper = mapper;
    }

    public SearchPage search(String query, int limit) {
        String normalized = query == null ? "" : query.trim();
        if (normalized.isEmpty()) throw new IllegalArgumentException("搜索内容不能为空");
        if (normalized.length() > 200) throw new IllegalArgumentException("搜索内容不能超过200个字符");
        int safeLimit = Math.max(1, Math.min(30, limit));
        double[] q = embed(normalized);
        List<DocRow> docs = jdbc.query("SELECT id,title,content,tags_json::text,embedding_json::text,source_url FROM knowledge_document ORDER BY updated_at DESC", (rs, row) ->
                new DocRow(rs.getObject("id", UUID.class), rs.getString("title"), rs.getString("content"), rs.getString(4), rs.getString(5), rs.getString("source_url")));
        List<DocumentHit> hits = docs.stream().map(doc -> {
            List<String> tags = readList(doc.tagsJson);
            double[] vector = readVector(doc.embeddingJson);
            if (vector.length != DIMENSIONS) vector = embed(doc.title + " " + doc.content + " " + String.join(" ", tags));
            double score = cosine(q, vector) + keywordBoost(normalized, doc.title, doc.content, tags);
            score = Math.max(0d, Math.min(1d, score));
            return new DocumentHit(doc.id, doc.title, snippet(doc.content), tags, Math.round(score * 1000d) / 1000d, doc.sourceUrl);
        }).sorted(Comparator.comparingDouble(DocumentHit::score).reversed()).limit(safeLimit).toList();
        return new SearchPage(normalized, hits);
    }

    public KnowledgeDocument get(UUID id) {
        return jdbc.query("SELECT id,title,content,tags_json::text,source_type,source_url FROM knowledge_document WHERE id=?", (rs, row) ->
                new KnowledgeDocument(rs.getObject("id", UUID.class), rs.getString("title"), rs.getString("content"), readList(rs.getString(4)), rs.getString("source_type"), rs.getString("source_url")), id)
                .stream().findFirst().orElseThrow(() -> new NoSuchElementException("知识文档不存在"));
    }

    public KnowledgeDocument create(String title, String content, List<String> tags, String sourceUrl) {
        String safeTitle = required(title, "标题", 180);
        String safeContent = required(content, "内容", 20000);
        List<String> safeTags = tags == null ? List.of() : tags.stream().filter(Objects::nonNull).map(String::trim).filter(s -> !s.isEmpty()).limit(20).map(s -> s.substring(0, Math.min(30, s.length()))).toList();
        UUID id = UUID.randomUUID();
        jdbc.update("INSERT INTO knowledge_document(id,title,content,tags_json,embedding_json,source_type,source_url) VALUES(?,?,? ,?::jsonb,?::jsonb,'user',?)", id, safeTitle, safeContent, json(safeTags), json(embedList(safeTitle + " " + safeContent + " " + String.join(" ", safeTags))), validUrl(sourceUrl, 500));
        return get(id);
    }

    public List<VideoItem> videos(UUID documentId) {
        String sql = documentId == null ? "SELECT id,document_id,title,video_url,cover_url,duration_seconds,platform FROM knowledge_video ORDER BY created_at DESC" : "SELECT id,document_id,title,video_url,cover_url,duration_seconds,platform FROM knowledge_video WHERE document_id=? ORDER BY created_at DESC";
        return documentId == null ? jdbc.query(sql, this::video) : jdbc.query(sql, this::video, documentId);
    }

    public VideoItem createVideo(UUID documentId, String title, String videoUrl, String coverUrl, Integer durationSeconds, String platform) {
        String safeTitle = required(title, "视频标题", 180);
        String safeUrl = required(videoUrl, "视频链接", 500);
        if (!(safeUrl.startsWith("https://") || safeUrl.startsWith("http://"))) throw new IllegalArgumentException("视频链接必须是 http 或 https");
        if (documentId != null && jdbc.queryForObject("SELECT count(*) FROM knowledge_document WHERE id=?", Integer.class, documentId) != 1) throw new IllegalArgumentException("关联知识文档不存在");
        int duration = durationSeconds == null ? 0 : durationSeconds;
        if (duration < 0 || duration > 86400) throw new IllegalArgumentException("视频时长不合法");
        UUID id = UUID.randomUUID();
        jdbc.update("INSERT INTO knowledge_video(id,document_id,title,video_url,cover_url,duration_seconds,platform) VALUES(?,?,?,?,?,?,?)", id, documentId, safeTitle, safeUrl, validUrl(coverUrl, 500), duration, platform == null || platform.isBlank() ? "other" : platform.substring(0, Math.min(30, platform.length())));
        return videos(null).stream().filter(v -> v.id().equals(id)).findFirst().orElseThrow();
    }

    private VideoItem video(java.sql.ResultSet rs, int row) throws java.sql.SQLException { return new VideoItem(rs.getObject("id", UUID.class), rs.getObject("document_id", UUID.class), rs.getString("title"), rs.getString("video_url"), rs.getString("cover_url"), rs.getInt("duration_seconds"), rs.getString("platform")); }
    private String required(String value, String name, int max) { String s = value == null ? "" : value.trim(); if (s.isEmpty() || s.length() > max) throw new IllegalArgumentException(name + "不能为空且不能超过" + max + "个字符"); return s; }
    private String validUrl(String value, int max) { if (value == null || value.isBlank()) return null; String s = value.trim(); if (s.length() > max || !(s.startsWith("https://") || s.startsWith("http://"))) throw new IllegalArgumentException("链接必须是 http 或 https"); return s; }
    private String snippet(String content) { String s = content == null ? "" : content.replaceAll("\\s+", " ").trim(); return s.length() <= 140 ? s : s.substring(0, 140) + "…"; }
    private double keywordBoost(String q, String title, String content, List<String> tags) { String hay = (title + " " + content + " " + String.join(" ", tags)).toLowerCase(Locale.ROOT); return hay.contains(q.toLowerCase(Locale.ROOT)) ? 0.15 : 0; }
    private List<String> readList(String json) { try { return mapper.readValue(json == null ? "[]" : json, new TypeReference<>() {}); } catch (Exception e) { return List.of(); } }
    private double[] readVector(String json) { try { List<Double> list = mapper.readValue(json == null ? "[]" : json, new TypeReference<>() {}); return list.stream().mapToDouble(Double::doubleValue).toArray(); } catch (Exception e) { return new double[0]; } }
    private List<Double> embedList(String text) { double[] v = embed(text); return Arrays.stream(v).boxed().collect(Collectors.toList()); }
    private String json(Object value) { try { return mapper.writeValueAsString(value); } catch (Exception e) { throw new IllegalStateException(e); } }
    private double[] embed(String text) { double[] vector = new double[DIMENSIONS]; String normalized = text == null ? "" : text.toLowerCase(Locale.ROOT); if (normalized.isBlank()) return vector; int[] chars = normalized.codePoints().toArray(); for (int i = 0; i < chars.length; i++) { add(vector, Integer.toString(chars[i])); if (i + 1 < chars.length) add(vector, chars[i] + ":" + chars[i + 1]); } double norm = Math.sqrt(Arrays.stream(vector).map(x -> x * x).sum()); if (norm > 0) for (int i = 0; i < vector.length; i++) vector[i] /= norm; return vector; }
    private void add(double[] vector, String token) { try { byte[] digest = MessageDigest.getInstance("SHA-256").digest(token.getBytes(StandardCharsets.UTF_8)); int index = ((digest[0] & 0xff) << 8 | (digest[1] & 0xff)) % DIMENSIONS; vector[index] += (digest[2] & 1) == 0 ? 1 : -1; } catch (Exception ignored) {} }
    private double cosine(double[] a, double[] b) { if (a.length != b.length) return 0; double dot = 0; for (int i = 0; i < a.length; i++) dot += a[i] * b[i]; return dot; }

    private record DocRow(UUID id, String title, String content, String tagsJson, String embeddingJson, String sourceUrl) {}
    public record SearchPage(String query, List<DocumentHit> items) {}
    public record DocumentHit(UUID id, String title, String snippet, List<String> tags, double score, String sourceUrl) {}
    public record KnowledgeDocument(UUID id, String title, String content, List<String> tags, String sourceType, String sourceUrl) {}
    public record VideoItem(UUID id, UUID documentId, String title, String videoUrl, String coverUrl, int durationSeconds, String platform) {}
}
