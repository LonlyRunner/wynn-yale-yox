package cn.chuxiaoban.nutrition;
import org.springframework.stereotype.Service; import java.time.LocalDate; import java.util.*;
@Service public class PriceService {
 public PriceQuote quote(String ingredient,String region){String name=ingredient==null?"":ingredient.trim();if(name.isEmpty()||name.length()>80)throw new IllegalArgumentException("食材名称不合法");int hash=Math.abs(name.hashCode());double min=2+(hash%180)/10.0;double max=min+1+(hash%50)/10.0;return new PriceQuote(name,region==null||region.isBlank()?"中国大陆":region.trim(),Math.round(min*100)/100d,Math.round(max*100)/100d,"CNY/kg",LocalDate.now(),"mock-curated");}
 public record PriceQuote(String ingredient,String region,double minPrice,double maxPrice,String unit,LocalDate asOf,String source){}
}
