package cn.chuxiaoban.account;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.common.web.RequestIdFilter;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/v1/auth/account")
public class AccountController {
    private final AccountService service;
    public AccountController(AccountService service) { this.service = service; }

    @PostMapping("/login")
    public ApiResponse<AccountService.AccountSession> login(@Valid @RequestBody LoginRequest body, HttpServletRequest request) {
        try { return ok(service.login(body.provider(), body.providerSubject(), body.devicePublicId(), body.nickname(), body.avatarUrl(), body.termsAccepted(), body.privacyAccepted()), request); } catch (IllegalArgumentException e) { throw bad(e); }
    }

    @PostMapping("/link")
    public ApiResponse<AccountService.AccountSession> link(@Valid @RequestBody LinkRequest body, HttpServletRequest request) {
        try { return ok(service.link((java.util.UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), (java.util.UUID) request.getAttribute(GuestAuthenticationFilter.DEVICE_ID), body.provider(), body.providerSubject(), body.nickname(), body.avatarUrl(), body.termsAccepted(), body.privacyAccepted()), request); } catch (IllegalArgumentException e) { throw bad(e); }
    }
    @GetMapping("/me")
    public ApiResponse<AccountService.AccountProfile> me(HttpServletRequest request) { try { return ok(service.profileForSpace((java.util.UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID)), request); } catch (IllegalArgumentException e) { throw bad(e); } }

    private <T> ApiResponse<T> ok(T data, HttpServletRequest request) { return ApiResponse.ok(data, (String) request.getAttribute(RequestIdFilter.ATTRIBUTE)); }
    private ResponseStatusException bad(Exception e) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage()); }
    public record LoginRequest(@NotBlank @Size(max = 30) String provider, @NotBlank @Size(max = 200) String providerSubject, @NotBlank @Size(max = 200) String devicePublicId, @Size(max = 80) String nickname, @Size(max = 500) String avatarUrl, boolean termsAccepted, boolean privacyAccepted) {}
    public record LinkRequest(@NotBlank @Size(max = 30) String provider, @NotBlank @Size(max = 200) String providerSubject, @Size(max = 80) String nickname, @Size(max = 500) String avatarUrl, boolean termsAccepted, boolean privacyAccepted) {}
}
