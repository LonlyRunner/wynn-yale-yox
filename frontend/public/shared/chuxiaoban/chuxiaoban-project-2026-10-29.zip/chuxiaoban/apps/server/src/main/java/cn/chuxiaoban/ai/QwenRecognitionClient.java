package cn.chuxiaoban.ai;

import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.Base64;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
@ConditionalOnExpression("'${cxb.ai.provider:mock}' == 'qwen' || '${cxb.ai.provider:mock}' == 'deepseek'")
public class QwenRecognitionClient implements AiRecognitionClient {
    private final OpenAiCompatibleClient client;

    public QwenRecognitionClient(OpenAiCompatibleClient client) { this.client = client; }

    @Override
    public List<RecognitionItem> recognize(byte[] image, String contentType, String note) {
        String dataUrl = "data:" + contentType + ";base64," + Base64.getEncoder().encodeToString(image);
        String prompt = "你是厨房食材识别器。只返回JSON对象，格式为 {\"recognized_items\":[{\"name\":\"西红柿\",\"quantity\":null,\"category\":\"vegetable\",\"confidence\":0.0,\"needs_confirmation\":true,\"possible_allergens\":[]}]}. category只能是 vegetable、fruit、meat、seafood、egg_dairy、staple、seasoning、processed、other。识别生鲜食材、包装食品和成品菜肴中能明确判断的主食材；若图片是菜品，返回主食材而不是菜名，例如番茄炒蛋返回西红柿和鸡蛋。不要猜测看不见的配料、品牌或功效；确实无法判断时才返回空数组。用户备注：" + (note == null ? "无" : note);
        var content = List.of(Map.of("type", "text", "text", prompt), Map.of("type", "image_url", "image_url", Map.of("url", dataUrl)));
        var result = client.chat(client.visionModel(), List.of(Map.of("role", "user", "content", content)));
        JsonNode nodes = AiSchemaValidator.array(result, "recognized_items", "items", "recognition items", 50, 0);
        List<RecognitionItem> output = new ArrayList<>();
        for (JsonNode item : nodes) {
            String name = item.isTextual() ? item.asText().trim() : item.path("name").asText("").trim();
            if (name.isBlank() || name.length() > 50) continue;
            String category = item.path("category").asText("other");
            if (!Set.of("vegetable", "fruit", "meat", "seafood", "egg_dairy", "staple", "seasoning", "processed", "other").contains(category)) category = "other";
            String quantity = item.path("quantity").isTextual() ? item.path("quantity").asText() : null;
            double confidence = item.path("confidence").isNumber() ? Math.max(0, Math.min(1, item.path("confidence").asDouble())) : 0.5;
            boolean needsConfirmation = !item.path("needs_confirmation").isBoolean() || item.path("needs_confirmation").asBoolean() || confidence < 0.75;
            List<String> allergens = new ArrayList<>();
            if (item.path("possible_allergens").isArray()) for (JsonNode allergen : item.path("possible_allergens")) if (allergen.isTextual() && allergen.asText().length() <= 40) allergens.add(allergen.asText());
            output.add(new RecognitionItem(name, quantity, category, confidence, needsConfirmation, allergens));
        }
        return output;
    }
}
