package cn.chuxiaoban;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChuxiaobanApplication {
    public static void main(String[] args) {
        SpringApplication.run(ChuxiaobanApplication.class, args);
    }
}
