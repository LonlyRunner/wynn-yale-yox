package cn.chuxiaoban.common.web;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.boot.test.mock.mockito.MockBean;
import cn.chuxiaoban.sync.GuestTokenService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(value = GlobalExceptionHandlerTest.FailingController.class, properties = "cxb.auth.enabled=false")
@Import({GlobalExceptionHandler.class, RequestIdFilter.class})
class GlobalExceptionHandlerTest {
    @Autowired MockMvc mvc;
    @MockBean GuestTokenService guestTokenService;

    @Test
    void hidesUnexpectedExceptionAndReturnsRequestId() throws Exception {
        mvc.perform(get("/fail").header("X-Request-Id", "test-request"))
                .andExpect(status().isInternalServerError())
                .andExpect(header().string("X-Request-Id", "test-request"))
                .andExpect(jsonPath("$.code").value("INTERNAL_ERROR"))
                .andExpect(jsonPath("$.request_id").value("test-request"))
                .andExpect(jsonPath("$.message").value("服务暂时不可用"));
    }

    @RestController
    static class FailingController {
        @GetMapping("/fail") void fail() { throw new IllegalStateException("sensitive detail"); }
    }
}
