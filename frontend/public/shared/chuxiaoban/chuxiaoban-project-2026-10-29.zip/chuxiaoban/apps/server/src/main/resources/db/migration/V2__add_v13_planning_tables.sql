CREATE TABLE shopping_list (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    source_dish_id UUID REFERENCES recommended_dish(id),
    title VARCHAR(120) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_shopping_list_space ON shopping_list(sync_space_id, updated_at DESC);

CREATE TABLE shopping_item (
    id UUID PRIMARY KEY,
    shopping_list_id UUID NOT NULL REFERENCES shopping_list(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    quantity_text VARCHAR(80),
    checked BOOLEAN NOT NULL DEFAULT false,
    position INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE family_menu (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    title VARCHAR(120) NOT NULL,
    dining_date DATE NOT NULL,
    note VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'OPEN',
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_family_menu_space_date ON family_menu(sync_space_id, dining_date DESC);

CREATE TABLE family_menu_item (
    id UUID PRIMARY KEY,
    family_menu_id UUID NOT NULL REFERENCES family_menu(id) ON DELETE CASCADE,
    dish_id UUID REFERENCES recommended_dish(id),
    name VARCHAR(120) NOT NULL,
    servings INTEGER NOT NULL DEFAULT 2 CHECK (servings BETWEEN 1 AND 20),
    note VARCHAR(300),
    position INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cooking_plan (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    dish_id UUID REFERENCES recommended_dish(id),
    title VARCHAR(120) NOT NULL,
    plan_date DATE NOT NULL,
    meal_slot VARCHAR(20) NOT NULL,
    servings INTEGER NOT NULL DEFAULT 2 CHECK (servings BETWEEN 1 AND 20),
    status VARCHAR(20) NOT NULL DEFAULT 'PLANNED',
    note VARCHAR(500),
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_cooking_plan_space_date ON cooking_plan(sync_space_id, plan_date, meal_slot);
