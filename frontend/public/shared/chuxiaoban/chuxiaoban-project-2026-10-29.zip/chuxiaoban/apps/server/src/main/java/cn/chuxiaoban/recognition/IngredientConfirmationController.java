package cn.chuxiaoban.recognition;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;
import java.time.Instant;

@RestController
@RequestMapping("/api/v1/recognition")
public class IngredientConfirmationController {
    private final IngredientConfirmationService service;
    public IngredientConfirmationController(IngredientConfirmationService service) { this.service = service; }

    @PutMapping("/{taskId}/confirm")
    public ApiResponse<Void> confirm(@PathVariable UUID taskId, @Valid @RequestBody ConfirmRequest body, HttpServletRequest request) {
        service.confirm((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), taskId,
                body.ingredients().stream().map(item -> new IngredientConfirmationService.ConfirmedIngredient(
                        item.sourceItemId(), item.name(), item.quantity(), item.allergenCodes())).toList(), body.expectedUpdatedAt());
        return ApiResponse.ok(null, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    public record ConfirmRequest(@Size(min = 1, max = 50) List<@Valid IngredientRequest> ingredients, Instant expectedUpdatedAt) {}
    public record IngredientRequest(UUID sourceItemId, @NotBlank @Size(max = 80) String name,
                                    @Size(max = 80) String quantity, List<@Size(max = 40) String> allergenCodes) {}
}
