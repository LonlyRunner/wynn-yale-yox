package cn.chuxiaoban.planning;

import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.*;

@Service
public class PlanningService {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    public PlanningService(JdbcTemplate jdbc, ObjectMapper mapper) { this.jdbc = jdbc; this.mapper = mapper; }

    @Transactional
    public ShoppingList createShoppingList(UUID spaceId, UUID dishId, String title) {
        String dishName = null; List<ShoppingItemInput> missing = List.of();
        if (dishId != null) {
            var dish = jdbc.query("SELECT d.name,d.ingredients_json::text FROM recommended_dish d JOIN recommendation_batch b ON b.id=d.batch_id WHERE d.id=? AND b.sync_space_id=?", rs -> {
                if (!rs.next()) throw notFound("菜品不存在"); return new DishSource(rs.getString(1), rs.getString(2));
            }, dishId, spaceId);
            dishName = dish.name(); missing = missingItems(dish.ingredients());
        }
        UUID id = UUID.randomUUID(); String listTitle = blank(title) ? (dishName == null ? "我的购物清单" : dishName + " · 待购食材") : title.trim();
        jdbc.update("INSERT INTO shopping_list(id,sync_space_id,source_dish_id,title) VALUES (?,?,?,?)", id, spaceId, dishId, listTitle);
        for (int i = 0; i < missing.size(); i++) jdbc.update("INSERT INTO shopping_item(id,shopping_list_id,name,quantity_text,position,category,estimated_price,priority,have_it) VALUES (?,?,?,?,?,?,?,?,?)", UUID.randomUUID(), id, missing.get(i).name(), missing.get(i).quantity(), i, categoryOf(missing.get(i).name()), estimatedPrice(missing.get(i).name()), "高", false);
        return shoppingList(spaceId, id);
    }

    public List<ShoppingList> shoppingLists(UUID spaceId) { return jdbc.query("SELECT id FROM shopping_list WHERE sync_space_id=? AND status='ACTIVE' ORDER BY updated_at DESC", (rs, row) -> shoppingList(spaceId, rs.getObject(1, UUID.class)), spaceId); }
    @Transactional
    public ShoppingList addShoppingItem(UUID spaceId, UUID listId, ShoppingItemInput input) {
        ownedList(spaceId, listId); int position = jdbc.queryForObject("SELECT count(*) FROM shopping_item WHERE shopping_list_id=?", Integer.class, listId);
        jdbc.update("INSERT INTO shopping_item(id,shopping_list_id,name,quantity_text,position,category,estimated_price,priority,have_it) VALUES (?,?,?,?,?,?,?,?,?)", UUID.randomUUID(), listId, input.name().trim(), input.quantity(), position, categoryOf(input.name()), estimatedPrice(input.name()), "普通", false);
        touchList(listId); return shoppingList(spaceId, listId);
    }
    @Transactional
    public ShoppingList checkShoppingItem(UUID spaceId, UUID listId, UUID itemId, boolean checked) {
        ownedList(spaceId, listId); int updated = jdbc.update("UPDATE shopping_item SET checked=?,updated_at=now() WHERE id=? AND shopping_list_id=?", checked, itemId, listId);
        if (updated != 1) throw notFound("购物项不存在"); touchList(listId); return shoppingList(spaceId, listId);
    }
    @Transactional
    public void archiveShoppingList(UUID spaceId, UUID listId) { ownedList(spaceId, listId); jdbc.update("UPDATE shopping_list SET status='ARCHIVED',version=version+1,updated_at=now() WHERE id=?", listId); }

    @Transactional
    public FamilyMenu createMenu(UUID spaceId, String title, LocalDate diningDate, String note) {
        UUID id = UUID.randomUUID(); jdbc.update("INSERT INTO family_menu(id,sync_space_id,title,dining_date,note) VALUES (?,?,?,?,?)", id, spaceId, blank(title) ? "家庭点菜" : title.trim(), diningDate, note); return menu(spaceId, id);
    }

    @Transactional
    public FamilyMenu generateMenu(UUID spaceId, int guestCount, java.math.BigDecimal budget, String occasion, List<String> preferences, List<String> allergens, LocalDate diningDate) {
        int guests = Math.max(1, Math.min(20, guestCount));
        String occasionValue = blank(occasion) ? "日常" : occasion.trim();
        UUID id = UUID.randomUUID();
        jdbc.update("INSERT INTO family_menu(id,sync_space_id,title,dining_date,note,guest_count,budget,occasion,preferences_json,allergens_json,total_estimated_cost,serving_suggestion) VALUES (?,?,?,?,?,?,?,?,?::jsonb,?::jsonb,?,?)", id, spaceId, occasionValue + " · AI排菜", diningDate, "AI 根据人数、预算和口味生成，可继续编辑", guests, budget, occasionValue, json(preferences == null ? List.of() : preferences), json(allergens == null ? List.of() : allergens), 0, "建议先上汤和凉菜，再上热菜，主食最后出锅");
        List<MenuSeed> seeds = List.of(new MenuSeed("番茄炒蛋", "热菜", "炒", 18, 26), new MenuSeed("清蒸时蔬", "热菜", "蒸", 15, 18), new MenuSeed("紫菜蛋花汤", "汤", "煮", 12, 12), new MenuSeed("米饭", "主食", "蒸", 35, 10));
        double total = 0; int position = 0;
        for (MenuSeed seed : seeds) { total += seed.cost; jdbc.update("INSERT INTO family_menu_item(id,family_menu_id,name,servings,note,position,category,cooking_method,estimated_cost,estimated_minutes,nutrition_json) VALUES (?,?,?,?,?,?,?,?,?,?,?::jsonb)", UUID.randomUUID(), id, seed.name, guests, "AI 建议，可替换", position++, seed.category, seed.method, seed.cost, seed.minutes, "{\"calories\":180,\"protein\":10,\"fat\":8,\"carb\":20}"); }
        jdbc.update("UPDATE family_menu SET total_estimated_cost=? WHERE id=?", total, id);
        return menu(spaceId, id);
    }
    public List<FamilyMenu> menus(UUID spaceId, LocalDate date) { String sql = date == null ? "SELECT id FROM family_menu WHERE sync_space_id=? ORDER BY dining_date DESC" : "SELECT id FROM family_menu WHERE sync_space_id=? AND dining_date=? ORDER BY created_at"; return date == null ? jdbc.query(sql, (rs, row) -> menu(spaceId, rs.getObject(1, UUID.class)), spaceId) : jdbc.query(sql, (rs, row) -> menu(spaceId, rs.getObject(1, UUID.class)), spaceId, date); }
    @Transactional
    public FamilyMenu addMenuItem(UUID spaceId, UUID menuId, UUID dishId, String name, int servings, String note) {
        ownedMenu(spaceId, menuId); String finalName = blank(name) ? dishName(spaceId, dishId) : name.trim(); if (blank(finalName)) throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "请选择菜品或填写菜名");
        int position = jdbc.queryForObject("SELECT count(*) FROM family_menu_item WHERE family_menu_id=?", Integer.class, menuId);
        jdbc.update("INSERT INTO family_menu_item(id,family_menu_id,dish_id,name,servings,note,position) VALUES (?,?,?,?,?,?,?)", UUID.randomUUID(), menuId, dishId, finalName, servings, note, position); touchMenu(menuId); return menu(spaceId, menuId);
    }
    @Transactional
    public FamilyMenu updateMenuStatus(UUID spaceId, UUID menuId, String status) { ownedMenu(spaceId, menuId); jdbc.update("UPDATE family_menu SET status=?,version=version+1,updated_at=now() WHERE id=?", status, menuId); return menu(spaceId, menuId); }
    @Transactional
    public void archiveMenu(UUID spaceId, UUID menuId) { ownedMenu(spaceId, menuId); jdbc.update("UPDATE family_menu SET status='ARCHIVED',version=version+1,updated_at=now() WHERE id=?", menuId); }

    @Transactional
    public CookingPlan createPlan(UUID spaceId, UUID dishId, String title, LocalDate planDate, String mealSlot, int servings, String note) {
        String finalTitle = blank(title) ? dishName(spaceId, dishId) : title.trim(); if (blank(finalTitle)) throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "请选择菜品或填写计划名称");
        UUID id = UUID.randomUUID(); jdbc.update("INSERT INTO cooking_plan(id,sync_space_id,dish_id,title,plan_date,meal_slot,servings,note) VALUES (?,?,?,?,?,?,?,?)", id, spaceId, dishId, finalTitle, planDate, mealSlot, servings, note); return plan(spaceId, id);
    }
    public List<CookingPlan> plans(UUID spaceId, LocalDate from, LocalDate to) { return jdbc.query("SELECT id FROM cooking_plan WHERE sync_space_id=? AND plan_date BETWEEN ? AND ? ORDER BY plan_date,meal_slot", (rs, row) -> plan(spaceId, rs.getObject(1, UUID.class)), spaceId, from, to); }
    public List<ScheduleItem> schedule(UUID spaceId, LocalDate date, String mealTime) { List<CookingPlan> source=plans(spaceId,date,date); int total=source.size(); List<ScheduleItem> result=new ArrayList<>(); for(int i=0;i<total;i++){ CookingPlan p=source.get(i); result.add(new ScheduleItem(p.id(),p.title(),Math.max(0,(total-i)*15),i==0?"关键路径":"可并行",p.mealSlot())); } return result; }
    @Transactional
    public CookingPlan updatePlanStatus(UUID spaceId, UUID planId, String status) { ownedPlan(spaceId, planId); jdbc.update("UPDATE cooking_plan SET status=?,version=version+1,updated_at=now() WHERE id=?", status, planId); return plan(spaceId, planId); }
    @Transactional
    public void archivePlan(UUID spaceId, UUID planId) { ownedPlan(spaceId, planId); jdbc.update("DELETE FROM cooking_plan WHERE id=?", planId); }

    private ShoppingList shoppingList(UUID spaceId, UUID id) { var list = jdbc.query("SELECT title,version FROM shopping_list WHERE id=? AND sync_space_id=?", rs -> { if (!rs.next()) throw notFound("购物清单不存在"); return new Object[]{rs.getString(1), rs.getLong(2)}; }, id, spaceId); return new ShoppingList(id, (String) list[0], (Long) list[1], jdbc.query("SELECT id,name,quantity_text,checked,category,estimated_price,priority,have_it FROM shopping_item WHERE shopping_list_id=? ORDER BY position", (rs, row) -> new ShoppingItem(rs.getObject(1, UUID.class), rs.getString(2), rs.getString(3), rs.getBoolean(4), rs.getString(5), rs.getBigDecimal(6), rs.getString(7), rs.getBoolean(8)), id)); }
    private FamilyMenu menu(UUID spaceId, UUID id) { var value = jdbc.query("SELECT title,dining_date,note,status,version FROM family_menu WHERE id=? AND sync_space_id=?", rs -> { if (!rs.next()) throw notFound("家庭菜单不存在"); return new Object[]{rs.getString(1), rs.getObject(2, LocalDate.class), rs.getString(3), rs.getString(4), rs.getLong(5)}; }, id, spaceId); return new FamilyMenu(id, (String)value[0], (LocalDate)value[1], (String)value[2], (String)value[3], (Long)value[4], jdbc.query("SELECT id,dish_id,name,servings,note FROM family_menu_item WHERE family_menu_id=? ORDER BY position", (rs,row)->new MenuItem(rs.getObject(1, UUID.class),rs.getObject(2, UUID.class),rs.getString(3),rs.getInt(4),rs.getString(5)),id)); }
    private CookingPlan plan(UUID spaceId, UUID id) { return jdbc.query("SELECT id,dish_id,title,plan_date,meal_slot,servings,status,note,version FROM cooking_plan WHERE id=? AND sync_space_id=?", rs -> { if (!rs.next()) throw notFound("制作计划不存在"); return new CookingPlan(rs.getObject(1,UUID.class),rs.getObject(2,UUID.class),rs.getString(3),rs.getObject(4,LocalDate.class),rs.getString(5),rs.getInt(6),rs.getString(7),rs.getString(8),rs.getLong(9)); }, id, spaceId); }
    private void ownedList(UUID spaceId, UUID id) { Integer count=jdbc.queryForObject("SELECT count(*) FROM shopping_list WHERE id=? AND sync_space_id=? AND status='ACTIVE'",Integer.class,id,spaceId); if(count==null||count!=1) throw notFound("购物清单不存在"); }
    private void ownedMenu(UUID spaceId, UUID id) { Integer count=jdbc.queryForObject("SELECT count(*) FROM family_menu WHERE id=? AND sync_space_id=?",Integer.class,id,spaceId); if(count==null||count!=1) throw notFound("家庭菜单不存在"); }
    private void ownedPlan(UUID spaceId, UUID id) { Integer count=jdbc.queryForObject("SELECT count(*) FROM cooking_plan WHERE id=? AND sync_space_id=?",Integer.class,id,spaceId); if(count==null||count!=1) throw notFound("制作计划不存在"); }
    private void touchList(UUID id){jdbc.update("UPDATE shopping_list SET version=version+1,updated_at=now() WHERE id=?",id);} private void touchMenu(UUID id){jdbc.update("UPDATE family_menu SET version=version+1,updated_at=now() WHERE id=?",id);}
    private String dishName(UUID spaceId, UUID dishId) { if(dishId==null) return null; return jdbc.query("SELECT d.name FROM recommended_dish d JOIN recommendation_batch b ON b.id=d.batch_id WHERE d.id=? AND b.sync_space_id=?",rs->rs.next()?rs.getString(1):null,dishId,spaceId); }
    private String categoryOf(String name) { String n=name==null?"":name; if(n.contains("肉")||n.contains("鸡")||n.contains("牛")||n.contains("猪")) return "肉类区"; if(n.contains("鱼")||n.contains("虾")||n.contains("海鲜")) return "海鲜区"; if(n.contains("油")||n.contains("盐")||n.contains("酱")||n.contains("醋")) return "调料区"; return "蔬菜区"; }
    private java.math.BigDecimal estimatedPrice(String name) { return java.math.BigDecimal.valueOf(2 + Math.abs((name==null?"":name).hashCode()%180)/10d).setScale(2, java.math.RoundingMode.HALF_UP); }
    private List<ShoppingItemInput> missingItems(String json) { try { List<Map<String,Object>> items=mapper.readValue(json,new TypeReference<>(){}); List<ShoppingItemInput> result=new ArrayList<>(); for(Map<String,Object> item:items) if(Boolean.FALSE.equals(item.get("available"))) result.add(new ShoppingItemInput(String.valueOf(item.get("name")), item.get("amount")==null?null:String.valueOf(item.get("amount")))); return result; } catch(Exception e){return List.of();} }
    private boolean blank(String value){return value==null||value.isBlank();} private BusinessException notFound(String message){return new BusinessException(ErrorCode.NOT_FOUND,HttpStatus.NOT_FOUND,message);} private record DishSource(String name,String ingredients){}
    private String json(Object value){try{return mapper.writeValueAsString(value);}catch(Exception e){throw new IllegalStateException(e);}}
    private record MenuSeed(String name,String category,String method,int minutes,double cost){}
    public record ShoppingItemInput(String name,String quantity){} public record ShoppingItem(UUID id,String name,String quantity,boolean checked,String category,java.math.BigDecimal estimatedPrice,String priority,boolean haveIt){} public record ShoppingList(UUID id,String title,long version,List<ShoppingItem> items){}
    public record MenuItem(UUID id,UUID dishId,String name,int servings,String note){} public record FamilyMenu(UUID id,String title,LocalDate diningDate,String note,String status,long version,List<MenuItem> items){}
    public record CookingPlan(UUID id,UUID dishId,String title,LocalDate planDate,String mealSlot,int servings,String status,String note,long version){}
    public record ScheduleItem(UUID id,String title,int minutesBeforeMeal,String path,String mealSlot){}
}
