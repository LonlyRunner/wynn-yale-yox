CREATE TABLE app_account (
    id UUID PRIMARY KEY,
    provider VARCHAR(30) NOT NULL,
    provider_subject_hash CHAR(64) NOT NULL,
    nickname VARCHAR(80),
    avatar_url VARCHAR(500),
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (provider, provider_subject_hash)
);

CREATE TABLE account_space (
    account_id UUID PRIMARY KEY REFERENCES app_account(id) ON DELETE CASCADE,
    sync_space_id UUID NOT NULL UNIQUE REFERENCES sync_space(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
