package cn.chuxiaoban.sync;

import cn.chuxiaoban.common.api.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/sync/guest")
public class GuestIdentityController {
    private final GuestIdentityService identityService;

    public GuestIdentityController(GuestIdentityService identityService) { this.identityService = identityService; }

    @PostMapping("/init")
    public ApiResponse<GuestTokenData> init(@Valid @RequestBody(required = false) InitRequest request,
                                            HttpServletRequest httpRequest) {
        var session = identityService.initialize(request == null ? null : request.devicePublicId());
        return ApiResponse.ok(new GuestTokenData(session.accessToken(), session.refreshToken(), 3600), requestId(httpRequest));
    }

    @PostMapping("/refresh")
    public ApiResponse<RefreshedTokenData> refresh(@Valid @RequestBody RefreshRequest request, HttpServletRequest httpRequest) {
        var token = identityService.refresh(request.refreshToken());
        return ApiResponse.ok(new RefreshedTokenData(token.accessToken(), token.expiresIn()), requestId(httpRequest));
    }

    private String requestId(HttpServletRequest request) { return (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE); }

    public record InitRequest(@Size(max = 200) String devicePublicId) {}
    public record GuestTokenData(String accessToken, String refreshToken, long expiresIn) {}
    public record RefreshRequest(@jakarta.validation.constraints.NotBlank String refreshToken) {}
    public record RefreshedTokenData(String accessToken, long expiresIn) {}
}
