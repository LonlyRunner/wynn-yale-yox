CREATE TABLE knowledge_document (
    id UUID PRIMARY KEY,
    title VARCHAR(180) NOT NULL,
    content TEXT NOT NULL,
    tags_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    embedding_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    source_type VARCHAR(30) NOT NULL DEFAULT 'curated',
    source_url VARCHAR(500),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_knowledge_document_updated ON knowledge_document(updated_at DESC);

CREATE TABLE knowledge_video (
    id UUID PRIMARY KEY,
    document_id UUID REFERENCES knowledge_document(id) ON DELETE SET NULL,
    title VARCHAR(180) NOT NULL,
    video_url VARCHAR(500) NOT NULL,
    cover_url VARCHAR(500),
    duration_seconds INTEGER CHECK (duration_seconds IS NULL OR duration_seconds BETWEEN 0 AND 86400),
    platform VARCHAR(30) NOT NULL DEFAULT 'other',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_knowledge_video_document ON knowledge_video(document_id, created_at DESC);

INSERT INTO knowledge_document (id, title, content, tags_json, source_type)
VALUES
 ('d0000000-0000-4000-8000-000000000001', '厨房安全：热油与明火', '热油下锅前确认食材表面干燥，锅边保持干净。出现油锅起火时立即关火并用锅盖覆盖，切勿用水泼洒。使用明火后确认阀门已关闭。', '["安全","热油","明火"]', 'curated'),
 ('d0000000-0000-4000-8000-000000000002', '家常菜调味基础', '先少量加盐，再根据口味逐步调整。酱油、蚝油等含盐调味料应一起计算，出锅前再做最后校味。', '["调味","基础"]', 'curated'),
 ('d0000000-0000-4000-8000-000000000003', '食材保存小贴士', '叶菜去除腐叶后冷藏并保持干燥；肉类按一次用量分装冷冻。剩菜应尽快冷藏，食用前彻底加热。', '["保存","食材"]', 'curated')
ON CONFLICT (id) DO NOTHING;
