package cn.chuxiaoban.chat;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/chat")
public class KitchenChatController {
    private final KitchenChatService service;
    public KitchenChatController(KitchenChatService service) { this.service = service; }

    @PostMapping
    public ApiResponse<KitchenChatService.ChatReply> chat(@Valid @RequestBody ChatRequest body, HttpServletRequest request) {
        request.getAttribute(GuestAuthenticationFilter.SPACE_ID); // authentication boundary
        return ApiResponse.ok(service.reply(body.message(), body.context()), (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    public record ChatRequest(@NotBlank @Size(max = 1000) String message, @Size(max = 1000) String context) {}
}
