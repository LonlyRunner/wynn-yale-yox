package cn.chuxiaoban.notification;
import cn.chuxiaoban.common.api.ApiResponse; import cn.chuxiaoban.common.web.RequestIdFilter; import cn.chuxiaoban.sync.GuestAuthenticationFilter; import jakarta.servlet.http.HttpServletRequest; import jakarta.validation.Valid; import jakarta.validation.constraints.NotNull; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/v1/notifications") public class NotificationController {
 private final NotificationService service; public NotificationController(NotificationService service){this.service=service;}
 @GetMapping public ApiResponse<List<NotificationService.NotificationItem>> list(@RequestParam(defaultValue="false") boolean unreadOnly,@RequestParam(defaultValue="30") int limit,HttpServletRequest req){return ok(service.list(space(req),unreadOnly,limit),req);}
 @PostMapping("/{id}/read") public ApiResponse<Void> read(@PathVariable UUID id,HttpServletRequest req){service.markRead(space(req),id);return ok(null,req);}
 private UUID space(HttpServletRequest r){return (UUID)r.getAttribute(GuestAuthenticationFilter.SPACE_ID);} private <T> ApiResponse<T> ok(T d,HttpServletRequest r){return ApiResponse.ok(d,(String)r.getAttribute(RequestIdFilter.ATTRIBUTE));}
}
