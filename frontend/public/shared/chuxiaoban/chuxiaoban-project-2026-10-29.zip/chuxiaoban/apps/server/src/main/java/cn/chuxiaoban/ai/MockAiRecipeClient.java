package cn.chuxiaoban.ai;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConditionalOnProperty(name = "cxb.ai.provider", havingValue = "mock", matchIfMissing = true)
public class MockAiRecipeClient implements AiRecipeClient {
    @Override
    public Recipe create(String dishName, int servings, boolean beginnerMode) {
        return new Recipe(10, List.of(
                new Step(1, "鸡蛋打入碗中，加少许盐搅散；处理刀具时保持手指远离刀刃。", "not_applicable", 2, List.of()),
                new Step(2, "锅烧热后放油，中火倒入蛋液，边缘凝固时翻面。", "medium", 3, List.of("热油可能飞溅，请保持距离。")),
                new Step(3, "加入切好的食材翻炒至出汁，尝味后关火装盘。", "medium", 5, List.of("确认燃气灶关闭。"))
        ), List.of("热油和刀具使用时请保持注意力。", "生熟食材使用不同砧板。"));
    }
}
