package cn.chuxiaoban.ai;

import java.util.List;

public interface AiRecognitionClient {
    List<RecognitionItem> recognize(byte[] image, String contentType, String note);

    record RecognitionItem(String name, String quantity, String category, double confidence, boolean needsConfirmation,
                           List<String> possibleAllergens) {}
}
