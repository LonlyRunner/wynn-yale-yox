ALTER TABLE household_order_item ADD COLUMN note varchar(300);
