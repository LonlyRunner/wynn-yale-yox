package cn.chuxiaoban.knowledge;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotNull;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/feedbacks")
public class CookingFeedbackController {
    private final CookingFeedbackService service;
    public CookingFeedbackController(CookingFeedbackService service) { this.service = service; }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApiResponse<CookingFeedbackService.FeedbackData> create(@Valid @RequestBody Body body, HttpServletRequest request) {
        var data = service.create((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), new CookingFeedbackService.FeedbackRequest(body.recipeId(), body.rating(), body.actualMinutes(), body.notes(), body.improvements(), body.failures(), body.familyFeedback(), body.autoTags(), body.aiSuggestion()));
        return ApiResponse.ok(data, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    @PutMapping("/{feedbackId}")
    public ApiResponse<CookingFeedbackService.FeedbackData> update(@PathVariable UUID feedbackId, @Valid @RequestBody UpdateBody body, HttpServletRequest request) {
        var data = service.update((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), feedbackId, body.expectedVersion(), body.rating(), body.actualMinutes(), body.notes());
        return ApiResponse.ok(data, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    public record Body(@NotNull UUID recipeId, @NotNull @Min(1) @Max(5) Integer rating, @NotNull @Min(1) @Max(1440) Integer actualMinutes, @Size(max = 2000) String notes, @Size(max = 2000) String improvements, @Size(max = 2000) String failures, @Size(max = 2000) String familyFeedback, java.util.List<String> autoTags, @Size(max = 2000) String aiSuggestion) {}
    public record UpdateBody(@NotNull @Min(1) Long expectedVersion, @NotNull @Min(1) @Max(5) Integer rating, @NotNull @Min(1) @Max(1440) Integer actualMinutes, @Size(max = 2000) String notes) {}
}
