package cn.chuxiaoban.oss;

import java.io.InputStream;
import java.net.URI;
import java.time.Duration;

public interface ObjectStorage {
    void put(String objectKey, InputStream content, long size, String contentType);
    URI signedGetUrl(String objectKey, Duration validity);
    void delete(String objectKey);
}
