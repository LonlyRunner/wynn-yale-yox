CREATE TABLE app_notification (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id) ON DELETE CASCADE,
    type VARCHAR(40) NOT NULL,
    title VARCHAR(160) NOT NULL,
    body VARCHAR(2000) NOT NULL,
    payload_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_notification_space_created ON app_notification(sync_space_id, created_at DESC);
