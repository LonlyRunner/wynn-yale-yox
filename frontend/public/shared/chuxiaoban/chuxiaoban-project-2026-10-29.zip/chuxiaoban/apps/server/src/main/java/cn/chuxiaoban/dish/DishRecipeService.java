package cn.chuxiaoban.dish;

import cn.chuxiaoban.ai.AiRecipeClient;
import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class DishRecipeService {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public DishRecipeService(JdbcTemplate jdbc, ObjectMapper mapper) { this.jdbc = jdbc; this.mapper = mapper; }

    public RecipeData get(UUID spaceId, UUID dishId) {
        // Older clients pass the recommended_dish id while the feedback/history
        // pages pass the recipe id. Accept both identifiers for a stable route.
        return jdbc.query("SELECT r.id,d.name,r.steps_json::text,r.safety_warnings_json::text FROM recipe r JOIN recommended_dish d ON d.id=r.recommended_dish_id JOIN recommendation_batch b ON b.id=d.batch_id WHERE (r.recommended_dish_id=? OR r.id=?) AND b.sync_space_id=?",
                rs -> {
                    if (!rs.next()) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "菜谱不存在");
                    try {
                        return new RecipeData(rs.getObject(1, UUID.class), rs.getString(2), mapper.readTree(rs.getString(3)), mapper.readTree(rs.getString(4)));
                    } catch (JsonProcessingException ex) { throw new IllegalStateException("菜谱数据损坏", ex); }
                }, dishId, dishId, spaceId);
    }

    public record RecipeData(UUID id, String dishName, JsonNode steps, JsonNode safetyWarnings) {}
}
