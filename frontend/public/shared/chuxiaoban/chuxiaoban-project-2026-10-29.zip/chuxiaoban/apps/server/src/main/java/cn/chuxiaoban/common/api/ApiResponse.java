package cn.chuxiaoban.common.api;

import com.fasterxml.jackson.annotation.JsonProperty;

public record ApiResponse<T>(String code, String message, T data, @JsonProperty("request_id") String requestId) {
    public static <T> ApiResponse<T> ok(T data, String requestId) {
        return new ApiResponse<>("OK", "success", data, requestId);
    }
}
