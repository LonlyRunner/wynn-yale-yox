/** Anonymous identity and cross-device synchronization. */
package cn.chuxiaoban.sync;
