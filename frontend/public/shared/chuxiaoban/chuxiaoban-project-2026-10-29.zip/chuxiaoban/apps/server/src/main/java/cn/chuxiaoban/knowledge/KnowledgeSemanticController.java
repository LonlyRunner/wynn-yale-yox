package cn.chuxiaoban.knowledge;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.common.web.RequestIdFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/knowledge")
public class KnowledgeSemanticController {
    private final KnowledgeSemanticService service;
    public KnowledgeSemanticController(KnowledgeSemanticService service) { this.service = service; }

    @GetMapping("/search")
    public ApiResponse<KnowledgeSemanticService.SearchPage> search(@RequestParam String q, @RequestParam(defaultValue = "10") int limit, HttpServletRequest request) {
        try { return ok(service.search(q, limit), request); } catch (IllegalArgumentException e) { throw bad(e); }
    }

    @GetMapping("/documents/{id}")
    public ApiResponse<KnowledgeSemanticService.KnowledgeDocument> document(@PathVariable UUID id, HttpServletRequest request) {
        try { return ok(service.get(id), request); } catch (Exception e) { throw notFound(e); }
    }

    @PostMapping("/documents")
    public ApiResponse<KnowledgeSemanticService.KnowledgeDocument> createDocument(@Valid @RequestBody DocumentRequest body, HttpServletRequest request) {
        try { return ok(service.create(body.title(), body.content(), body.tags(), body.sourceUrl()), request); } catch (IllegalArgumentException e) { throw bad(e); }
    }

    @GetMapping("/videos")
    public ApiResponse<List<KnowledgeSemanticService.VideoItem>> videos(@RequestParam(required = false, name = "document_id") UUID documentId, HttpServletRequest request) { return ok(service.videos(documentId), request); }

    @PostMapping("/videos")
    public ApiResponse<KnowledgeSemanticService.VideoItem> createVideo(@Valid @RequestBody VideoRequest body, HttpServletRequest request) {
        try { return ok(service.createVideo(body.documentId(), body.title(), body.videoUrl(), body.coverUrl(), body.durationSeconds(), body.platform()), request); } catch (IllegalArgumentException e) { throw bad(e); }
    }

    private <T> ApiResponse<T> ok(T data, HttpServletRequest request) { return ApiResponse.ok(data, (String) request.getAttribute(RequestIdFilter.ATTRIBUTE)); }
    private ResponseStatusException bad(Exception e) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, e.getMessage()); }
    private ResponseStatusException notFound(Exception e) { return new ResponseStatusException(HttpStatus.NOT_FOUND, e.getMessage()); }

    public record DocumentRequest(@NotBlank @Size(max = 180) String title, @NotBlank @Size(max = 20000) String content, List<String> tags, @Size(max = 500) String sourceUrl) {}
    public record VideoRequest(UUID documentId, @NotBlank @Size(max = 180) String title, @NotBlank @Size(max = 500) String videoUrl, @Size(max = 500) String coverUrl, Integer durationSeconds, String platform) {}
}
