/** Dish recommendation use cases. */
package cn.chuxiaoban.recommendation;
