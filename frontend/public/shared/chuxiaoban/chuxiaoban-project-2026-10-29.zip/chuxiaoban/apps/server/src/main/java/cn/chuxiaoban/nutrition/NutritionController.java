package cn.chuxiaoban.nutrition;
import cn.chuxiaoban.common.api.ApiResponse; import cn.chuxiaoban.common.web.RequestIdFilter; import jakarta.servlet.http.HttpServletRequest; import org.springframework.web.bind.annotation.*; import java.util.*;
@RestController @RequestMapping("/api/v1/data") public class NutritionController {
 private final NutritionService nutrition; private final PriceService prices; public NutritionController(NutritionService n,PriceService p){nutrition=n;prices=p;}
 @GetMapping("/nutrition/search") public ApiResponse<List<NutritionService.NutritionItem>> nutrition(@RequestParam String q,@RequestParam(defaultValue="10") int limit,HttpServletRequest r){return ok(nutrition.search(q,limit),r);}
 @GetMapping("/prices") public ApiResponse<PriceService.PriceQuote> price(@RequestParam String ingredient,@RequestParam(required=false) String region,HttpServletRequest r){return ok(prices.quote(ingredient,region),r);}
 private <T> ApiResponse<T> ok(T d,HttpServletRequest r){return ApiResponse.ok(d,(String)r.getAttribute(RequestIdFilter.ATTRIBUTE));}
}
