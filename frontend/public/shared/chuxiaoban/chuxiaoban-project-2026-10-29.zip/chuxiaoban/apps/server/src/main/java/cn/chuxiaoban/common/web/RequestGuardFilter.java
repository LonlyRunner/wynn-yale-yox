package cn.chuxiaoban.common.web;

import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.script.DefaultRedisScript;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/** Best-effort Redis guard for duplicate writes and abusive request bursts. */
@Component
public class RequestGuardFilter extends OncePerRequestFilter {
    private static final Set<String> MUTATING = Set.of("POST", "PUT", "PATCH", "DELETE");
    private static final DefaultRedisScript<Long> INCREMENT = new DefaultRedisScript<>("return redis.call('incr', KEYS[1])", Long.class);
    private final StringRedisTemplate redis;

    public RequestGuardFilter(ObjectProvider<StringRedisTemplate> redis) { this.redis = redis.getIfAvailable(); }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException {
        if (redis == null || !MUTATING.contains(request.getMethod()) || !request.getRequestURI().startsWith("/api/")) { chain.doFilter(request, response); return; }
        try {
            String idempotencyKey = request.getHeader("Idempotency-Key");
            if (idempotencyKey != null && !idempotencyKey.isBlank()) {
                String key = "cxb:idempotency:" + request.getRequestURI() + ":" + idempotencyKey.trim();
                Boolean acquired = redis.opsForValue().setIfAbsent(key, "1", Duration.ofMinutes(10));
                if (Boolean.FALSE.equals(acquired)) { writeError(response, 409, "请求已处理，请勿重复提交"); return; }
            }
            String bucket = "cxb:rate:" + request.getRequestURI() + ":" + clientKey(request) + ":" + (System.currentTimeMillis() / 60_000);
            Long count = redis.execute(INCREMENT, List.of(bucket));
            if (count != null && count == 1) redis.expire(bucket, Duration.ofMinutes(2));
            int limit = request.getRequestURI().contains("/recognition/upload") ? 10 : 60;
            if (count != null && count > limit) { writeError(response, 429, "操作太频繁，请稍后再试"); return; }
        } catch (RuntimeException ignored) {
            // Redis is an optional guard; a Redis outage must not take down the core workflow.
        }
        chain.doFilter(request, response);
    }

    private String clientKey(HttpServletRequest request) { return request.getRemoteAddr() == null ? "unknown" : request.getRemoteAddr(); }
    private void writeError(HttpServletResponse response, int status, String message) throws IOException {
        response.setStatus(status); response.setContentType("application/json;charset=UTF-8");
        response.getWriter().write("{\"code\":\"REQUEST_GUARD\",\"message\":\"" + message + "\",\"data\":null,\"request_id\":\"" + UUID.randomUUID() + "\"}");
    }
}
