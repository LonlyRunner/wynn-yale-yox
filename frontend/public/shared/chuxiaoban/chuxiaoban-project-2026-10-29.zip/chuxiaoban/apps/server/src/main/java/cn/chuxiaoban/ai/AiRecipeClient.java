package cn.chuxiaoban.ai;

import java.util.List;

public interface AiRecipeClient {
    Recipe create(String dishName, int servings, boolean beginnerMode);

    record Recipe(int totalMinutes, List<Step> steps, List<String> safetyWarnings) {}
    record Step(int stepNo, String action, String heatLevel, int durationMinutes, List<String> warnings) {}
}
