package cn.chuxiaoban.common.api;

public enum ErrorCode {
    INVALID_ARGUMENT,
    UNAUTHORIZED,
    FORBIDDEN,
    NOT_FOUND,
    CONFLICT,
    INVALID_FILE,
    RATE_LIMITED,
    AI_TIMEOUT,
    AI_INVALID_RESPONSE,
    INTERNAL_ERROR
}
