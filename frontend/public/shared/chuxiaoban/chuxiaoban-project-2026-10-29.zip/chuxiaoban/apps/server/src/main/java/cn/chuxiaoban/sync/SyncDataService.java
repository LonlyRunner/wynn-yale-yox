package cn.chuxiaoban.sync;

import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class SyncDataService {
    private final JdbcTemplate jdbc;
    public SyncDataService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public Snapshot snapshot(UUID spaceId) {
        var row = jdbc.query("SELECT version,updated_at FROM sync_space WHERE id=? AND status='ACTIVE'", rs -> {
            if (!rs.next()) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "同步空间不存在");
            return new SpaceRow(rs.getLong(1), rs.getTimestamp(2).toInstant());
        }, spaceId);
        int tasks = count("SELECT count(*) FROM recognition_task WHERE sync_space_id=?", spaceId);
        int batches = count("SELECT count(*) FROM recommendation_batch WHERE sync_space_id=?", spaceId);
        int feedback = count("SELECT count(*) FROM cooking_feedback WHERE sync_space_id=? AND deleted_at IS NULL", spaceId);
        int devices = count("SELECT count(*) FROM guest_device WHERE sync_space_id=? AND revoked_at IS NULL", spaceId);
        return new Snapshot(row.version, row.updatedAt, tasks, batches, feedback, devices);
    }

    @Transactional
    public void delete(UUID spaceId) {
        Integer active = jdbc.queryForObject("SELECT count(*) FROM sync_space WHERE id=? AND status='ACTIVE'", Integer.class, spaceId);
        if (active == null || active != 1) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "同步空间不存在");
        jdbc.update("UPDATE upload_object SET deleted_at=now(),status='DELETED' WHERE sync_space_id=?", spaceId);
        jdbc.update("UPDATE cooking_feedback SET deleted_at=now(),updated_at=now() WHERE sync_space_id=?", spaceId);
        jdbc.update("UPDATE guest_device SET revoked_at=now(),token_version=token_version+1 WHERE sync_space_id=?", spaceId);
        jdbc.update("UPDATE sync_space SET status='DELETED',version=version+1,updated_at=now() WHERE id=?", spaceId);
    }

    public List<SyncChange> changes(UUID spaceId, Instant since, int limit) {
        Instant point = since == null ? Instant.EPOCH : since;
        int safeLimit = Math.max(1, Math.min(100, limit));
        List<SyncChange> changes = new ArrayList<>();
        changes.addAll(jdbc.query("SELECT id,updated_at,status FROM recognition_task WHERE sync_space_id=? AND updated_at>?", (rs, row) -> new SyncChange("recognition_task", rs.getObject(1, UUID.class), rs.getString(3), rs.getTimestamp(2).toInstant()), spaceId, Timestamp.from(point)));
        changes.addAll(jdbc.query("SELECT id,updated_at,status FROM recommendation_batch WHERE sync_space_id=? AND updated_at>?", (rs, row) -> new SyncChange("recommendation_batch", rs.getObject(1, UUID.class), rs.getString(3), rs.getTimestamp(2).toInstant()), spaceId, Timestamp.from(point)));
        changes.addAll(jdbc.query("SELECT id,updated_at,deleted_at FROM cooking_feedback WHERE sync_space_id=? AND updated_at>?", (rs, row) -> new SyncChange("cooking_feedback", rs.getObject(1, UUID.class), rs.getTimestamp(3) == null ? "updated" : "deleted", rs.getTimestamp(2).toInstant()), spaceId, Timestamp.from(point)));
        return changes.stream().sorted(Comparator.comparing(SyncChange::updatedAt).reversed()).limit(safeLimit).toList();
    }

    public SyncEntityDetail detail(UUID spaceId, String entityType, UUID entityId) {
        Map<String, Object> payload = new LinkedHashMap<>();
        switch (entityType) {
            case "recognition_task" -> {
                var rows = jdbc.query("SELECT status,updated_at FROM recognition_task WHERE id=? AND sync_space_id=?", (rs, row) -> Map.<String, Object>of("status", rs.getString(1), "updated_at", rs.getTimestamp(2).toInstant()), entityId, spaceId);
                if (rows.isEmpty()) throw notFound();
                payload.putAll(rows.get(0));
                payload.put("confirmed_ingredients", jdbc.query("SELECT name,quantity_text,position FROM confirmed_ingredient WHERE task_id=? ORDER BY position", (rs, row) -> {
                    // quantity_text is optional; Map.of rejects null values and used to turn
                    // a valid synchronized recognition task into an HTTP 500.
                    Map<String, Object> ingredient = new LinkedHashMap<>();
                    ingredient.put("name", rs.getString(1));
                    ingredient.put("quantity", rs.getString(2));
                    ingredient.put("position", rs.getInt(3));
                    return ingredient;
                }, entityId));
            }
            case "recommendation_batch" -> {
                var rows = jdbc.query("SELECT status,version,updated_at FROM recommendation_batch WHERE id=? AND sync_space_id=?", (rs, row) -> Map.<String, Object>of("status", rs.getString(1), "version", rs.getLong(2), "updated_at", rs.getTimestamp(3).toInstant()), entityId, spaceId);
                if (rows.isEmpty()) throw notFound();
                payload.putAll(rows.get(0));
                payload.put("dishes", jdbc.query("SELECT id,name,difficulty,prep_minutes,cook_minutes,replaced_dish_id FROM recommended_dish WHERE batch_id=? ORDER BY created_at", (rs, row) -> { Map<String, Object> dish = new LinkedHashMap<>(); dish.put("id", rs.getObject(1, UUID.class)); dish.put("name", rs.getString(2)); dish.put("difficulty", rs.getInt(3)); dish.put("prep_minutes", rs.getInt(4)); dish.put("cook_minutes", rs.getInt(5)); dish.put("replaced_dish_id", rs.getObject(6, UUID.class)); return dish; }, entityId));
            }
            case "cooking_feedback" -> {
                var rows = jdbc.query("SELECT recipe_id,rating,actual_minutes,notes,updated_at,deleted_at FROM cooking_feedback WHERE id=? AND sync_space_id=?", (rs, row) -> { Map<String, Object> feedback = new LinkedHashMap<>(); feedback.put("recipe_id", rs.getObject(1, UUID.class)); feedback.put("rating", rs.getInt(2)); feedback.put("actual_minutes", rs.getInt(3)); feedback.put("notes", rs.getString(4)); feedback.put("updated_at", rs.getTimestamp(5).toInstant()); feedback.put("deleted", rs.getTimestamp(6) != null); return feedback; }, entityId, spaceId);
                if (rows.isEmpty()) throw notFound();
                payload.putAll(rows.get(0));
            }
            default -> throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "不支持的同步实体类型");
        }
        return new SyncEntityDetail(entityType, entityId, payload);
    }

    private BusinessException notFound() { return new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "同步实体不存在"); }

    private int count(String sql, UUID spaceId) { Integer value = jdbc.queryForObject(sql, Integer.class, spaceId); return value == null ? 0 : value; }
    private record SpaceRow(long version, Instant updatedAt) {}
    public record Snapshot(long version, Instant updatedAt, int recognitionTasks, int recommendationBatches, int feedbackCount, int deviceCount) {}
    public record SyncChange(String entityType, UUID entityId, String action, Instant updatedAt) {}
    public record SyncEntityDetail(String entityType, UUID entityId, Map<String, Object> payload) {}
}
