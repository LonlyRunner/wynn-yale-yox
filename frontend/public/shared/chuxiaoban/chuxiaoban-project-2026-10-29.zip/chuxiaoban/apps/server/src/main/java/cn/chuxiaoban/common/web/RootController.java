package cn.chuxiaoban.common.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class RootController {
    @GetMapping("/")
    public Map<String, Object> root() {
        return Map.of(
                "service", "chuxiaoban-server",
                "status", "UP",
                "message", "厨小伴 API 服务已启动",
                "health", "/actuator/health",
                "api_docs", "/swagger-ui/index.html");
    }
}
