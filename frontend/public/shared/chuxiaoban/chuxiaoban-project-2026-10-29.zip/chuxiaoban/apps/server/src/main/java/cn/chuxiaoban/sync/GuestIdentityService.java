package cn.chuxiaoban.sync;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class GuestIdentityService {
    private final JdbcTemplate jdbc;
    private final GuestTokenService tokenService;

    public GuestIdentityService(JdbcTemplate jdbc, GuestTokenService tokenService) {
        this.jdbc = jdbc;
        this.tokenService = tokenService;
    }

    @Transactional
    public GuestSession initialize(String devicePublicId) {
        String normalized = devicePublicId == null || devicePublicId.isBlank()
                ? UUID.randomUUID().toString() : devicePublicId.trim();
        if (normalized.length() > 200) throw new IllegalArgumentException("device_public_id too long");
        String deviceHash = sha256(normalized);
        var existing = jdbc.query("SELECT gd.id,gd.sync_space_id,gd.token_version FROM guest_device gd JOIN sync_space ss ON ss.id=gd.sync_space_id WHERE gd.device_public_id_hash=? AND gd.revoked_at IS NULL AND ss.status='ACTIVE'",
                rs -> rs.next() ? new ExistingDevice(rs.getObject(1, UUID.class), rs.getObject(2, UUID.class), rs.getLong(3)) : null,
                deviceHash);
        if (existing != null) {
            return new GuestSession(existing.deviceId(), existing.spaceId(), existing.tokenVersion(),
                    tokenService.issue(existing.deviceId(), existing.spaceId(), existing.tokenVersion(), 3600),
                    tokenService.issue(existing.deviceId(), existing.spaceId(), existing.tokenVersion(), 60L * 60 * 24 * 30));
        }
        UUID deviceId = UUID.randomUUID();
        UUID spaceId = UUID.randomUUID();
        jdbc.update("INSERT INTO sync_space(id,status,version) VALUES (?, 'ACTIVE', 1)", spaceId);
        jdbc.update("INSERT INTO guest_device(id,sync_space_id,device_public_id_hash) VALUES (?,?,?)",
                deviceId, spaceId, deviceHash);
        return new GuestSession(deviceId, spaceId, 1, tokenService.issue(deviceId, spaceId, 1, 3600),
                tokenService.issue(deviceId, spaceId, 1, 60L * 60 * 24 * 30));
    }

    public RefreshedAccessToken refresh(String refreshToken) {
        if (refreshToken == null || refreshToken.isBlank()) throw new IllegalArgumentException("refresh_token required");
        var claims = tokenService.verify(refreshToken);
        return new RefreshedAccessToken(tokenService.issue(claims.deviceId(), claims.spaceId(), claims.tokenVersion(), 3600), 3600);
    }

    private String sha256(String value) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(value.getBytes(StandardCharsets.UTF_8))); }
        catch (Exception ex) { throw new IllegalStateException("device hash failed", ex); }
    }

    public record GuestSession(UUID deviceId, UUID spaceId, long tokenVersion, String accessToken, String refreshToken) {}
    public record RefreshedAccessToken(String accessToken, long expiresIn) {}
    private record ExistingDevice(UUID deviceId, UUID spaceId, long tokenVersion) {}
}
