package cn.chuxiaoban.sync;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Base64;
import java.util.Map;
import java.util.UUID;

@Service
public class GuestTokenService {
    private static final Base64.Encoder B64 = Base64.getUrlEncoder().withoutPadding();
    private static final Base64.Decoder B64D = Base64.getUrlDecoder();
    private final ObjectMapper mapper;
    private final byte[] secret;

    public GuestTokenService(ObjectMapper mapper,
                             @Value("${cxb.token-secret}") String secret) {
        if (secret.length() < 32) throw new IllegalStateException("CXB_TOKEN_SECRET must contain at least 32 characters");
        this.mapper = mapper;
        this.secret = secret.getBytes(StandardCharsets.UTF_8);
    }

    public String issue(UUID deviceId, UUID spaceId, long tokenVersion, long ttlSeconds) {
        long now = Instant.now().getEpochSecond();
        Map<String, Object> header = Map.of("alg", "HS256", "typ", "JWT");
        Map<String, Object> payload = Map.of("sub", deviceId.toString(), "space", spaceId.toString(),
                "ver", tokenVersion, "iat", now, "exp", now + ttlSeconds);
        String encodedHeader = encode(header);
        String encodedPayload = encode(payload);
        String unsigned = encodedHeader + "." + encodedPayload;
        return unsigned + "." + B64.encodeToString(sign(unsigned));
    }

    public Claims verify(String token) {
        try {
            String[] parts = token.split("\\.", -1);
            if (parts.length != 3 || !constantTimeEquals(sign(parts[0] + "." + parts[1]), B64D.decode(parts[2])))
                throw new IllegalArgumentException("invalid signature");
            Map<?, ?> payload = mapper.readValue(B64D.decode(parts[1]), Map.class);
            long exp = ((Number) payload.get("exp")).longValue();
            if (Instant.now().getEpochSecond() >= exp) throw new IllegalArgumentException("expired");
            return new Claims(UUID.fromString((String) payload.get("sub")), UUID.fromString((String) payload.get("space")),
                    ((Number) payload.get("ver")).longValue(), exp);
        } catch (Exception ex) {
            throw new IllegalArgumentException("invalid guest token", ex);
        }
    }

    private String encode(Object value) {
        try { return B64.encodeToString(mapper.writeValueAsBytes(value)); }
        catch (JsonProcessingException ex) { throw new IllegalStateException("token encoding failed", ex); }
    }

    private byte[] sign(String value) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(secret, "HmacSHA256"));
            return mac.doFinal(value.getBytes(StandardCharsets.UTF_8));
        } catch (Exception ex) { throw new IllegalStateException("token signing failed", ex); }
    }

    private boolean constantTimeEquals(byte[] left, byte[] right) {
        if (left.length != right.length) return false;
        int result = 0;
        for (int i = 0; i < left.length; i++) result |= left[i] ^ right[i];
        return result == 0;
    }

    public record Claims(UUID deviceId, UUID spaceId, long tokenVersion, long expiresAt) {}
}
