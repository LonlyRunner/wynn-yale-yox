package cn.chuxiaoban.sync;

import cn.chuxiaoban.common.api.ApiResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;
import java.time.Instant;

@RestController
@RequestMapping("/api/v1/sync")
public class SyncCodeController {
    private final SyncCodeService service;
    private final SyncDataService dataService;
    public SyncCodeController(SyncCodeService service, SyncDataService dataService) { this.service = service; this.dataService = dataService; }
    @PostMapping("/code")
    public ApiResponse<SyncCodeService.SyncCode> create(HttpServletRequest request) {
        return ApiResponse.ok(service.create((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID)), requestId(request));
    }
    @PostMapping("/bind")
    public ApiResponse<GuestIdentityController.GuestTokenData> bind(@Valid @RequestBody BindRequest body, HttpServletRequest request) {
        var data = service.bind((UUID) request.getAttribute(GuestAuthenticationFilter.DEVICE_ID), body.syncCode(), body.confirmed());
        return ApiResponse.ok(data, requestId(request));
    }
    @GetMapping("/status")
    public ApiResponse<SyncCodeService.SyncStatus> status(HttpServletRequest request) {
        return ApiResponse.ok(service.status((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), (UUID) request.getAttribute(GuestAuthenticationFilter.DEVICE_ID)), requestId(request));
    }
    @PostMapping("/unbind")
    public ApiResponse<GuestIdentityController.GuestTokenData> unbind(HttpServletRequest request) {
        var data = service.unbind((UUID) request.getAttribute(GuestAuthenticationFilter.DEVICE_ID));
        return ApiResponse.ok(data, requestId(request));
    }
    @GetMapping("/data")
    public ApiResponse<SyncDataService.Snapshot> data(HttpServletRequest request) {
        return ApiResponse.ok(dataService.snapshot((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID)), requestId(request));
    }
    @DeleteMapping("/data")
    public ApiResponse<Void> delete(HttpServletRequest request) {
        dataService.delete((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID));
        return ApiResponse.ok(null, requestId(request));
    }
    @GetMapping("/changes")
    public ApiResponse<java.util.List<SyncDataService.SyncChange>> changes(@RequestParam(required = false) String since, @RequestParam(defaultValue = "50") int limit, HttpServletRequest request) {
        Instant point = null;
        try { if (since != null && !since.isBlank()) point = Instant.parse(since); } catch (Exception ignored) { }
        return ApiResponse.ok(dataService.changes((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), point, limit), requestId(request));
    }
    @GetMapping("/changes/{entityType}/{entityId}")
    public ApiResponse<SyncDataService.SyncEntityDetail> changeDetail(@PathVariable String entityType, @PathVariable UUID entityId, HttpServletRequest request) {
        return ApiResponse.ok(dataService.detail((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), entityType, entityId), requestId(request));
    }
    private String requestId(HttpServletRequest request) { return (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE); }
    public record BindRequest(@Size(min = 8, max = 20) String syncCode, boolean confirmed) {}
}
