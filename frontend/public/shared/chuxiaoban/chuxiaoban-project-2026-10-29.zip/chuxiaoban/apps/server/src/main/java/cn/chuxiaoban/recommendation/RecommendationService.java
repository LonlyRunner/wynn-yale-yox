package cn.chuxiaoban.recommendation;

import cn.chuxiaoban.ai.AiRecommendationClient;
import cn.chuxiaoban.ai.AiRecipeClient;
import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import cn.chuxiaoban.recognition.AllergenRuleService;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@Service
public class RecommendationService {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final AiRecommendationClient ai;
    private final AllergenRuleService allergenRules;
    private final AiRecipeClient recipeClient;

    public RecommendationService(JdbcTemplate jdbc, ObjectMapper mapper, AiRecommendationClient ai, AllergenRuleService allergenRules, AiRecipeClient recipeClient) {
        this.jdbc = jdbc; this.mapper = mapper; this.ai = ai; this.allergenRules = allergenRules; this.recipeClient = recipeClient;
    }

    @Transactional
    public RecommendationBatch recommend(UUID spaceId, UUID taskId, Preferences preferences) {
        Integer confirmed = jdbc.queryForObject("SELECT count(*) FROM recognition_task WHERE id=? AND sync_space_id=? AND status='CONFIRMED'", Integer.class, taskId, spaceId);
        if (confirmed == null || confirmed != 1)
            throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "请先确认识别出的食材");
        List<AiRecommendationClient.Ingredient> ingredients = jdbc.query("SELECT name,quantity_text,allergen_codes::text FROM confirmed_ingredient WHERE task_id=? ORDER BY position", (rs, row) -> {
            try { return new AiRecommendationClient.Ingredient(rs.getString(1), rs.getString(2), mapper.readValue(rs.getString(3), new TypeReference<List<String>>() {})); }
            catch (JsonProcessingException ex) { throw new IllegalStateException(ex); }
        }, taskId);
        AiRecommendationClient.Preferences aiPreferences = new AiRecommendationClient.Preferences(
                preferences == null ? List.of() : safe(preferences.flavors()),
                preferences == null ? List.of() : safe(preferences.allergenCodes()),
                preferences == null ? List.of() : safe(preferences.excludedIngredients()),
                preferences == null || preferences.variationHint() == null ? "" : preferences.variationHint());
        List<AiRecommendationClient.Recommendation> candidates = List.of();
        for (int attempt = 0; attempt < 2 && candidates.size() < 3; attempt++) {
            try {
                String variation = aiPreferences.variationHint() + (attempt == 0 ? "" : "-retry");
                var requestPreferences = new AiRecommendationClient.Preferences(aiPreferences.flavors(), aiPreferences.allergenCodes(), aiPreferences.excludedIngredients(), variation);
                var generated = ai.recommend(ingredients, requestPreferences);
                candidates = (generated == null ? List.<AiRecommendationClient.Recommendation>of() : generated).stream()
                        .filter(item -> !conflicts(item, aiPreferences)).toList();
            } catch (IllegalStateException ex) {
                if (attempt == 1) throw new BusinessException(ErrorCode.AI_INVALID_RESPONSE, HttpStatus.UNPROCESSABLE_ENTITY, "推荐结果暂不可用，请重试");
            }
        }
        if (candidates.size() < 3)
            throw new BusinessException(ErrorCode.AI_INVALID_RESPONSE, HttpStatus.UNPROCESSABLE_ENTITY, "无法生成满足忌口条件的三道菜");
        UUID batchId = UUID.randomUUID();
        jdbc.update("INSERT INTO recommendation_batch(id,sync_space_id,recognition_task_id,preferences_json,status) VALUES (?,?,?,?::jsonb,?)",
                batchId, spaceId, taskId, json(aiPreferences), "READY");
        List<DishSummary> dishes = new ArrayList<>();
        for (var candidate : candidates.subList(0, 3)) {
            UUID dishId = UUID.randomUUID();
            int difficulty = Math.max(1, Math.min(5, candidate.difficulty()));
            int prepMinutes = Math.max(0, Math.min(1440, candidate.prepMinutes()));
            int cookMinutes = Math.max(1, Math.min(1440, candidate.cookMinutes()));
            jdbc.update("INSERT INTO recommended_dish(id,batch_id,name,difficulty,prep_minutes,cook_minutes,ingredients_json,warnings_json) VALUES (?,?,?,?,?,?,?::jsonb,?::jsonb)",
                    dishId, batchId, candidate.name(), difficulty, prepMinutes, cookMinutes,
                    json(candidate.ingredients()), json(candidate.warnings()));
            var recipe = recipeClient.create(candidate.name(), 3, true);
            jdbc.update("INSERT INTO recipe(id,recommended_dish_id,schema_version,steps_json,safety_warnings_json,content_hash) VALUES (?,?,?,?::jsonb,?::jsonb,?)",
                    UUID.randomUUID(), dishId, "1.0", json(recipe.steps()), json(recipe.safetyWarnings()), contentHash(recipe));
            dishes.add(new DishSummary(dishId, candidate.name(), difficulty, prepMinutes, cookMinutes, candidate.ingredients(), candidate.warnings(), candidate.reason()));
        }
        return new RecommendationBatch(batchId, 1L, dishes);
    }

    @Transactional
    public DishSummary replace(UUID spaceId, UUID dishId) {
        var batch = jdbc.query("SELECT b.id,b.recognition_task_id,d.name FROM recommended_dish d JOIN recommendation_batch b ON b.id=d.batch_id WHERE d.id=? AND b.sync_space_id=? AND b.status='READY'", rs -> {
            if (!rs.next()) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "推荐菜品不存在");
            return new ReplaceContext(rs.getObject(1, UUID.class), rs.getObject(2, UUID.class), rs.getString(3));
        }, dishId, spaceId);
        List<AiRecommendationClient.Ingredient> ingredients = jdbc.query("SELECT name,quantity_text,allergen_codes::text FROM confirmed_ingredient WHERE task_id=? ORDER BY position", (rs, row) -> {
            try { return new AiRecommendationClient.Ingredient(rs.getString(1), rs.getString(2), mapper.readValue(rs.getString(3), new TypeReference<List<String>>() {})); }
            catch (JsonProcessingException ex) { throw new IllegalStateException(ex); }
        }, batch.taskId());
        var preferences = new AiRecommendationClient.Preferences(List.of(), List.of(), List.of(), "replace-" + dishId + "-" + System.nanoTime());
        AiRecommendationClient.Recommendation candidate = null;
        for (int attempt = 0; attempt < 2 && candidate == null; attempt++) {
            try {
                var generated = ai.recommend(ingredients, new AiRecommendationClient.Preferences(preferences.flavors(), preferences.allergenCodes(), preferences.excludedIngredients(), preferences.variationHint() + "-" + attempt));
                candidate = generated == null ? null : generated.stream().filter(item -> !item.name().equalsIgnoreCase(batch.currentName()) && !conflicts(item, preferences)).findFirst().orElse(null);
            } catch (IllegalStateException ex) {
                if (attempt == 1) throw new BusinessException(ErrorCode.AI_INVALID_RESPONSE, HttpStatus.UNPROCESSABLE_ENTITY, "暂时无法替换菜品，请重试");
            }
        }
        if (candidate == null) throw new BusinessException(ErrorCode.AI_INVALID_RESPONSE, HttpStatus.UNPROCESSABLE_ENTITY, "暂时没有合适的替换菜品");
        return insertDish(batch.batchId(), candidate, dishId);
    }

    @Transactional
    public DishSummary replace(UUID spaceId, UUID batchId, UUID dishId) {
        Integer owned = jdbc.queryForObject("SELECT count(*) FROM recommended_dish d JOIN recommendation_batch b ON b.id=d.batch_id WHERE d.id=? AND b.id=? AND b.sync_space_id=?", Integer.class, dishId, batchId, spaceId);
        if (owned == null || owned != 1) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "推荐菜品不存在");
        return replace(spaceId, dishId);
    }

    @Transactional
    public DishSummary replace(UUID spaceId, UUID batchId, UUID dishId, long expectedVersion) {
        Long current = jdbc.queryForObject("SELECT version FROM recommendation_batch WHERE id=? AND sync_space_id=? AND status='READY' FOR UPDATE", Long.class, batchId, spaceId);
        if (current == null) throw new BusinessException(ErrorCode.NOT_FOUND, HttpStatus.NOT_FOUND, "推荐批次不存在");
        if (current != expectedVersion) throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "推荐列表已在另一端更新，请刷新后再试");
        return replace(spaceId, batchId, dishId);
    }

    private DishSummary insertDish(UUID batchId, AiRecommendationClient.Recommendation candidate, UUID replacedDishId) {
        UUID dishId = UUID.randomUUID();
        int difficulty = Math.max(1, Math.min(5, candidate.difficulty()));
        int prepMinutes = Math.max(0, Math.min(1440, candidate.prepMinutes()));
        int cookMinutes = Math.max(1, Math.min(1440, candidate.cookMinutes()));
        jdbc.update("INSERT INTO recommended_dish(id,batch_id,name,difficulty,prep_minutes,cook_minutes,ingredients_json,warnings_json,replaced_dish_id) VALUES (?,?,?,?,?,?,?::jsonb,?::jsonb,?)",
                dishId, batchId, candidate.name(), difficulty, prepMinutes, cookMinutes, json(candidate.ingredients()), json(candidate.warnings()), replacedDishId);
        var recipe = recipeClient.create(candidate.name(), 3, true);
        jdbc.update("INSERT INTO recipe(id,recommended_dish_id,schema_version,steps_json,safety_warnings_json,content_hash) VALUES (?,?,?,?::jsonb,?::jsonb,?)",
                UUID.randomUUID(), dishId, "1.0", json(recipe.steps()), json(recipe.safetyWarnings()), contentHash(recipe));
        jdbc.update("UPDATE recommendation_batch SET version=version+1,updated_at=now() WHERE id=?", batchId);
        return new DishSummary(dishId, candidate.name(), difficulty, prepMinutes, cookMinutes, candidate.ingredients(), candidate.warnings(), candidate.reason());
    }

    private boolean conflicts(AiRecommendationClient.Recommendation item, AiRecommendationClient.Preferences preferences) {
        Set<String> excluded = new HashSet<>(preferences.allergenCodes());
        return item.ingredients().stream().anyMatch(ingredient -> {
            Set<String> codes = allergenRules.allergensFor(ingredient.name(), List.of());
            return allergenRules.conflicts(codes, excluded) || preferences.excludedIngredients().stream().anyMatch(ingredient.name()::contains);
        });
    }

    private List<String> safe(List<String> value) { return value == null ? List.of() : value.stream().filter(Objects::nonNull).limit(50).toList(); }
    private String json(Object value) { try { return mapper.writeValueAsString(value); } catch (JsonProcessingException ex) { throw new IllegalStateException(ex); } }
    private String contentHash(Object value) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(json(value).getBytes(StandardCharsets.UTF_8))); }
        catch (Exception ex) { throw new IllegalStateException(ex); }
    }

    public record Preferences(List<String> flavors, List<String> allergenCodes, List<String> excludedIngredients, String variationHint) {}
    public record RecommendationBatch(UUID batchId, long version, List<DishSummary> dishes) {}
    private record ReplaceContext(UUID batchId, UUID taskId, String currentName) {}
    public record DishSummary(UUID id, String name, int difficulty, int prepMinutes, int cookMinutes,
                              List<AiRecommendationClient.RecommendationIngredient> ingredients, List<String> warnings, String reason) {}
}
