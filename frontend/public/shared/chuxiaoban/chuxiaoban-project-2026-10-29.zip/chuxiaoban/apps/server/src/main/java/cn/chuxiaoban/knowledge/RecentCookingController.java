package cn.chuxiaoban.knowledge;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/knowledge")
public class RecentCookingController {
    private final RecentCookingService service;
    public RecentCookingController(RecentCookingService service) { this.service = service; }
    @GetMapping("/recent")
    public ApiResponse<RecentCookingService.RecentPage> list(@RequestParam(required = false) String cursor, @RequestParam(defaultValue = "20") int limit, HttpServletRequest request) {
        return ApiResponse.ok(service.list((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), cursor, limit), (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }
}
