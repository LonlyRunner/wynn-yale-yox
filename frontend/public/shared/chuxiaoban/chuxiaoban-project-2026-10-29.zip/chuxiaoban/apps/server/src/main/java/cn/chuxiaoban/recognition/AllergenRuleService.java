package cn.chuxiaoban.recognition;

import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AllergenRuleService {
    private static final Map<String, Set<String>> RULES = Map.ofEntries(
            Map.entry("鸡蛋", Set.of("egg")), Map.entry("鸭蛋", Set.of("egg")),
            Map.entry("牛奶", Set.of("milk")), Map.entry("奶油", Set.of("milk")), Map.entry("奶酪", Set.of("milk")),
            Map.entry("花生", Set.of("peanut")), Map.entry("芝麻", Set.of("sesame")), Map.entry("虾", Set.of("crustacean")),
            Map.entry("蟹", Set.of("crustacean")), Map.entry("鱼", Set.of("fish")), Map.entry("小麦", Set.of("wheat")),
            Map.entry("面粉", Set.of("wheat")), Map.entry("大豆", Set.of("soy"))
    );

    public Set<String> allergensFor(String name, Collection<String> modelCodes) {
        Set<String> result = new LinkedHashSet<>(modelCodes == null ? List.of() : modelCodes);
        RULES.forEach((keyword, codes) -> { if (name != null && name.contains(keyword)) result.addAll(codes); });
        return result;
    }

    public boolean conflicts(Collection<String> ingredientCodes, Collection<String> excludedCodes) {
        Set<String> excluded = new HashSet<>(excludedCodes == null ? List.of() : excludedCodes);
        return ingredientCodes.stream().anyMatch(excluded::contains);
    }
}
