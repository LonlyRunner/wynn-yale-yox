/** Recipe retrieval and cooking guidance. */
package cn.chuxiaoban.dish;
