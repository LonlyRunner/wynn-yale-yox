ALTER TABLE household_dish ADD COLUMN category varchar(30) NOT NULL DEFAULT '其他';
UPDATE household_dish SET category=CASE WHEN name IN ('番茄炒蛋','宫保鸡丁','红烧肉','鱼香肉丝','麻婆豆腐','清蒸鲈鱼') THEN '家常热菜' WHEN name='清炒时蔬' THEN '清爽蔬菜' WHEN name='紫菜蛋花汤' THEN '暖心汤品' WHEN name IN ('米饭','蛋炒饭') THEN '主食' ELSE '其他' END;
