package cn.chuxiaoban.recognition;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.constraints.Size;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/recognition")
public class RecognitionController {
    private final RecognitionService service;
    public RecognitionController(RecognitionService service) { this.service = service; }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ApiResponse<RecognitionService.RecognitionResult> upload(
            @RequestPart("image") MultipartFile image,
            @RequestParam(value = "note", required = false) @Size(max = 300) String note,
            HttpServletRequest request) {
        UUID spaceId = (UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID);
        var data = service.recognize(spaceId, image, note);
        return ApiResponse.ok(data, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }
}
