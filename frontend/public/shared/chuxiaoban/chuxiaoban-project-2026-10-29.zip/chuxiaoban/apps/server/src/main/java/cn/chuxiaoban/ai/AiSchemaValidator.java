package cn.chuxiaoban.ai;

import com.fasterxml.jackson.databind.JsonNode;

import java.util.Set;

/** Lightweight runtime checks matching the versioned AI JSON contracts. */
final class AiSchemaValidator {
    private static final Set<String> CATEGORIES = Set.of("vegetable", "fruit", "meat", "seafood", "egg_dairy", "staple", "seasoning", "processed", "other");
    private static final Set<String> HEAT_LEVELS = Set.of("off", "low", "medium", "high", "not_applicable");

    private AiSchemaValidator() {}

    static JsonNode array(JsonNode root, String canonical, String legacy, String label, int max, int min) {
        if (root.isArray()) {
            if (root.size() < min || root.size() > max) throw invalid(label + " count");
            return root;
        }
        JsonNode value = root.path(canonical);
        if (!value.isArray() && legacy != null) value = root.path(legacy);
        if (!value.isArray() || value.size() < min || value.size() > max) throw invalid(label + " count");
        return value;
    }

    static void recognition(JsonNode root) {
        JsonNode items = array(root, "recognized_items", "items", "recognition items", 50, 0);
        for (JsonNode item : items) {
            if (!item.isObject() || !text(item, "name", 1, 50) || !item.has("quantity") || !item.has("category")
                    || !item.path("confidence").isNumber() || item.path("confidence").asDouble() < 0 || item.path("confidence").asDouble() > 1
                    || !item.path("needs_confirmation").isBoolean() || !strings(item.path("possible_allergens"), 40)) throw invalid("recognition item");
            if (!CATEGORIES.contains(item.path("category").asText())) throw invalid("recognition category");
            if (!item.path("quantity").isNull() && (!item.path("quantity").isTextual() || item.path("quantity").asText().length() > 40)) throw invalid("recognition quantity");
        }
    }

    static void recommendations(JsonNode root) {
        JsonNode dishes = array(root, "recommendations", "dishes", "recommendations", 3, 3);
        for (JsonNode dish : dishes) {
            if (!dish.isObject() || !text(dish, "name", 1, 80)) throw invalid("recommendation item");
            if (!integerLike(dish.path("difficulty"), 1, 5) || !integerLike(dish.path("prep_minutes"), 0, 1440) || !integerLike(dish.path("cook_minutes"), 1, 1440)) throw invalid("recommendation timing");
            if (dish.has("reason") && !dish.path("reason").isTextual()) throw invalid("recommendation reason");
            if (dish.has("warnings") && !strings(dish.path("warnings"), 300)) throw invalid("recommendation warnings");
            JsonNode ingredients = dish.path("ingredients");
            if (!ingredients.isArray() || ingredients.size() > 50) throw invalid("recommendation ingredients");
            for (JsonNode ingredient : ingredients) {
                if (!(ingredient.isTextual() || (ingredient.isObject() && text(ingredient, "name", 0, 50)))) throw invalid("recommendation ingredient");
            }
        }
    }

    static void recipe(JsonNode root) {
        if (!number(root, "total_minutes", 1, 1440)) throw invalid("recipe total_minutes");
        JsonNode steps = root.path("steps");
        if (!steps.isArray() || steps.size() < 1 || steps.size() > 30 || !strings(root.path("safety_warnings"), 300)) throw invalid("recipe steps");
        for (JsonNode step : steps) {
            if (!step.isObject() || !number(step, "step_no", 1, Integer.MAX_VALUE) || !text(step, "action", 1, 1000)
                    || !text(step, "heat_level", 1, 30) || !HEAT_LEVELS.contains(step.path("heat_level").asText())
                    || !number(step, "duration_minutes", 0, 1440) || !strings(step.path("warnings"), 300)) throw invalid("recipe step");
        }
    }

    private static boolean number(JsonNode node, String field, int min, int max) { return node.path(field).isIntegralNumber() && node.path(field).asInt() >= min && node.path(field).asInt() <= max; }
    private static boolean integerLike(JsonNode node, int min, int max) { return (node.isIntegralNumber() && node.asInt() >= min && node.asInt() <= max) || (node.isTextual() && !node.asText().isBlank()); }
    private static boolean text(JsonNode node, String field, int min, int max) { return node.path(field).isTextual() && node.path(field).asText().length() >= min && node.path(field).asText().length() <= max; }
    private static boolean strings(JsonNode node, int maxItemLength) { if (!node.isArray() || node.size() > 20) return false; for (JsonNode item : node) if (!item.isTextual() || item.asText().length() > maxItemLength) return false; return true; }
    private static IllegalStateException invalid(String detail) { return new IllegalStateException("AI schema invalid: " + detail); }
}
