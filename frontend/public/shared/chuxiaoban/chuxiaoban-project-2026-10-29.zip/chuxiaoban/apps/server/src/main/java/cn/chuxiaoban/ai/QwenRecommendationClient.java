package cn.chuxiaoban.ai;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import com.fasterxml.jackson.databind.JsonNode;

@Component
@ConditionalOnExpression("'${cxb.ai.provider:mock}' == 'qwen' || '${cxb.ai.provider:mock}' == 'deepseek'")
public class QwenRecommendationClient implements AiRecommendationClient {
    private final OpenAiCompatibleClient client;
    private final ObjectMapper mapper;

    public QwenRecommendationClient(OpenAiCompatibleClient client, ObjectMapper mapper) { this.client = client; this.mapper = mapper; }

    @Override
    public List<Recommendation> recommend(List<Ingredient> ingredients, Preferences preferences) {
        String prompt = "根据确认食材和偏好生成恰好3道互不重复的家常菜。只返回JSON对象 {\"dishes\":[{\"name\":\"\",\"difficulty\":1,\"prep_minutes\":1,\"cook_minutes\":1,\"ingredients\":[{\"name\":\"\",\"amount\":\"\",\"available\":true}],\"reason\":\"\",\"warnings\":[]}]}。不输出医疗功效，不使用确认食材之外的过敏原。本轮变化标记=" + preferences.variationHint() + "。确认食材=" + json(ingredients) + "，偏好=" + json(preferences);
        var result = client.chat(client.textModel(), List.of(Map.of("role", "user", "content", prompt)));
        JsonNode nodes = dishes(result);
        Set<String> available = new HashSet<>();
        for (Ingredient ingredient : ingredients) available.add(ingredient.name());
        List<Recommendation> output = new ArrayList<>();
        for (JsonNode dish : nodes) {
            String name = firstText(dish, "name", "dish_name", "title");
            if (name.isBlank() || name.length() > 80) continue;
            List<RecommendationIngredient> dishIngredients = new ArrayList<>();
            JsonNode ingredientNodes = dish.path("ingredients");
            if (!ingredientNodes.isArray()) ingredientNodes = dish.path("main_ingredients");
            if (ingredientNodes.isArray()) for (JsonNode item : ingredientNodes) {
                if (item.isTextual()) dishIngredients.add(new RecommendationIngredient(item.asText(), "", available.contains(item.asText())));
                else if (item.isObject()) {
                    String ingredientName = firstText(item, "name", "ingredient", "food");
                    if (!ingredientName.isBlank()) dishIngredients.add(new RecommendationIngredient(ingredientName, firstText(item, "amount", "quantity"), item.has("available") ? item.path("available").asBoolean() : available.contains(ingredientName)));
                }
            }
            output.add(new Recommendation(name, parseDifficulty(dish.path("difficulty")), parseInt(dish.path("prep_minutes"), 0), parseInt(dish.path("cook_minutes"), 1), dishIngredients, firstText(dish, "reason", "recommendation_reason"), strings(dish.has("warnings") ? dish.path("warnings") : dish.path("tips"))));
        }
        if (output.size() < 3) throw new IllegalStateException("AI returned fewer than three usable recommendations");
        return output;
    }

    private JsonNode dishes(JsonNode root) {
        if (root.isArray()) return root;
        JsonNode data = root.path("data");
        JsonNode source = data.isObject() ? data : root;
        for (String key : List.of("recommendations", "dishes", "recipes", "items")) {
            JsonNode value = source.path(key);
            if (value.isArray()) return value;
        }
        throw new IllegalStateException("AI response does not contain recommendation items");
    }

    private String firstText(JsonNode node, String... keys) {
        for (String key : keys) if (node.path(key).isTextual()) return node.path(key).asText("").trim();
        return "";
    }

    private int parseDifficulty(JsonNode node) { if (node.isIntegralNumber()) return Math.max(1, Math.min(5, node.asInt())); String value=node.asText("").toLowerCase(); return value.contains("难")||value.contains("hard")?4:value.contains("中")||value.contains("medium")?3:1; }
    private int parseInt(JsonNode node, int fallback) { return node.isIntegralNumber() ? Math.max(0, Math.min(1440, node.asInt())) : fallback; }
    private List<String> strings(JsonNode node) { List<String> values = new ArrayList<>(); if (node.isArray()) for (JsonNode value : node) if (value.isTextual()) values.add(value.asText()); return values; }

    private String json(Object value) { try { return mapper.writeValueAsString(value); } catch (Exception ex) { throw new IllegalStateException(ex); } }
}
