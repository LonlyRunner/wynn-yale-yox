package cn.chuxiaoban.nutrition;
import org.springframework.stereotype.Service; import java.util.*;
@Service public class NutritionService {
 private static final Map<String,NutritionItem> CATALOG=Map.of("鸡蛋",new NutritionItem("鸡蛋",143,12.6,9.5,1.1,"每100克，可食部"),"西红柿",new NutritionItem("西红柿",18,0.9,0.2,3.9,"每100克，可食部"),"鸡胸肉",new NutritionItem("鸡胸肉",133,24.6,3.0,0,"每100克，可食部"),"大米",new NutritionItem("大米",346,7.4,0.8,77.9,"每100克，生重"));
 public List<NutritionItem> search(String query,int limit){String q=query==null?"":query.trim();if(q.isEmpty())throw new IllegalArgumentException("食材不能为空");int n=Math.max(1,Math.min(20,limit));return CATALOG.values().stream().filter(x->x.name().contains(q)||q.contains(x.name())).limit(n).toList();}
 public record NutritionItem(String name,double caloriesKcal,double proteinG,double fatG,double carbohydrateG,String basis){}
}
