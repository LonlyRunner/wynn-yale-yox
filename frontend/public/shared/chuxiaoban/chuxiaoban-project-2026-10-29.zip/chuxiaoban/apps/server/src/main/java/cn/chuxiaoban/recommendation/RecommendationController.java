package cn.chuxiaoban.recommendation;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Size;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Min;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/recommendations")
public class RecommendationController {
    private final RecommendationService service;
    public RecommendationController(RecommendationService service) { this.service = service; }

    @PostMapping
    public ApiResponse<RecommendationService.RecommendationBatch> recommend(@Valid @RequestBody RecommendRequest body, HttpServletRequest request) {
        var preferences = body.preferences() == null ? new RecommendationService.Preferences(List.of(), List.of(), List.of(), body.rerollToken())
                : new RecommendationService.Preferences(body.preferences().flavors(), body.preferences().allergenCodes(), body.preferences().excludedIngredients(), body.rerollToken());
        var result = service.recommend((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), body.recognitionTaskId(), preferences);
        return ApiResponse.ok(result, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    @PostMapping("/{batchId}/replace")
    public ApiResponse<RecommendationService.DishSummary> replace(@PathVariable UUID batchId, @Valid @RequestBody ReplaceRequest body, HttpServletRequest request) {
        var result = service.replace((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), batchId, body.dishId(), body.expectedVersion());
        return ApiResponse.ok(result, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }

    public record RecommendRequest(UUID recognitionTaskId, @Valid PreferenceRequest preferences, @Size(max = 80) String rerollToken) {}
    public record ReplaceRequest(@NotNull UUID dishId, @NotNull @Min(1) Long expectedVersion) {}
    public record PreferenceRequest(@Size(max = 10) List<@Size(max = 30) String> flavors,
                                    @Size(max = 30) List<@Size(max = 40) String> allergenCodes,
                                    @Size(max = 50) List<@Size(max = 50) String> excludedIngredients) {}
}
