CREATE TABLE household_dish_recipe (
 dish_id uuid PRIMARY KEY REFERENCES household_dish(id) ON DELETE CASCADE,
 recipe_json jsonb NOT NULL,
 generated_at timestamptz NOT NULL DEFAULT now()
);
