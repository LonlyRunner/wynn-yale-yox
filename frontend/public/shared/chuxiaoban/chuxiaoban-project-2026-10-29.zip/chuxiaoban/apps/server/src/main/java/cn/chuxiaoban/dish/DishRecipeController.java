package cn.chuxiaoban.dish;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/dishes")
public class DishRecipeController {
    private final DishRecipeService service;
    public DishRecipeController(DishRecipeService service) { this.service = service; }

    @GetMapping("/{dishId}")
    public ApiResponse<DishRecipeService.RecipeData> get(@PathVariable UUID dishId, HttpServletRequest request) {
        var data = service.get((UUID) request.getAttribute(GuestAuthenticationFilter.SPACE_ID), dishId);
        return ApiResponse.ok(data, (String) request.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE));
    }
}
