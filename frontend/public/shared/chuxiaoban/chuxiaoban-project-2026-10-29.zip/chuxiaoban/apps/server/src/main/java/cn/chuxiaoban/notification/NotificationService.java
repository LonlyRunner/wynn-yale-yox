package cn.chuxiaoban.notification;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
import java.util.*;

@Service
public class NotificationService {
    private final JdbcTemplate jdbc; private final ObjectMapper mapper;
    public NotificationService(JdbcTemplate jdbc, ObjectMapper mapper) { this.jdbc = jdbc; this.mapper = mapper; }
    public List<NotificationItem> list(UUID spaceId, boolean unreadOnly, int limit) { int safe = Math.max(1, Math.min(50, limit)); String sql = "SELECT id,type,title,body,read_at,created_at FROM app_notification WHERE sync_space_id=?" + (unreadOnly ? " AND read_at IS NULL" : "") + " ORDER BY created_at DESC LIMIT ?"; return jdbc.query(sql, (rs, row) -> new NotificationItem(rs.getObject(1, UUID.class), rs.getString(2), rs.getString(3), rs.getString(4), rs.getTimestamp(5) == null ? null : rs.getTimestamp(5).toInstant(), rs.getTimestamp(6).toInstant()), spaceId, safe); }
    @Transactional public void markRead(UUID spaceId, UUID id) { int updated = jdbc.update("UPDATE app_notification SET read_at=now() WHERE id=? AND sync_space_id=? AND read_at IS NULL", id, spaceId); if (updated == 0) throw new NoSuchElementException("通知不存在或已读"); }
    @Transactional public NotificationItem create(UUID spaceId, String type, String title, String body, Map<String, Object> payload) { UUID id = UUID.randomUUID(); try { jdbc.update("INSERT INTO app_notification(id,sync_space_id,type,title,body,payload_json) VALUES(?,?,?,?,?,?::jsonb)", id, spaceId, safe(type, 40), safe(title, 160), safe(body, 2000), mapper.writeValueAsString(payload == null ? Map.of() : payload)); } catch (Exception e) { throw new IllegalArgumentException("通知内容无效", e); } return list(spaceId, false, 50).stream().filter(n -> n.id().equals(id)).findFirst().orElseThrow(); }
    private String safe(String s, int max) { String v = s == null ? "" : s.trim(); if (v.isEmpty() || v.length() > max) throw new IllegalArgumentException("通知字段不能为空且不能超过" + max + "个字符"); return v; }
    public record NotificationItem(UUID id, String type, String title, String body, Instant readAt, Instant createdAt) {}
}
