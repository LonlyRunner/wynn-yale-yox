package cn.chuxiaoban.planning;

import cn.chuxiaoban.common.api.ApiResponse;
import cn.chuxiaoban.sync.GuestAuthenticationFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.*;

@RestController
@RequestMapping("/api/v1")
public class PlanningController {
    private final PlanningService service; public PlanningController(PlanningService service){this.service=service;}
    private UUID space(HttpServletRequest r){return (UUID)r.getAttribute(GuestAuthenticationFilter.SPACE_ID);} private String rid(HttpServletRequest r){return (String)r.getAttribute(cn.chuxiaoban.common.web.RequestIdFilter.ATTRIBUTE);}
    @GetMapping("/shopping-lists") public ApiResponse<List<PlanningService.ShoppingList>> lists(HttpServletRequest r){return ApiResponse.ok(service.shoppingLists(space(r)),rid(r));}
    @PostMapping("/shopping-lists") public ApiResponse<PlanningService.ShoppingList> createList(@RequestBody ShoppingListBody b,HttpServletRequest r){return ApiResponse.ok(service.createShoppingList(space(r),b.dishId(),b.title()),rid(r));}
    @PostMapping("/shopping-lists/{listId}/items") public ApiResponse<PlanningService.ShoppingList> addItem(@PathVariable UUID listId,@Valid @RequestBody ItemBody b,HttpServletRequest r){return ApiResponse.ok(service.addShoppingItem(space(r),listId,new PlanningService.ShoppingItemInput(b.name(),b.quantity())),rid(r));}
    @PutMapping("/shopping-lists/{listId}/items/{itemId}") public ApiResponse<PlanningService.ShoppingList> check(@PathVariable UUID listId,@PathVariable UUID itemId,@RequestBody CheckBody b,HttpServletRequest r){return ApiResponse.ok(service.checkShoppingItem(space(r),listId,itemId,b.checked()),rid(r));}
    @DeleteMapping("/shopping-lists/{listId}") public ApiResponse<Void> deleteList(@PathVariable UUID listId,HttpServletRequest r){service.archiveShoppingList(space(r),listId);return ApiResponse.ok(null,rid(r));}
    @GetMapping("/family-menus") public ApiResponse<List<PlanningService.FamilyMenu>> menus(@RequestParam(required=false) LocalDate date,HttpServletRequest r){return ApiResponse.ok(service.menus(space(r),date),rid(r));}
    @PostMapping("/family-menus") public ApiResponse<PlanningService.FamilyMenu> createMenu(@Valid @RequestBody MenuBody b,HttpServletRequest r){return ApiResponse.ok(service.createMenu(space(r),b.title(),b.diningDate(),b.note()),rid(r));}
    @PostMapping("/family-menus/generate") public ApiResponse<PlanningService.FamilyMenu> generateMenu(@Valid @RequestBody GenerateMenuBody b,HttpServletRequest r){return ApiResponse.ok(service.generateMenu(space(r),b.guestCount(),b.budget(),b.occasion(),b.preferences(),b.allergens(),b.diningDate()),rid(r));}
    @PostMapping("/family-menus/{menuId}/items") public ApiResponse<PlanningService.FamilyMenu> addMenuItem(@PathVariable UUID menuId,@Valid @RequestBody MenuItemBody b,HttpServletRequest r){return ApiResponse.ok(service.addMenuItem(space(r),menuId,b.dishId(),b.name(),b.servings(),b.note()),rid(r));}
    @PutMapping("/family-menus/{menuId}/status") public ApiResponse<PlanningService.FamilyMenu> menuStatus(@PathVariable UUID menuId,@Valid @RequestBody StatusBody b,HttpServletRequest r){return ApiResponse.ok(service.updateMenuStatus(space(r),menuId,b.status()),rid(r));}
    @DeleteMapping("/family-menus/{menuId}") public ApiResponse<Void> deleteMenu(@PathVariable UUID menuId,HttpServletRequest r){service.archiveMenu(space(r),menuId);return ApiResponse.ok(null,rid(r));}
    @GetMapping("/cooking-plans") public ApiResponse<List<PlanningService.CookingPlan>> plans(@RequestParam(required=false) LocalDate from,@RequestParam(required=false) LocalDate to,HttpServletRequest r){LocalDate start=from==null?LocalDate.now():from;return ApiResponse.ok(service.plans(space(r),start,to==null?start.plusDays(7):to),rid(r));}
    @GetMapping("/cooking-plans/schedule") public ApiResponse<List<PlanningService.ScheduleItem>> schedule(@RequestParam(required=false) LocalDate date,HttpServletRequest r){return ApiResponse.ok(service.schedule(space(r),date==null?LocalDate.now():date,null),rid(r));}
    @PostMapping("/cooking-plans") public ApiResponse<PlanningService.CookingPlan> createPlan(@Valid @RequestBody PlanBody b,HttpServletRequest r){return ApiResponse.ok(service.createPlan(space(r),b.dishId(),b.title(),b.planDate(),b.mealSlot(),b.servings(),b.note()),rid(r));}
    @PutMapping("/cooking-plans/{planId}/status") public ApiResponse<PlanningService.CookingPlan> planStatus(@PathVariable UUID planId,@Valid @RequestBody StatusBody b,HttpServletRequest r){return ApiResponse.ok(service.updatePlanStatus(space(r),planId,b.status()),rid(r));}
    @DeleteMapping("/cooking-plans/{planId}") public ApiResponse<Void> deletePlan(@PathVariable UUID planId,HttpServletRequest r){service.archivePlan(space(r),planId);return ApiResponse.ok(null,rid(r));}
    public record ShoppingListBody(UUID dishId,@Size(max=120) String title){} public record ItemBody(@NotBlank @Size(max=100) String name,@Size(max=80) String quantity){} public record CheckBody(boolean checked){}
    public record MenuBody(@Size(max=120) String title,@NotNull LocalDate diningDate,@Size(max=500) String note){} public record GenerateMenuBody(@NotNull @Min(1) @Max(20) Integer guestCount,java.math.BigDecimal budget,@Size(max=30) String occasion,List<String> preferences,List<String> allergens,@NotNull LocalDate diningDate){} public record MenuItemBody(UUID dishId,@Size(max=120) String name,@NotNull @Min(1) @Max(20) Integer servings,@Size(max=300) String note){} public record PlanBody(UUID dishId,@Size(max=120) String title,@NotNull LocalDate planDate,@NotBlank @Pattern(regexp="breakfast|lunch|dinner|custom") String mealSlot,@NotNull @Min(1) @Max(20) Integer servings,@Size(max=500) String note){} public record StatusBody(@NotBlank @Pattern(regexp="OPEN|CLOSED|PLANNED|DONE|SKIPPED") String status){}
}
