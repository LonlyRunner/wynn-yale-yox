ALTER TABLE app_account
    ADD COLUMN phone_hash CHAR(64),
    ADD COLUMN phone_verified_at TIMESTAMPTZ,
    ADD COLUMN terms_accepted_at TIMESTAMPTZ,
    ADD COLUMN privacy_accepted_at TIMESTAMPTZ,
    ADD COLUMN last_login_at TIMESTAMPTZ;

ALTER TABLE shopping_item
    ADD COLUMN category VARCHAR(40) NOT NULL DEFAULT '其他',
    ADD COLUMN estimated_price NUMERIC(10,2),
    ADD COLUMN priority VARCHAR(10) NOT NULL DEFAULT '普通',
    ADD COLUMN have_it BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE family_menu
    ADD COLUMN guest_count INTEGER NOT NULL DEFAULT 2,
    ADD COLUMN budget NUMERIC(10,2),
    ADD COLUMN occasion VARCHAR(30) NOT NULL DEFAULT '日常',
    ADD COLUMN preferences_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN allergens_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    ADD COLUMN total_estimated_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
    ADD COLUMN serving_suggestion VARCHAR(1000);

ALTER TABLE family_menu_item
    ADD COLUMN category VARCHAR(30) NOT NULL DEFAULT '热菜',
    ADD COLUMN cooking_method VARCHAR(30),
    ADD COLUMN estimated_cost NUMERIC(10,2) NOT NULL DEFAULT 0,
    ADD COLUMN estimated_minutes INTEGER NOT NULL DEFAULT 15,
    ADD COLUMN nutrition_json JSONB NOT NULL DEFAULT '{}'::jsonb;
