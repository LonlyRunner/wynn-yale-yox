package cn.chuxiaoban.account;

import cn.chuxiaoban.sync.GuestTokenService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class AccountService {
    private final JdbcTemplate jdbc;
    private final GuestTokenService tokens;

    public AccountService(JdbcTemplate jdbc, GuestTokenService tokens) { this.jdbc = jdbc; this.tokens = tokens; }

    @Transactional
    public AccountSession login(String provider, String subject, String devicePublicId, String nickname, String avatarUrl, boolean termsAccepted, boolean privacyAccepted) {
        String p = normalize(provider, "provider", 30); String s = required(subject, "provider_subject", 200); String device = required(devicePublicId, "device_public_id", 200);
        String subjectHash = sha256(s); UUID account = jdbc.query("SELECT id FROM app_account WHERE provider=? AND provider_subject_hash=? AND status='ACTIVE'", rs -> rs.next() ? rs.getObject(1, UUID.class) : null, p, subjectHash);
        if (account == null) { account = UUID.randomUUID(); jdbc.update("INSERT INTO app_account(id,provider,provider_subject_hash,nickname,avatar_url,terms_accepted_at,privacy_accepted_at,last_login_at) VALUES(?,?,?,?,?,CASE WHEN ? THEN now() ELSE NULL END,CASE WHEN ? THEN now() ELSE NULL END,now())", account, p, subjectHash, trim(nickname, 80), trim(avatarUrl, 500), termsAccepted, privacyAccepted); }
        else jdbc.update("UPDATE app_account SET nickname=COALESCE(?,nickname),avatar_url=COALESCE(?,avatar_url),terms_accepted_at=CASE WHEN ? THEN COALESCE(terms_accepted_at,now()) ELSE terms_accepted_at END,privacy_accepted_at=CASE WHEN ? THEN COALESCE(privacy_accepted_at,now()) ELSE privacy_accepted_at END,last_login_at=now(),updated_at=now() WHERE id=?", trim(nickname, 80), trim(avatarUrl, 500), termsAccepted, privacyAccepted, account);
        UUID space = jdbc.query("SELECT sync_space_id FROM account_space WHERE account_id=?", rs -> rs.next() ? rs.getObject(1, UUID.class) : null, account);
        if (space == null) { space = UUID.randomUUID(); jdbc.update("INSERT INTO sync_space(id,status,version) VALUES (?,'ACTIVE',1)", space); jdbc.update("INSERT INTO account_space(account_id,sync_space_id) VALUES (?,?)", account, space); }
        String deviceHash = sha256(p + ":" + device); UUID deviceId = jdbc.query("SELECT id FROM guest_device WHERE device_public_id_hash=? AND revoked_at IS NULL", rs -> rs.next() ? rs.getObject(1, UUID.class) : null, deviceHash);
        long version = 1;
        if (deviceId == null) { deviceId = UUID.randomUUID(); jdbc.update("INSERT INTO guest_device(id,sync_space_id,device_public_id_hash) VALUES(?,?,?)", deviceId, space, deviceHash); }
        else { jdbc.update("UPDATE guest_device SET sync_space_id=?, token_version=token_version+1, last_seen_at=now() WHERE id=?", space, deviceId); version = jdbc.queryForObject("SELECT token_version FROM guest_device WHERE id=?", Long.class, deviceId); }
        return new AccountSession(account, space, deviceId, tokens.issue(deviceId, space, version, 3600), tokens.issue(deviceId, space, version, 60L * 60 * 24 * 30));
    }

    @Transactional
    public AccountSession link(UUID sourceSpaceId, UUID currentDeviceId, String provider, String subject, String nickname, String avatarUrl, boolean termsAccepted, boolean privacyAccepted) {
        String p = normalize(provider, "provider", 30); String hash = sha256(required(subject, "provider_subject", 200));
        UUID account = jdbc.query("SELECT id FROM app_account WHERE provider=? AND provider_subject_hash=?", rs -> rs.next() ? rs.getObject(1, UUID.class) : null, p, hash);
        if (account == null) { account = UUID.randomUUID(); jdbc.update("INSERT INTO app_account(id,provider,provider_subject_hash,nickname,avatar_url,terms_accepted_at,privacy_accepted_at,last_login_at) VALUES(?,?,?,?,?,CASE WHEN ? THEN now() ELSE NULL END,CASE WHEN ? THEN now() ELSE NULL END,now())", account, p, hash, trim(nickname, 80), trim(avatarUrl, 500), termsAccepted, privacyAccepted); }
        UUID existing = jdbc.query("SELECT sync_space_id FROM account_space WHERE account_id=?", rs -> rs.next() ? rs.getObject(1, UUID.class) : null, account);
        UUID targetSpace = existing == null ? sourceSpaceId : existing;
        if (existing == null) jdbc.update("INSERT INTO account_space(account_id,sync_space_id) VALUES (?,?)", account, sourceSpaceId);
        else if (!existing.equals(sourceSpaceId)) mergeSpace(sourceSpaceId, existing);
        jdbc.update("UPDATE guest_device SET sync_space_id=?,token_version=token_version+1,last_seen_at=now() WHERE id=?", targetSpace, currentDeviceId);
        long version = jdbc.queryForObject("SELECT token_version FROM guest_device WHERE id=?", Long.class, currentDeviceId);
        return new AccountSession(account, targetSpace, currentDeviceId, tokens.issue(currentDeviceId, targetSpace, version, 3600), tokens.issue(currentDeviceId, targetSpace, version, 60L * 60 * 24 * 30));
    }

    public AccountProfile profile(UUID accountId) { return jdbc.query("SELECT id,provider,nickname,avatar_url,status FROM app_account WHERE id=?", (rs, row) -> new AccountProfile(rs.getObject(1, UUID.class), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5)), accountId).stream().findFirst().orElseThrow(); }
    public AccountProfile profileForSpace(UUID spaceId) { return jdbc.query("SELECT a.id,a.provider,a.nickname,a.avatar_url,a.status FROM app_account a JOIN account_space s ON s.account_id=a.id WHERE s.sync_space_id=?", (rs,row)->new AccountProfile(rs.getObject(1,UUID.class),rs.getString(2),rs.getString(3),rs.getString(4),rs.getString(5)),spaceId).stream().findFirst().orElseThrow(() -> new IllegalArgumentException("当前仍为游客身份")); }
    private void mergeSpace(UUID source, UUID target) { for (String table : java.util.List.of("upload_object","recognition_task","recommendation_batch","cooking_feedback","shopping_list","family_menu","cooking_plan","app_notification")) jdbc.update("UPDATE " + table + " SET sync_space_id=? WHERE sync_space_id=?", target, source); jdbc.update("UPDATE guest_device SET sync_space_id=?,token_version=token_version+1 WHERE sync_space_id=?",target,source); jdbc.update("UPDATE sync_space SET status='MERGED',updated_at=now() WHERE id=?",source); }
    private String normalize(String v, String name, int max) { String s = required(v, name, max).toLowerCase(); if (!s.matches("[a-z0-9_-]+")) throw new IllegalArgumentException(name + " 格式不合法"); return s; }
    private String required(String v, String name, int max) { String s = v == null ? "" : v.trim(); if (s.isEmpty() || s.length() > max) throw new IllegalArgumentException(name + " 不能为空且长度不能超过" + max); return s; }
    private String trim(String v, int max) { return v == null ? null : v.trim().substring(0, Math.min(max, v.trim().length())); }
    private String sha256(String v) { try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(v.getBytes(StandardCharsets.UTF_8))); } catch (NoSuchAlgorithmException e) { throw new IllegalStateException(e); } }
    public record AccountSession(UUID accountId, UUID spaceId, UUID deviceId, String accessToken, String refreshToken) {}
    public record AccountProfile(UUID id, String provider, String nickname, String avatarUrl, String status) {}
}
