CREATE TABLE sync_space (
    id UUID PRIMARY KEY,
    status VARCHAR(20) NOT NULL,
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);

CREATE TABLE guest_device (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    device_public_id_hash VARCHAR(128) NOT NULL UNIQUE,
    token_version BIGINT NOT NULL DEFAULT 1,
    last_seen_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    revoked_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_guest_device_space ON guest_device(sync_space_id);

CREATE TABLE sync_code (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    code_hash VARCHAR(128) NOT NULL UNIQUE,
    expires_at TIMESTAMPTZ NOT NULL,
    attempts INTEGER NOT NULL DEFAULT 0,
    used_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE upload_object (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    object_key VARCHAR(300) NOT NULL UNIQUE,
    mime_type VARCHAR(100) NOT NULL,
    size_bytes BIGINT NOT NULL CHECK (size_bytes > 0 AND size_bytes <= 10485760),
    sha256 CHAR(64) NOT NULL,
    status VARCHAR(30) NOT NULL,
    expires_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_upload_space ON upload_object(sync_space_id);

CREATE TABLE recognition_task (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    upload_object_id UUID NOT NULL REFERENCES upload_object(id),
    status VARCHAR(30) NOT NULL,
    schema_version VARCHAR(20) NOT NULL,
    model_ref VARCHAR(120),
    error_code VARCHAR(60),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_recognition_space_created ON recognition_task(sync_space_id, created_at DESC);

CREATE TABLE recognized_item (
    id UUID PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES recognition_task(id) ON DELETE CASCADE,
    name VARCHAR(80) NOT NULL,
    quantity_text VARCHAR(80),
    category VARCHAR(30) NOT NULL,
    confidence NUMERIC(4,3) NOT NULL CHECK (confidence BETWEEN 0 AND 1),
    needs_confirmation BOOLEAN NOT NULL,
    allergen_codes JSONB NOT NULL DEFAULT '[]'::jsonb
);

CREATE TABLE confirmed_ingredient (
    id UUID PRIMARY KEY,
    task_id UUID NOT NULL REFERENCES recognition_task(id) ON DELETE CASCADE,
    source_item_id UUID REFERENCES recognized_item(id),
    name VARCHAR(80) NOT NULL,
    quantity_text VARCHAR(80),
    allergen_codes JSONB NOT NULL DEFAULT '[]'::jsonb,
    position INTEGER NOT NULL CHECK (position >= 0)
);

CREATE TABLE recommendation_batch (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    recognition_task_id UUID NOT NULL REFERENCES recognition_task(id),
    preferences_json JSONB NOT NULL DEFAULT '{}'::jsonb,
    status VARCHAR(30) NOT NULL,
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE recommended_dish (
    id UUID PRIMARY KEY,
    batch_id UUID NOT NULL REFERENCES recommendation_batch(id) ON DELETE CASCADE,
    name VARCHAR(120) NOT NULL,
    difficulty SMALLINT NOT NULL CHECK (difficulty BETWEEN 1 AND 5),
    prep_minutes INTEGER NOT NULL CHECK (prep_minutes BETWEEN 0 AND 1440),
    cook_minutes INTEGER NOT NULL CHECK (cook_minutes BETWEEN 1 AND 1440),
    ingredients_json JSONB NOT NULL,
    warnings_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    replaced_dish_id UUID REFERENCES recommended_dish(id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE recipe (
    id UUID PRIMARY KEY,
    recommended_dish_id UUID NOT NULL UNIQUE REFERENCES recommended_dish(id),
    schema_version VARCHAR(20) NOT NULL,
    steps_json JSONB NOT NULL,
    safety_warnings_json JSONB NOT NULL DEFAULT '[]'::jsonb,
    content_hash CHAR(64) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE cooking_feedback (
    id UUID PRIMARY KEY,
    sync_space_id UUID NOT NULL REFERENCES sync_space(id),
    recipe_id UUID NOT NULL REFERENCES recipe(id),
    rating SMALLINT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    actual_minutes INTEGER NOT NULL CHECK (actual_minutes BETWEEN 1 AND 1440),
    notes VARCHAR(2000),
    version BIGINT NOT NULL DEFAULT 1,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    deleted_at TIMESTAMPTZ
);
CREATE INDEX idx_feedback_space_updated ON cooking_feedback(sync_space_id, updated_at DESC);

