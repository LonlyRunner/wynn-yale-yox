CREATE TABLE household_dish (id uuid PRIMARY KEY, sync_space_id uuid NOT NULL REFERENCES sync_space(id), name varchar(120) NOT NULL, description varchar(300), available boolean NOT NULL DEFAULT true, created_at timestamptz NOT NULL DEFAULT now());
CREATE INDEX household_dish_space_idx ON household_dish(sync_space_id);
CREATE TABLE household_order (id uuid PRIMARY KEY, sync_space_id uuid NOT NULL REFERENCES sync_space(id), status varchar(20) NOT NULL DEFAULT 'NEW', note varchar(300), created_at timestamptz NOT NULL DEFAULT now());
CREATE TABLE household_order_item (id uuid PRIMARY KEY, order_id uuid NOT NULL REFERENCES household_order(id), dish_name varchar(120) NOT NULL, quantity integer NOT NULL CHECK (quantity BETWEEN 1 AND 20));
