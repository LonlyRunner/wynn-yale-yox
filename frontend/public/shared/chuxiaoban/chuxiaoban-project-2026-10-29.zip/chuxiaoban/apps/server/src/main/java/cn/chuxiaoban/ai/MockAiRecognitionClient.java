package cn.chuxiaoban.ai;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConditionalOnProperty(name = "cxb.ai.provider", havingValue = "mock", matchIfMissing = true)
public class MockAiRecognitionClient implements AiRecognitionClient {
    @Override
    public List<RecognitionItem> recognize(byte[] image, String contentType, String note) {
        // 仅用于本地联调；真实供应商适配器必须替换此 Bean，并经过 Schema/过敏原校验。
        return List.of(
                new RecognitionItem("西红柿", "2个", "vegetable", 0.96, false, List.of()),
                new RecognitionItem("鸡蛋", "3个", "egg_dairy", 0.91, false, List.of("egg")),
                new RecognitionItem("小葱", "少许", "vegetable", 0.79, false, List.of())
        );
    }
}
