package cn.chuxiaoban.ai;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.List;
import java.util.Map;

/** Minimal OpenAI-compatible transport used by Qwen-compatible endpoints. */
@Component
public class OpenAiCompatibleClient {
    private final RestClient client;
    private final ObjectMapper mapper;
    private final String visionModel;
    private final String textModel;
    private final int maxRetries;

    public OpenAiCompatibleClient(RestClient.Builder builder, ObjectMapper mapper,
                                  @Value("${cxb.ai.base-url:}") String baseUrl,
                                  @Value("${cxb.ai.api-key:}") String apiKey,
                                  @Value("${cxb.ai.vision-model:}") String visionModel,
                                  @Value("${cxb.ai.text-model:}") String textModel,
                                  @Value("${cxb.ai.max-retries:1}") int maxRetries) {
        if (baseUrl == null || baseUrl.isBlank()) throw new IllegalStateException("CXB_AI_BASE_URL is required for a real AI provider");
        if (apiKey == null || apiKey.isBlank()) throw new IllegalStateException("CXB_AI_API_KEY is required for a real AI provider");
        this.client = builder.baseUrl(baseUrl).defaultHeader("Authorization", "Bearer " + apiKey).build();
        this.mapper = mapper;
        this.visionModel = visionModel;
        this.textModel = textModel;
        this.maxRetries = Math.max(0, Math.min(3, maxRetries));
    }

    public String visionModel() { return visionModel; }
    public String textModel() { return textModel; }

    public JsonNode chat(String model, List<Map<String, Object>> messages) {
        if (model == null || model.isBlank()) throw new IllegalStateException("AI model is not configured");
        Map<String, Object> body = Map.of(
                "model", model,
                "messages", messages,
                "temperature", 0.2,
                "response_format", Map.of("type", "json_object"),
                "enable_thinking", false);
        JsonNode response = null;
        RuntimeException last = null;
        for (int attempt = 0; attempt <= maxRetries; attempt++) {
            try {
                response = client.post().uri("/chat/completions").contentType(MediaType.APPLICATION_JSON)
                        .body(body).retrieve().body(JsonNode.class);
                break;
            } catch (RuntimeException ex) {
                last = ex;
                if (attempt < maxRetries) try { Thread.sleep(250L * (attempt + 1)); } catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); throw new IllegalStateException("AI request interrupted", interrupted); }
            }
        }
        if (response == null && last != null) throw new IllegalStateException("AI request failed after retries", last);
        if (response == null) throw new IllegalStateException("AI returned an empty response");
        JsonNode content = response.path("choices").path(0).path("message").path("content");
        if (!content.isTextual()) throw new IllegalStateException("AI response content is not text");
        return parseJson(content.asText());
    }

    private JsonNode parseJson(String raw) {
        String value = raw == null ? "" : raw.trim();
        if (value.startsWith("```")) value = value.replaceFirst("^```(?:json)?\\s*", "").replaceFirst("\\s*```$", "").trim();
        int objectStart = value.indexOf('{');
        int arrayStart = value.indexOf('[');
        int start = objectStart < 0 ? arrayStart : arrayStart < 0 ? objectStart : Math.min(objectStart, arrayStart);
        if (start > 0) value = value.substring(start);
        try { return mapper.readTree(value); }
        catch (JsonProcessingException ex) { throw new IllegalStateException("AI returned invalid JSON", ex); }
    }
}
