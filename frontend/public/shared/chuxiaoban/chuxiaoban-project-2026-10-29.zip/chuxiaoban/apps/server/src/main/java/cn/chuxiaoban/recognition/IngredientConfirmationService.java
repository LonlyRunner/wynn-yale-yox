package cn.chuxiaoban.recognition;

import cn.chuxiaoban.common.api.ErrorCode;
import cn.chuxiaoban.common.exception.BusinessException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.time.Instant;

@Service
public class IngredientConfirmationService {
    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;
    private final AllergenRuleService allergenRules;

    public IngredientConfirmationService(JdbcTemplate jdbc, ObjectMapper mapper, AllergenRuleService allergenRules) {
        this.jdbc = jdbc; this.mapper = mapper; this.allergenRules = allergenRules;
    }

    @Transactional
    public void confirm(UUID spaceId, UUID taskId, List<ConfirmedIngredient> ingredients) {
        confirm(spaceId, taskId, ingredients, null);
    }

    @Transactional
    public void confirm(UUID spaceId, UUID taskId, List<ConfirmedIngredient> ingredients, Instant expectedUpdatedAt) {
        if (ingredients == null || ingredients.isEmpty() || ingredients.size() > 50)
            throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "至少确认一项食材");
        TaskState task = jdbc.query("SELECT status,updated_at FROM recognition_task WHERE id=? AND sync_space_id=? FOR UPDATE", rs -> {
            if (!rs.next()) return null;
            return new TaskState(rs.getString("status"), rs.getTimestamp("updated_at").toInstant());
        }, taskId, spaceId);
        if (task == null)
            throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "识别任务不存在或尚未可确认");

        // The client can retry after a slow network response.  Confirmation is deliberately
        // idempotent: a task already confirmed by this same request flow is a success, not a 409.
        if ("CONFIRMED".equals(task.status())) return;
        if (!"AWAITING_CONFIRMATION".equals(task.status()))
            throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "识别任务尚未可确认");
        if (expectedUpdatedAt != null && !task.updatedAt().equals(expectedUpdatedAt))
            throw new BusinessException(ErrorCode.CONFLICT, HttpStatus.CONFLICT, "识别任务已在另一端更新，请重新识别后再确认");
        jdbc.update("DELETE FROM confirmed_ingredient WHERE task_id=?", taskId);
        for (int i = 0; i < ingredients.size(); i++) {
            ConfirmedIngredient item = ingredients.get(i);
            if (item.name() == null || item.name().isBlank() || item.name().length() > 80)
                throw new BusinessException(ErrorCode.INVALID_ARGUMENT, HttpStatus.BAD_REQUEST, "食材名称不正确");
            var codes = allergenRules.allergensFor(item.name().trim(), item.allergenCodes());
            UUID sourceItemId = item.sourceItemId();
            if (sourceItemId != null) {
                Integer sourceOwned = jdbc.queryForObject("SELECT count(*) FROM recognized_item WHERE id=? AND task_id=?", Integer.class, sourceItemId, taskId);
                if (sourceOwned == null || sourceOwned != 1) sourceItemId = null;
            }
            jdbc.update("INSERT INTO confirmed_ingredient(id,task_id,source_item_id,name,quantity_text,allergen_codes,position) VALUES (?,?,?,?,?,?::jsonb,?)",
                    UUID.randomUUID(), taskId, sourceItemId, item.name().trim(), item.quantity(), json(codes), i);
        }
        jdbc.update("UPDATE recognition_task SET status='CONFIRMED',updated_at=now() WHERE id=?", taskId);
    }

    private String json(Object value) { try { return mapper.writeValueAsString(value); } catch (JsonProcessingException ex) { throw new IllegalStateException(ex); } }
    private record TaskState(String status, Instant updatedAt) {}
    public record ConfirmedIngredient(UUID sourceItemId, String name, String quantity, List<String> allergenCodes) {}
}
