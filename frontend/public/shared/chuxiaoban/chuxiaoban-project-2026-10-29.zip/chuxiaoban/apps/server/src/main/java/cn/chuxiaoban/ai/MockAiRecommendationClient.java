package cn.chuxiaoban.ai;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@ConditionalOnProperty(name = "cxb.ai.provider", havingValue = "mock", matchIfMissing = true)
public class MockAiRecommendationClient implements AiRecommendationClient {
    @Override
    public List<Recommendation> recommend(List<Ingredient> ingredients, Preferences preferences) {
        return List.of(
                new Recommendation("西红柿炒蛋", 1, 5, 8,
                        List.of(new RecommendationIngredient("西红柿", "2个", true), new RecommendationIngredient("鸡蛋", "3个", true)),
                        "食材匹配度高，步骤简单，适合先做", List.of()),
                new Recommendation("蒜蓉炒青菜", 1, 3, 5,
                        List.of(new RecommendationIngredient("青菜", "300g", false), new RecommendationIngredient("蒜", "少许", false)),
                        "快手少油，补充一份清爽蔬菜", List.of("需要补充青菜和蒜")),
                new Recommendation("玉米蛋花汤", 2, 5, 10,
                        List.of(new RecommendationIngredient("玉米", "1根", false), new RecommendationIngredient("鸡蛋", "1个", true)),
                        "冷热搭配，口味温和", List.of("需要补充玉米"))
        );
    }
}
