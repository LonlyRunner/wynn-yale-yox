package cn.chuxiaoban.oss;

import io.minio.*;
import io.minio.http.Method;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.net.URI;
import java.time.Duration;

@Component
public class MinioObjectStorage implements ObjectStorage {
    private final MinioClient client;
    private final String bucket;

    public MinioObjectStorage(@Value("${cxb.storage.endpoint}") String endpoint,
                              @Value("${cxb.storage.access-key}") String accessKey,
                              @Value("${cxb.storage.secret-key}") String secretKey,
                              @Value("${cxb.storage.bucket}") String bucket) {
        this.client = MinioClient.builder().endpoint(endpoint).credentials(accessKey, secretKey).build();
        this.bucket = bucket;
    }

    @Override
    public void put(String objectKey, InputStream content, long size, String contentType) {
        try {
            client.putObject(PutObjectArgs.builder().bucket(bucket).object(objectKey)
                    .stream(content, size, -1).contentType(contentType).build());
        } catch (Exception ex) { throw new IllegalStateException("对象存储上传失败", ex); }
    }

    @Override
    public URI signedGetUrl(String objectKey, Duration validity) {
        try {
            String url = client.getPresignedObjectUrl(GetPresignedObjectUrlArgs.builder().method(Method.GET)
                    .bucket(bucket).object(objectKey).expiry(Math.toIntExact(validity.toSeconds())).build());
            return URI.create(url);
        } catch (Exception ex) { throw new IllegalStateException("对象存储签名失败", ex); }
    }

    @Override
    public void delete(String objectKey) {
        try { client.removeObject(RemoveObjectArgs.builder().bucket(bucket).object(objectKey).build()); }
        catch (Exception ex) { throw new IllegalStateException("对象存储删除失败", ex); }
    }
}
