/** Cooking feedback and recent records. */
package cn.chuxiaoban.knowledge;
