package cn.chuxiaoban.ai;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.boot.autoconfigure.condition.ConditionalOnExpression;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@ConditionalOnExpression("'${cxb.ai.provider:mock}' == 'qwen' || '${cxb.ai.provider:mock}' == 'deepseek'")
public class QwenRecipeClient implements AiRecipeClient {
    private final OpenAiCompatibleClient client;
    private final ObjectMapper mapper;

    public QwenRecipeClient(OpenAiCompatibleClient client, ObjectMapper mapper) { this.client = client; this.mapper = mapper; }

    @Override
    public Recipe create(String dishName, int servings, boolean beginnerMode) {
        String prompt = "为菜品“" + dishName + "”生成适合新手的结构化菜谱。只返回JSON对象 {\"total_minutes\":1,\"steps\":[{\"step_no\":1,\"action\":\"\",\"heat_level\":\"not_applicable\",\"duration_minutes\":1,\"warnings\":[]}],\"safety_warnings\":[]}。步骤必须包含动作、火候、时间和安全提醒；不要输出医疗功效。人数=" + servings + "，新手模式=" + beginnerMode;
        var result = client.chat(client.textModel(), List.of(Map.of("role", "user", "content", prompt)));
        ObjectNode normalized = normalize(result);
        AiSchemaValidator.recipe(normalized);
        try { return mapper.treeToValue(normalized, Recipe.class); }
        catch (Exception ex) { throw new IllegalStateException("AI recipe schema invalid", ex); }
    }

    private ObjectNode normalize(JsonNode source) {
        if (source == null || !source.isObject()) throw new IllegalStateException("AI recipe schema invalid: object");
        ObjectNode root = (ObjectNode) source.deepCopy();
        if (!root.path("total_minutes").isIntegralNumber()) root.put("total_minutes", 30);
        if (!root.path("safety_warnings").isArray()) root.set("safety_warnings", mapper.createArrayNode());
        ArrayNode steps = mapper.createArrayNode();
        JsonNode rawSteps = root.path("steps");
        if (rawSteps.isArray()) {
            int no = 1;
            for (JsonNode raw : rawSteps) {
                if (!raw.isObject() || !raw.path("action").isTextual() || raw.path("action").asText().isBlank()) continue;
                ObjectNode step = mapper.createObjectNode();
                step.put("step_no", no++);
                step.put("action", raw.path("action").asText());
                step.put("heat_level", heatLevel(raw.path("heat_level").asText("not_applicable")));
                int duration = raw.path("duration_minutes").isIntegralNumber() ? raw.path("duration_minutes").asInt() : 5;
                step.put("duration_minutes", Math.max(0, Math.min(1440, duration)));
                step.set("warnings", raw.path("warnings").isArray() ? raw.path("warnings") : mapper.createArrayNode());
                steps.add(step);
            }
        }
        if (steps.isEmpty()) {
            ObjectNode step = mapper.createObjectNode();
            step.put("step_no", 1);
            step.put("action", "准备食材并完成烹饪");
            step.put("heat_level", "not_applicable");
            step.put("duration_minutes", 15);
            step.set("warnings", mapper.createArrayNode());
            steps.add(step);
        }
        root.set("steps", steps);
        return root;
    }

    private String heatLevel(String value) {
        String v = value == null ? "" : value.toLowerCase();
        if (v.contains("高") || v.contains("high")) return "high";
        if (v.contains("中") || v.contains("medium")) return "medium";
        if (v.contains("低") || v.contains("小") || v.contains("low")) return "low";
        if (v.contains("关") || v.contains("off")) return "off";
        return "not_applicable";
    }
}
