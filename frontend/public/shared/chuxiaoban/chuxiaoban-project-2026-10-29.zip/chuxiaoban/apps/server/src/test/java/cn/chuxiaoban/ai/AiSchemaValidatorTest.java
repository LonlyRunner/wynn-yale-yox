package cn.chuxiaoban.ai;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** Fixed contract samples for the AI workflows described in v1.2. */
class AiSchemaValidatorTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void acceptsRecognitionSamples() throws Exception {
        var valid = mapper.readTree("""
                {"recognized_items":[{"name":"西红柿","quantity":"2个","category":"vegetable","confidence":0.91,"needs_confirmation":false,"possible_allergens":[]}]}
                """);
        var empty = mapper.readTree("""
                {"recognized_items":[]}
                """);
        assertDoesNotThrow(() -> AiSchemaValidator.recognition(valid));
        assertDoesNotThrow(() -> AiSchemaValidator.recognition(empty));
    }

    @Test
    void rejectsInvalidRecognitionSamples() throws Exception {
        var confidence = mapper.readTree("""
                {"recognized_items":[{"name":"食材","quantity":null,"category":"vegetable","confidence":1.1,"needs_confirmation":true,"possible_allergens":[]}]}
                """);
        var category = mapper.readTree("""
                {"recognized_items":[{"name":"食材","quantity":null,"category":"unknown","confidence":0.2,"needs_confirmation":true,"possible_allergens":[]}]}
                """);
        assertTrue(assertThrows(IllegalStateException.class, () -> AiSchemaValidator.recognition(confidence)).getMessage().contains("recognition item"));
        assertTrue(assertThrows(IllegalStateException.class, () -> AiSchemaValidator.recognition(category)).getMessage().contains("recognition category"));
    }

    @Test
    void requiresExactlyThreeRecommendations() throws Exception {
        var valid = mapper.readTree("""
                {"recommendations":[{"name":"菜1","difficulty":1,"prep_minutes":5,"cook_minutes":10,"ingredients":["西红柿"],"warnings":[]},{"name":"菜2","difficulty":"中","prep_minutes":0,"cook_minutes":1,"ingredients":[],"warnings":[]},{"name":"菜3","difficulty":5,"prep_minutes":20,"cook_minutes":30,"ingredients":[],"warnings":[]}]}
                """);
        var tooFew = mapper.readTree("""
                {"recommendations":[{"name":"菜1","difficulty":1,"prep_minutes":5,"cook_minutes":10,"ingredients":[],"warnings":[]}]}
                """);
        assertDoesNotThrow(() -> AiSchemaValidator.recommendations(valid));
        assertThrows(IllegalStateException.class, () -> AiSchemaValidator.recommendations(tooFew));
    }

    @Test
    void rejectsInvalidRecipeHeatLevel() throws Exception {
        var valid = mapper.readTree("""
                {"total_minutes":20,"safety_warnings":["注意热油"],"steps":[{"step_no":1,"action":"加热锅","heat_level":"medium","duration_minutes":2,"warnings":[]}]}
                """);
        var invalidHeat = mapper.readTree("""
                {"total_minutes":20,"safety_warnings":[],"steps":[{"step_no":1,"action":"加热锅","heat_level":"爆炒","duration_minutes":2,"warnings":[]}]}
                """);
        assertDoesNotThrow(() -> AiSchemaValidator.recipe(valid));
        assertThrows(IllegalStateException.class, () -> AiSchemaValidator.recipe(invalidHeat));
    }
}
